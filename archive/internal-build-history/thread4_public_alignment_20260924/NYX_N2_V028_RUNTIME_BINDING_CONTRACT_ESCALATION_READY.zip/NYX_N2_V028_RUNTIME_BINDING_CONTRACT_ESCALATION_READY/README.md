# NYX N2 V028 — Runtime Binding Contract Escalation

This packet closes the N2 discovery lane without speculative construction.

Pinned evidence:
- V027 return SHA-256: `0b14b1dc7ab2603fcb80752c8e057eb003ef575afbd755737145b488a9dc789e`
- Constraint semantics anchor: `D:\HYDRA\phase0_surface_implementations\constraint_semantics_surface_v001.py`
- Anchor SHA-256: `bc95f5f86142084234c2dc954c7f6f192bfcbbdcdf3f77ce53bedbda7262388c`

Proven defect:
`N2-DEFECT-023-RUNTIME-ENTRYPOINT-CONTRACT-ABSENT`

Failed seam:
`PHASE0_SELECTED_CONSTRAINT_SURFACE_TO_RUNTIME_ENTRYPOINT`

Owner:
`PHASE0_BINDING_RUNTIME_OWNER`

Allowed owner repair:
Expose one explicit authoritative runtime binding contract pointing to a legitimate pre-existing executable entrypoint for the selected Constraint semantics surface.

Forbidden:
- inventing a loader;
- N2 adjudication changes;
- canonical Core changes from this packet;
- alias inference;
- mtime/newest-wins selection.

If no authorized runtime exists, the owner must return:
`BLOCKED_BY_MISSING_RUNTIME_AUTHORITY`.

N2 remains:
`PARKED_PENDING_OWNER_REPAIR`.

# Public Repository Map

The recruiter-facing path should expose the system in this order:

1. `repo/README.md`
2. `docs/ARCHITECTURE.md`
3. `docs/EVIDENCE_INDEX.md`
4. `constraint-case-study-v2.html`
5. `evidence/`
6. `docs/REAL_VS_SYNTHETIC.md`

Do not lead a new reader with giant internal version trees, hundreds of ZIPs, stale handoffs, deprecated artifacts, or internal factory archaeology.

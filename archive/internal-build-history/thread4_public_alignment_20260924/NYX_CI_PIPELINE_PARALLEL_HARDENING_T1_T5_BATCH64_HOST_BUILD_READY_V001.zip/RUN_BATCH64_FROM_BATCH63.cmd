@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_BATCH64_FROM_BATCH63.ps1"
if errorlevel 1 (
  echo.
  echo BATCH64 BUILD FAILED. See the error above.
  pause
  exit /b 1
)
echo.
echo BATCH64 BUILD PASSED.
pause

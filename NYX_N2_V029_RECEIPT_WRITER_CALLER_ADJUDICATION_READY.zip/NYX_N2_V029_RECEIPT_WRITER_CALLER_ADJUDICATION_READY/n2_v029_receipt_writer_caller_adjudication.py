
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import ntpath
import os
import re
import shutil
import tempfile
import warnings
import zipfile
from pathlib import Path
from typing import Any

warnings.filterwarnings("ignore", category=SyntaxWarning)

EXPECTED_V028_SHA256 = "274c9040e80d1479e8feda0ac4005e1b047166d693ffdb0f0ca6613f87b052c5"
EXPECTED_WRITER_SHA256 = "84df9a26f4b210fa9feae4cbea2189097c784fdf290f27227fb472b37cb60469"
WRITER_PATHS = ['D:\\HYDRA\\execution_runtime\\nyx_175_phase0_real_v001\\implementation_discovery_tool\\tools\\scan_hydra_implementation.py', 'D:\\HYDRA\\execution_runtime\\nyx_175_phase0_real_v001\\phase0_binding_review\\_tools_discovery\\tools\\scan_hydra_implementation.py', 'D:\\HYDRA\\execution_runtime\\NYX_PHASE0_HOST_PREFLIGHT_20260906_165307\\nyx_runtime\\phase0_discovery_workspace\\implementation_discovery_tool\\tools\\scan_hydra_implementation.py']

TEXT_EXTS = {".py",".ps1",".cmd",".bat",".json",".yaml",".yml",".toml",".ini",".cfg",".txt"}
EXEC_EXTS = {".py",".ps1",".cmd",".bat"}

EXCLUDED_PARTS = {
    ".git",".hg",".svn","__pycache__",".pytest_cache",".mypy_cache",
    "node_modules","site-packages","dist-packages",".venv","venv","env",
    "archive","archives","_archive","backup","backups","_backup",
    "stash","_stash","hydra stash","temp","tmp","downloads",
    "test_results","fixtures","fixture","quarantine","tests","test",
}
EXCLUDED_SUBSTRINGS = {"_zip_control_layer_temp","_verify_","verification"}

PY_EXEC_PRIMITIVES = {
    "subprocess.run","subprocess.Popen","subprocess.call","os.system",
    "runpy.run_path","runpy.run_module",
}
PS_EXEC_RX = re.compile(
    r"(?:\bpython(?:\.exe)?\b|\bpy(?:\.exe)?\b|"
    r"\bpowershell(?:\.exe)?\b.*?-File|"
    r"\bStart-Process\b|^\s*&\s+)",
    flags=re.IGNORECASE | re.MULTILINE,
)
CMD_EXEC_RX = re.compile(
    r"^\s*(?:call\s+|python(?:\.exe)?\s+|py(?:\.exe)?\s+|powershell(?:\.exe)?\s+)",
    flags=re.IGNORECASE | re.MULTILINE,
)

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()

def canon(v: str) -> str:
    s=str(v).strip().strip("'\"").replace("/","\\")
    while "\\\\" in s:
        s=s.replace("\\\\","\\")
    s=ntpath.normpath(s)
    if re.match(r"^[A-Za-z]:",s):
        s=s[0].upper()+s[1:]
    return s.casefold()

def display(v: str) -> str:
    s=str(v).strip().strip("'\"").replace("/","\\")
    while "\\\\" in s:
        s=s.replace("\\\\","\\")
    s=ntpath.normpath(s)
    if re.match(r"^[A-Za-z]:",s):
        s=s[0].upper()+s[1:]
    return s

def is_excluded(path: Path, root: Path) -> bool:
    try:
        rel=path.relative_to(root)
    except Exception:
        rel=path
    parts=[p.casefold() for p in rel.parts]
    for part in parts[:-1]:
        if part in EXCLUDED_PARTS:
            return True
        if any(x in part for x in EXCLUDED_SUBSTRINGS):
            return True
        if part.startswith("_nyx_") and "verify" in part:
            return True
    return False

def dotted(node):
    if isinstance(node,ast.Name):
        return node.id
    if isinstance(node,ast.Attribute):
        base=dotted(node.value)
        return (base+"."+node.attr) if base else node.attr
    return None

def python_exec_markers(path: Path):
    try:
        text=path.read_text(encoding="utf-8",errors="ignore")
        with warnings.catch_warnings():
            warnings.simplefilter("ignore",SyntaxWarning)
            tree=ast.parse(text)
    except Exception:
        return []
    rows=[]
    for n in ast.walk(tree):
        if isinstance(n,ast.Call):
            fn=dotted(n.func) or ""
            if fn in PY_EXEC_PRIMITIVES:
                rows.append({"primitive":fn,"lineno":getattr(n,"lineno",None)})
    return rows

def exec_markers(path: Path, text: str):
    ext=path.suffix.casefold()
    if ext==".py":
        return python_exec_markers(path)
    if ext==".ps1":
        return [{"match":m.group(0)[:200]} for m in PS_EXEC_RX.finditer(text)]
    if ext in {".cmd",".bat"}:
        return [{"match":m.group(0)[:200]} for m in CMD_EXEC_RX.finditer(text)]
    return []

def unique_suffix(writer: Path, root: Path):
    try:
        rel=writer.relative_to(root)
    except Exception:
        return str(writer)
    parts=list(rel.parts)
    # Keep enough path to distinguish the three byte-identical copies.
    return "\\".join(parts[-5:]) if len(parts)>=5 else "\\".join(parts)

def inspect_reference_file(path: Path, root: Path, writers: list[Path]):
    try:
        text=path.read_text(encoding="utf-8",errors="ignore")
    except Exception:
        return []

    text_norm=canon(text)
    markers=exec_markers(path,text)
    executable=path.suffix.casefold() in EXEC_EXTS and bool(markers)

    rows=[]
    for idx,writer in enumerate(writers,1):
        full=canon(str(writer))
        suffix=canon(unique_suffix(writer,root))
        full_hit=full in text_norm
        suffix_hit=suffix in text_norm
        basename_hit=writer.name.casefold() in text.casefold()

        if not (full_hit or suffix_hit or basename_hit):
            continue

        authority="MENTION_ONLY"
        if executable and full_hit:
            authority="EXACT_FULL_PATH_EXEC_CALLER"
        elif executable and suffix_hit:
            authority="UNIQUE_RELATIVE_PATH_EXEC_CALLER"
        elif executable and basename_hit:
            authority="BASENAME_EXEC_MENTION_ONLY"

        rows.append({
            "writer_index":idx,
            "writer_path":str(writer),
            "writer_sha256":sha256_file(writer) if writer.is_file() else None,
            "referrer_path":str(path),
            "referrer_sha256":sha256_file(path),
            "referrer_suffix":path.suffix.casefold(),
            "full_path_hit":full_hit,
            "unique_suffix_hit":suffix_hit,
            "basename_hit":basename_hit,
            "execution_marker_count":len(markers),
            "execution_markers":markers[:50],
            "authority":authority,
        })
    return rows

def selftest():
    td=Path(tempfile.mkdtemp(prefix="n2v029_"))
    try:
        root=td/"HYDRA"
        writer1=root/"execution_runtime"/"A"/"tools"/"scan_hydra_implementation.py"
        writer2=root/"execution_runtime"/"B"/"tools"/"scan_hydra_implementation.py"
        writer1.parent.mkdir(parents=True)
        writer2.parent.mkdir(parents=True)
        writer1.write_text("print('writer')\n",encoding="utf-8")
        writer2.write_text("print('writer')\n",encoding="utf-8")

        caller=root/"RUN_A.ps1"
        caller.write_text('python "'+str(writer1)+'"\n',encoding="utf-8")
        mention=root/"notes.txt"
        mention.write_text("scan_hydra_implementation.py\n",encoding="utf-8")

        rr=inspect_reference_file(caller,root,[writer1,writer2])
        strong_rr=[x for x in rr if x["authority"] in {"EXACT_FULL_PATH_EXEC_CALLER","UNIQUE_RELATIVE_PATH_EXEC_CALLER"}]
        assert len(strong_rr)==1
        assert strong_rr[0]["writer_path"]==str(writer1)
        assert strong_rr[0]["authority"]=="EXACT_FULL_PATH_EXEC_CALLER"
        assert all(x["authority"] in {"EXACT_FULL_PATH_EXEC_CALLER","BASENAME_EXEC_MENTION_ONLY"} for x in rr)

        mm=inspect_reference_file(mention,root,[writer1,writer2])
        assert mm and all(x["authority"]=="MENTION_ONLY" for x in mm)

        print("N2_V029_SELFTEST=PASS")
        print("N2_V029_EXACT_CALLER_GATE=PASS")
        print("N2_V029_IDENTICAL_HASH_NOT_OWNER_AUTHORITY=PASS")
        print("N2_V029_BASENAME_MENTION_REJECTED=PASS")
        print("N2_V029_MTIME_UNUSED=PASS")
    finally:
        shutil.rmtree(td,ignore_errors=True)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--hydra-root",default=r"D:\HYDRA")
    ap.add_argument("--v028-evidence")
    ap.add_argument("--output-dir")
    ap.add_argument("--selftest",action="store_true")
    args=ap.parse_args()

    if args.selftest:
        selftest()
        return 0

    root=Path(args.hydra_root)
    ev=Path(args.v028_evidence)
    outdir=Path(args.output_dir)

    if not root.is_dir():
        raise RuntimeError(f"HYDRA root missing: {root}")
    if not ev.is_file():
        raise RuntimeError(f"V028 evidence missing: {ev}")
    if sha256_file(ev)!=EXPECTED_V028_SHA256:
        raise RuntimeError("V028 evidence SHA256 mismatch")

    writers=[Path(p) for p in WRITER_PATHS]
    writer_receipts=[]
    for p in writers:
        exists=p.is_file()
        sha=sha256_file(p) if exists else None
        writer_receipts.append({
            "path":str(p),
            "exists":exists,
            "sha256":sha,
            "expected_sha256":EXPECTED_WRITER_SHA256,
            "hash_match":(sha==EXPECTED_WRITER_SHA256) if sha else False,
        })

    refs=[]
    files_seen=0
    eligible_files=0
    for cur,dirs,files in os.walk(root,topdown=True):
        cp=Path(cur)
        dirs[:]=[d for d in dirs if not is_excluded(cp/d/"__probe__.py",root)]
        for fn in files:
            files_seen+=1
            p=cp/fn
            if p.suffix.casefold() not in TEXT_EXTS:
                continue
            if is_excluded(p,root):
                continue
            if any(canon(str(p))==canon(str(w)) for w in writers):
                continue
            try:
                if p.stat().st_size>5_000_000:
                    continue
            except Exception:
                continue
            eligible_files+=1
            refs.extend(inspect_reference_file(p,root,writers))

    strong=[r for r in refs if r["authority"] in {"EXACT_FULL_PATH_EXEC_CALLER","UNIQUE_RELATIVE_PATH_EXEC_CALLER"}]
    mention_only=[r for r in refs if r["authority"]=="MENTION_ONLY"]
    basename_exec=[r for r in refs if r["authority"]=="BASENAME_EXEC_MENTION_ONLY"]

    per_writer=[]
    for idx,w in enumerate(writers,1):
        s=[r for r in strong if r["writer_index"]==idx]
        per_writer.append({
            "writer_index":idx,
            "writer_path":str(w),
            "writer_sha256":sha256_file(w) if w.is_file() else None,
            "strong_caller_count":len(s),
            "strong_callers":s,
        })

    active=[r for r in per_writer if r["strong_caller_count"]>0]

    if len(active)==1:
        status="UNIQUE_RECEIPT_WRITER_RUNTIME_BRANCH_PROVEN"
        defect=None
        selected=active[0]
        next_action="PIN_SELECTED_RECEIPT_WRITER_BRANCH_AND_INSPECT_ITS_CALLER_ORCHESTRATION_ONLY"
    elif len(active)>1:
        status="MULTIPLE_RECEIPT_WRITER_RUNTIME_BRANCHES_ACTIVE"
        defect="N2-DEFECT-025-RECEIPT-WRITER-RUNTIME-BRANCH-AMBIGUOUS"
        selected=None
        next_action="STOP_NO_MUTATION_ADJUDICATE_MULTIPLE_EXACT_CALLER_BRANCHES"
    else:
        status="NO_RECEIPT_WRITER_CALLER_PROVEN"
        defect="N2-DEFECT-025-RECEIPT-WRITER-CALLER-NOT-PROVEN"
        selected=None
        next_action="STOP_NO_MUTATION_RECEIPT_WRITERS_ARE_NOT_RUNTIME_BOUND_BY_EXACT_CALLER"

    result={
        "version":"N2_V029_RECEIPT_WRITER_CALLER_ADJUDICATION",
        "parent_defect":"N2-DEFECT-024-RUNTIME-BINDING-CONTRACT-OWNER-NOT-PROVEN",
        "v028_sha256":sha256_file(ev),
        "hydra_root":str(root),
        "expected_writer_sha256":EXPECTED_WRITER_SHA256,
        "writer_count":len(writers),
        "writer_receipts":writer_receipts,
        "files_seen":files_seen,
        "eligible_files_scanned":eligible_files,
        "reference_count":len(refs),
        "strong_caller_count":len(strong),
        "mention_only_count":len(mention_only),
        "basename_exec_mention_count":len(basename_exec),
        "writer_branch_receipts":per_writer,
        "selected_writer_branch":selected,
        "status":status,
        "defect_id":defect,
        "next_action":next_action,
        "read_only":True,
        "baseline_mutated":False,
        "canonical_core_mutated":False,
        "constraint_semantics_mutated":False,
        "n2_mutated":False,
        "mention_only_authority":"REJECTED",
        "identical_hash_owner_authority":"REJECTED",
        "mtime_authority":"NONE",
        "score_selection":"NONE",
    }

    outdir.mkdir(parents=True,exist_ok=True)
    (outdir/"N2_V029_RECEIPT_WRITER_CALLER_ADJUDICATION.json").write_text(
        json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")

    print("="*60)
    print("NYX N2 V029 - RECEIPT WRITER CALLER ADJUDICATION")
    print("="*60)
    print("FINAL="+status)
    print("PARENT_DEFECT="+result["parent_defect"])
    print("DEFECT_ID="+(defect or "NONE"))
    print("WRITER_COUNT="+str(len(writers)))
    print("FILES_SEEN="+str(files_seen))
    print("ELIGIBLE_FILES_SCANNED="+str(eligible_files))
    print("REFERENCE_COUNT="+str(len(refs)))
    print("STRONG_CALLER_COUNT="+str(len(strong)))
    print("MENTION_ONLY_COUNT="+str(len(mention_only)))
    print("BASENAME_EXEC_MENTION_COUNT="+str(len(basename_exec)))

    for row in per_writer:
        i=row["writer_index"]
        print(f"WRITER_{i:02d}_PATH="+row["writer_path"])
        print(f"WRITER_{i:02d}_SHA256="+str(row["writer_sha256"] or ""))
        print(f"WRITER_{i:02d}_STRONG_CALLER_COUNT="+str(row["strong_caller_count"]))
        for j,caller in enumerate(row["strong_callers"][:10],1):
            print(f"WRITER_{i:02d}_CALLER_{j:02d}="+caller["referrer_path"])
            print(f"WRITER_{i:02d}_CALLER_{j:02d}_SHA256="+caller["referrer_sha256"])
            print(f"WRITER_{i:02d}_CALLER_{j:02d}_AUTHORITY="+caller["authority"])

    if selected:
        print("SELECTED_WRITER_PATH="+selected["writer_path"])
        print("SELECTED_WRITER_SHA256="+str(selected["writer_sha256"] or ""))

    print("READ_ONLY=TRUE")
    print("BASELINE_MUTATED=FALSE")
    print("CANONICAL_CORE_MUTATED=FALSE")
    print("CONSTRAINT_SEMANTICS_MUTATED=FALSE")
    print("N2_MUTATED=FALSE")
    print("MENTION_ONLY_AUTHORITY=REJECTED")
    print("IDENTICAL_HASH_OWNER_AUTHORITY=REJECTED")
    print("NO_MTIME_AUTHORITY=TRUE")
    print("SCORE_SELECTION=NO")
    print("NEXT_ACTION="+next_action)
    return 0

if __name__=="__main__":
    raise SystemExit(main())

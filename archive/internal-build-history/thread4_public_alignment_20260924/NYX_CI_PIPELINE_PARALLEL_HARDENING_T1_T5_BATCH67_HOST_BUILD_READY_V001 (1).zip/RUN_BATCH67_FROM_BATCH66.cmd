@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_BATCH67_FROM_BATCH66.ps1"
if errorlevel 1 (
  echo.
  echo BATCH67 BUILD FAILED. See the error above.
  pause
  exit /b 1
)
echo.
echo BATCH67 BUILD PASSED.
pause

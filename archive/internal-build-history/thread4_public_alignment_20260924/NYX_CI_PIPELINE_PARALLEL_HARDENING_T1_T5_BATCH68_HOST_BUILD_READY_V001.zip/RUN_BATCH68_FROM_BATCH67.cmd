@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_BATCH68_FROM_BATCH67.ps1"
if errorlevel 1 (
  echo.
  echo BATCH68 BUILD FAILED. See the error above.
  pause
  exit /b 1
)
echo.
echo BATCH68 BUILD PASSED.
pause

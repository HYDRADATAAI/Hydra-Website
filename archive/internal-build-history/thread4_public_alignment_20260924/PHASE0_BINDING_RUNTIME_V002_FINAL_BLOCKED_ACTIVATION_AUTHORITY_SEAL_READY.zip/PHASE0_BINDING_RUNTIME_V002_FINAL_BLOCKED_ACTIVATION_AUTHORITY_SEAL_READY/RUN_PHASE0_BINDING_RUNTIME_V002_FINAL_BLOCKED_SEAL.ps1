param(
    [string]$V001Evidence=""
)
$ErrorActionPreference="Stop"
Set-StrictMode -Version Latest

$Expected="795ec8ce85f862a1568b6c2c9eb08e5e96bad418d8ce00f2fc98257a02476e8b"

Write-Host "============================================================"
Write-Host "PHASE0 BINDING/RUNTIME V002 - FINAL BLOCKED ACTIVATION AUTHORITY SEAL"
Write-Host "============================================================"
Write-Host "SOURCE_DEFECT=N2-DEFECT-026-HIGHER-ORDER-DEPLOYMENT-BINDING-NOT-PROVEN"
Write-Host "DEFECT_ID=PHASE0-DEFECT-001-DEPLOYMENT-ACTIVATION-CONTRACT-ABSENT"
Write-Host "FAILED_SEAM=PHASE0_DEPLOYMENT_ROOT_TO_RUNTIME_ACTIVATION"
Write-Host "MODE=READ_ONLY_FINAL_BLOCKED_SEAL"
Write-Host "NEW_DISCOVERY=NO"
Write-Host "ARCHITECTURE_EXTENSION_AUTHORIZED=NO"
Write-Host "N2_REOPEN=NO"

$Downloads=Join-Path $env:USERPROFILE "Downloads"

if(-not $V001Evidence){
    $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "PHASE0_BINDING_RUNTIME_V001_ACTIVATION_AUTHORITY_RETURN_*.zip" -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending
    $Found=$null
    foreach($C in $Candidates){
        $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        if($H -eq $Expected){$Found=$C;break}
    }
    if(-not $Found){
        $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "*PHASE0*V001*RETURN*.zip" -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending
        foreach($C in $Candidates){
            $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            if($H -eq $Expected){$Found=$C;break}
        }
    }
    if(-not $Found){throw "Exact Phase0 V001 return packet not found with SHA256=$Expected"}
    $V001Evidence=$Found.FullName
}

$Actual=(Get-FileHash -LiteralPath $V001Evidence -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host "V001_EVIDENCE=$V001Evidence"
Write-Host "V001_EVIDENCE_SHA256=$Actual"
if($Actual -ne $Expected){throw "Phase0 V001 evidence hash mismatch."}
Write-Host "V001_EVIDENCE_HASH_VERIFIED=PASS"

$Tmp=Join-Path $env:TEMP ("PHASE0_V002_VERIFY_" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $Tmp -Force|Out-Null
try {
    Expand-Archive -LiteralPath $V001Evidence -DestinationPath $Tmp -Force
    $Report=Get-ChildItem -LiteralPath $Tmp -Filter "PHASE0_V001_DEPLOYMENT_ACTIVATION_AUTHORITY_PROOF.json" -File -Recurse |
        Select-Object -First 1
    if(-not $Report){throw "Phase0 V001 authority proof JSON not found in return packet."}

    $R=Get-Content -LiteralPath $Report.FullName -Raw | ConvertFrom-Json

    $Checks=[ordered]@{
        V001_FINAL_BLOCKED=($R.status -eq "BLOCKED_BY_MISSING_DEPLOYMENT_ACTIVATION_AUTHORITY")
        V001_DEFECT_MATCH=($R.defect_id -eq "PHASE0-DEFECT-001-DEPLOYMENT-ACTIVATION-CONTRACT-ABSENT")
        CONTRACT_HITS_ZERO=([int]$R.contract_hit_count -eq 0)
        ACTIVATION_COMBOS_ZERO=([int]$R.unique_activation_combo_count -eq 0)
        V001_READ_ONLY=([bool]$R.read_only -eq $true)
        BASELINE_UNMUTATED=([bool]$R.baseline_mutated -eq $false)
        CORE_UNMUTATED=([bool]$R.canonical_core_mutated -eq $false)
        CONSTRAINT_UNMUTATED=([bool]$R.constraint_semantics_mutated -eq $false)
        N2_UNMUTATED=([bool]$R.n2_mutated -eq $false)
    }

    foreach($K in $Checks.Keys){
        Write-Host ("CHECK_" + $K + "=" + $Checks[$K].ToString().ToUpperInvariant())
        if(-not $Checks[$K]){throw "Seal prerequisite failed: $K"}
    }

    $RunDir="D:\NYX_PHASE0_BINDING_RUNTIME_WORK\V002_FINAL_BLOCKED_SEAL_$(Get-Date -Format yyyyMMdd_HHmmss)"
    $ReturnDir=Join-Path $RunDir "PHASE0_V002_RETURN"
    New-Item -ItemType Directory -Path $ReturnDir -Force|Out-Null

    $Receipt=[ordered]@{
        version="PHASE0_BINDING_RUNTIME_V002_FINAL_BLOCKED_ACTIVATION_AUTHORITY_SEAL"
        final="BLOCKED_SEALED_MISSING_DEPLOYMENT_ACTIVATION_AUTHORITY"
        phase0_sealed=$true
        seal_type="FINAL_BLOCKED_MISSING_AUTHORITY"
        source_defect="N2-DEFECT-026-HIGHER-ORDER-DEPLOYMENT-BINDING-NOT-PROVEN"
        defect_id="PHASE0-DEFECT-001-DEPLOYMENT-ACTIVATION-CONTRACT-ABSENT"
        failed_seam="PHASE0_DEPLOYMENT_ROOT_TO_RUNTIME_ACTIVATION"
        owner_lane="PHASE0_BINDING_RUNTIME"
        parent_v001_final=$R.status
        parent_v001_defect_id=$R.defect_id
        contract_hit_count=[int]$R.contract_hit_count
        unique_activation_combo_count=[int]$R.unique_activation_combo_count
        exact_cause="Phase-0 owner proof found zero explicit activation contracts binding either proven deployment root to a runnable runtime entrypoint."
        minimum_repair="No repair authorized. Creating an activation contract is an architecture change requiring explicit approval or new authoritative evidence."
        reopen_gate="Explicit architecture authorization to create/install a deployment activation contract, or new authoritative evidence proving a pre-existing contract."
        baseline_mutated="NO"
        canonical_core_mutated="NO"
        constraint_semantics_mutated="NO"
        n2_mutated="NO"
        n2_disposition="ARCHIVE_PARKED"
        phase0_disposition="BLOCKED_SEALED"
        next_action="STOP_UNTIL_EXPLICIT_ARCHITECTURE_AUTHORIZATION_OR_NEW_AUTHORITY_EVIDENCE"
        v001_evidence=$V001Evidence
        v001_sha256=$Actual
    }

    $ReceiptPath=Join-Path $ReturnDir "PHASE0_V002_FINAL_BLOCKED_ACTIVATION_AUTHORITY_SEAL.json"
    $Receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $ReceiptPath -Encoding UTF8

    $Ticket=[ordered]@{
        defect_id="PHASE0-DEFECT-001-DEPLOYMENT-ACTIVATION-CONTRACT-ABSENT"
        failed_seam="PHASE0_DEPLOYMENT_ROOT_TO_RUNTIME_ACTIVATION"
        owner_lane="PHASE0_BINDING_RUNTIME"
        status="BLOCKED_MISSING_AUTHORITY"
        architecture_change_required=$true
        mutation_authorized=$false
        allowed_future_action="Explicitly authorized activation-contract creation/install OR presentation of new pre-existing authority evidence"
        forbidden=@(
            "Infer active root by mtime/newest-wins",
            "Infer active root from directory names",
            "Treat identical code hashes as activation authority",
            "Patch both deployment roots",
            "Reopen N2 before activation authority is proven"
        )
    }
    $TicketPath=Join-Path $ReturnDir "PHASE0_DEFECT_001_DEPLOYMENT_ACTIVATION_AUTHORITY_TICKET.json"
    $Ticket | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $TicketPath -Encoding UTF8

    $Summary=@"
PHASE0 BINDING/RUNTIME V002 FINAL BLOCKED ACTIVATION AUTHORITY SEAL
FINAL=BLOCKED_SEALED_MISSING_DEPLOYMENT_ACTIVATION_AUTHORITY
PHASE0_SEALED=TRUE
SEAL_TYPE=FINAL_BLOCKED_MISSING_AUTHORITY
SOURCE_DEFECT=N2-DEFECT-026-HIGHER-ORDER-DEPLOYMENT-BINDING-NOT-PROVEN
DEFECT_ID=PHASE0-DEFECT-001-DEPLOYMENT-ACTIVATION-CONTRACT-ABSENT
FAILED_SEAM=PHASE0_DEPLOYMENT_ROOT_TO_RUNTIME_ACTIVATION
CONTRACT_HIT_COUNT=0
UNIQUE_ACTIVATION_COMBO_COUNT=0
BASELINE_MUTATED=NO
CANONICAL_CORE_MUTATED=NO
CONSTRAINT_SEMANTICS_MUTATED=NO
N2_MUTATED=NO
N2_DISPOSITION=ARCHIVE_PARKED
PHASE0_DISPOSITION=BLOCKED_SEALED
ARCHITECTURE_EXTENSION_AUTHORIZED=NO
REOPEN_GATE=Explicit architecture authorization to create/install a deployment activation contract, or new authoritative evidence proving a pre-existing contract.
NEXT_ACTION=STOP_UNTIL_EXPLICIT_ARCHITECTURE_AUTHORIZATION_OR_NEW_AUTHORITY_EVIDENCE
"@
    $SummaryPath=Join-Path $ReturnDir "PHASE0_V002_FINAL_BLOCKED_ACTIVATION_AUTHORITY_SUMMARY.txt"
    $Summary | Set-Content -LiteralPath $SummaryPath -Encoding UTF8

    $ReturnZip=Join-Path $Downloads ("PHASE0_BINDING_RUNTIME_V002_FINAL_BLOCKED_SEAL_RETURN_{0}.zip" -f (Get-Date -Format yyyyMMdd_HHmmss))
    Compress-Archive -Path (Join-Path $ReturnDir "*") -DestinationPath $ReturnZip -CompressionLevel Optimal
    $ReturnSha=(Get-FileHash -LiteralPath $ReturnZip -Algorithm SHA256).Hash.ToLowerInvariant()

    Write-Host ""
    Write-Host "============================================================"
    Write-Host "PHASE0 BINDING/RUNTIME V002 FINAL"
    Write-Host "============================================================"
    Write-Host "FINAL=BLOCKED_SEALED_MISSING_DEPLOYMENT_ACTIVATION_AUTHORITY"
    Write-Host "PHASE0_SEALED=TRUE"
    Write-Host "SEAL_TYPE=FINAL_BLOCKED_MISSING_AUTHORITY"
    Write-Host "SOURCE_DEFECT=N2-DEFECT-026-HIGHER-ORDER-DEPLOYMENT-BINDING-NOT-PROVEN"
    Write-Host "DEFECT_ID=PHASE0-DEFECT-001-DEPLOYMENT-ACTIVATION-CONTRACT-ABSENT"
    Write-Host "FAILED_SEAM=PHASE0_DEPLOYMENT_ROOT_TO_RUNTIME_ACTIVATION"
    Write-Host "CONTRACT_HIT_COUNT=0"
    Write-Host "UNIQUE_ACTIVATION_COMBO_COUNT=0"
    Write-Host "BASELINE_MUTATED=NO"
    Write-Host "CANONICAL_CORE_MUTATED=NO"
    Write-Host "CONSTRAINT_SEMANTICS_MUTATED=NO"
    Write-Host "N2_MUTATED=NO"
    Write-Host "N2_DISPOSITION=ARCHIVE_PARKED"
    Write-Host "PHASE0_DISPOSITION=BLOCKED_SEALED"
    Write-Host "ARCHITECTURE_EXTENSION_AUTHORIZED=NO"
    Write-Host "NEXT_ACTION=STOP_UNTIL_EXPLICIT_ARCHITECTURE_AUTHORIZATION_OR_NEW_AUTHORITY_EVIDENCE"
    Write-Host "RETURN_ZIP=$ReturnZip"
    Write-Host "RETURN_SHA256=$ReturnSha"
    Write-Host "RETURN_RUN_DIR=$RunDir"
}
finally {
    Remove-Item -LiteralPath $Tmp -Recurse -Force -ErrorAction SilentlyContinue
}

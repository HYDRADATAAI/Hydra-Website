param(
    [string]$V031Evidence=""
)
$ErrorActionPreference="Stop"
Set-StrictMode -Version Latest

$Expected="620677b7e81a29e77627879dc9005e5bd696dff12be8d037e6e45a8699f8cf1b"
$Downloads=Join-Path $env:USERPROFILE "Downloads"

Write-Host "============================================================"
Write-Host "PHASE0 BINDING/RUNTIME DEFECT-026 HANDOFF"
Write-Host "============================================================"
Write-Host "SOURCE_LANE=NYX_N2"
Write-Host "SOURCE_VERSION=V031"
Write-Host "N2_SEALED=TRUE"
Write-Host "N2_DISPOSITION=ARCHIVE_PARKED"
Write-Host "DEFECT_ID=N2-DEFECT-026-HIGHER-ORDER-DEPLOYMENT-BINDING-NOT-PROVEN"
Write-Host "OWNER_LANE=PHASE0_BINDING_RUNTIME"
Write-Host "MUTATION_AUTHORIZED=NO_HANDOFF_ONLY"

if(-not $V031Evidence){
    $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "N2_V031_RETURN_PACKET_*.zip" -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending
    $Found=$null
    foreach($C in $Candidates){
        $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        if($H -eq $Expected){$Found=$C;break}
    }
    if(-not $Found){
        $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "*V031*RETURN*.zip" -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending
        foreach($C in $Candidates){
            $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            if($H -eq $Expected){$Found=$C;break}
        }
    }
    if(-not $Found){throw "Exact sealed V031 return packet not found with SHA256=$Expected"}
    $V031Evidence=$Found.FullName
}

$Actual=(Get-FileHash -LiteralPath $V031Evidence -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host "V031_EVIDENCE=$V031Evidence"
Write-Host "V031_EVIDENCE_SHA256=$Actual"
if($Actual -ne $Expected){throw "V031 evidence hash mismatch."}
Write-Host "V031_EVIDENCE_HASH_VERIFIED=PASS"

$Roots=@(
    "D:\HYDRA\execution_runtime\nyx_175_phase0_real_v001",
    "D:\HYDRA\execution_runtime\nyx_phase0_host_preflight_20260906_165307"
)
foreach($Root in $Roots){
    Write-Host "DEPLOYMENT_ROOT=$Root EXISTS=$((Test-Path -LiteralPath $Root -PathType Container).ToString().ToUpperInvariant())"
}

Write-Host ""
Write-Host "FINAL=HANDOFF_READY"
Write-Host "FAILED_SEAM=PHASE0_DEPLOYMENT_ROOT_TO_RUNTIME_ACTIVATION"
Write-Host "OWNER_LANE=PHASE0_BINDING_RUNTIME"
Write-Host "ALLOWED_OUTCOME_1=DEPLOYMENT_ACTIVATION_CONTRACT_PROVEN"
Write-Host "ALLOWED_OUTCOME_2=BLOCKED_BY_MISSING_DEPLOYMENT_ACTIVATION_AUTHORITY"
Write-Host "N2_REOPEN=FORBIDDEN_UNTIL_REOPEN_GATE_SATISFIED"
Write-Host "BASELINE_MUTATED=NO"
Write-Host "CANONICAL_CORE_MUTATED=NO"
Write-Host "N2_MUTATED=NO"

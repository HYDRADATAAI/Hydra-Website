HYDRA V14 — FINAL PUBLIC RELEASE SEAL

Purpose
-------
Read-only post-deployment verification. This package does not modify GitHub, GitHub Pages, or the local HYDRA baseline.

Prerequisite
------------
Run V13 first. V14 requires the latest:
  HYDRA_V13_PUBLIC_GITHUB_DEPLOYMENT_RETURN_*.zip
in your Downloads folder.

V14 independently proves:
1. V13 recorded a successful repo sync.
2. Public main SHA equals the V13 post-deploy SHA.
3. Every V12 deployment-manifest file exists publicly and has the exact sealed SHA-256.
4. GitHub Pages serves the homepage, constraint case study, and repository front door.
5. Public pages contain the recruiter hero, explicit REPRESENTATIVE/SYNTHETIC/SHADOW labels, authority principle, blocked state, and claim-boundary language.
6. No affirmative unsupported live-production claim is found by the bounded audit.

Only then does it issue:
  PASS_FINAL_PUBLIC_SITE_RELEASE_SEAL

Otherwise it returns a named blocker and performs no repair or mutation.

from pathlib import Path
from bs4 import BeautifulSoup
import re, json, csv, hashlib

ROOT=Path('/mnt/data/RECRUITER_SCAN_AUDIT')
W2=ROOT/'PATCHED_PUBLIC_SURFACES/W2_PROOF'
W3=ROOT/'PATCHED_PUBLIC_SURFACES/W3_CASE'
GH=ROOT/'PATCHED_PUBLIC_SURFACES/GITHUB_W4'
checks=[]

def check(name, ok, observed):
    checks.append({'check':name,'pass':bool(ok),'observed':observed})

# HTML asset + content checks
for label,base in [('W2',W2),('W3',W3)]:
    html=base/'index.html'
    soup=BeautifulSoup(html.read_text(encoding='utf-8'),'html.parser')
    css=soup.find('link',rel='stylesheet')
    target=base/(css.get('href') if css else '')
    check(f'{label}_STYLESHEET_PRESENT', css is not None and target.exists(), str(target))
    text=' '.join(soup.stripped_strings)
    check(f'{label}_NO_TERMINAL_WALL', max([len(x.get_text('\n').splitlines()) for x in soup.find_all('pre')] or [0]) <= 12,
          max([len(x.get_text('\n').splitlines()) for x in soup.find_all('pre')] or [0]))
    check(f'{label}_WORD_COUNT_BOUNDED', len(text.split()) < 1000, len(text.split()))

s2=BeautifulSoup((W2/'index.html').read_text(encoding='utf-8'),'html.parser')
check('W2_EIGHT_STEP_LOOP', len(s2.select('.proof-card'))==8, len(s2.select('.proof-card')))
check('W2_FAST_SUMMARY_PRESENT', len(s2.select('.scan-summary > div'))==3, [x.get_text(' ',strip=True) for x in s2.select('.scan-summary > div')])
check('W2_REAL_PROOF_VISIBLE_IN_FAST_SUMMARY', '17,766,662' in s2.select_one('.scan-summary').get_text(' ',strip=True), s2.select_one('.scan-summary').get_text(' ',strip=True))
check('W2_FAIL_CLOSED_VISIBLE_IN_FAST_SUMMARY', 'Missing authority stays blocked' in s2.select_one('.scan-summary').get_text(' ',strip=True), s2.select_one('.scan-summary').get_text(' ',strip=True))
css2=(W2/'styles.css').read_text(encoding='utf-8')
tiny8=bool(re.search(r'(font-size\s*:\s*8px|font\s*:\s*[^;]*\b8px\b)',css2))
check('W2_NO_8PX_SCAN_LABELS', not tiny8, '8px style found' if tiny8 else 'none')

s3=BeautifulSoup((W3/'index.html').read_text(encoding='utf-8'),'html.parser')
check('W3_SEVEN_STAGE_CASE', len(s3.select('.pipeline .node'))==7, len(s3.select('.pipeline .node')))
fast=s3.select_one('.case-fast-read')
check('W3_FAST_RESULT_PRESENT', fast is not None, fast.get_text(' ',strip=True) if fast else None)
check('W3_SUPPORTED_AND_BLOCKED_VISIBLE', fast is not None and 'LOCAL BOTTLENECK' in fast.get_text() and 'SYSTEMIC SHORTAGE' in fast.get_text(), fast.get_text(' ',strip=True) if fast else None)
check('W3_REPRESENTATIVE_LABEL_RETAINED', 'REPRESENTATIVE / NON-LIVE' in s3.get_text(' ',strip=True), 'REPRESENTATIVE / NON-LIVE')

# GitHub front door checks
readme=(GH/'README.md').read_text(encoding='utf-8')
check('GITHUB_30_SECOND_PROOF_BEFORE_ARCHITECTURE', readme.find('## 30-second proof') < readme.find('## Architecture'), [readme.find('## 30-second proof'), readme.find('## Architecture')])
for phrase in ['17,766,662 canonical rows written','synthetic/shadow integrated seam','semantic_values_invented=false']:
    check('GITHUB_FAST_PROOF_'+re.sub(r'\W+','_',phrase).upper()[:50], phrase in readme, phrase)
# relative markdown links
links=re.findall(r'\[[^\]]+\]\(([^)]+)\)',readme)
bad=[]
for href in links:
    if '://' in href or href.startswith('#') or href.startswith('mailto:'): continue
    path=(GH/href).resolve()
    if not path.exists(): bad.append(href)
check('GITHUB_LOCAL_LINKS_RESOLVE', not bad, bad)
check('GITHUB_NO_PUBLIC_PRODUCTION_RUNNER_CLAIM', 'There is **no public production runner claimed here**' in readme, 'explicit boundary present')

# Hero scan contract
hero=(ROOT/'HERO_SCAN_CONTRACT.md').read_text(encoding='utf-8')
for phrase in ['HYDRA / MARKET INTELLIGENCE DATA PLATFORM','Turn fragmented market data into traceable intelligence.','Source-accounted ingestion','Contract-bound handoffs','Lineage + release gates']:
    check('HERO_'+re.sub(r'\W+','_',phrase).upper()[:50], phrase in hero, phrase)

# Overall
fail=[c for c in checks if not c['pass']]
receipt={
    'deliverable':'RECRUITER_SCAN_AUDIT',
    'acceptance':'PASS' if not fail else 'FAIL',
    'checks_total':len(checks),
    'checks_passed':len(checks)-len(fail),
    'checks_failed':len(fail),
    'browser_runtime_scan':'DEFERRED_TO_W7',
    'reason':'W6 is recruiter information-hierarchy scan; W7 owns browser/responsive/link runtime seal.',
    'checks':checks,
}
(ROOT/'W6_RECRUITER_SCAN_RECEIPT.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt,indent=2))
if fail: raise SystemExit(1)

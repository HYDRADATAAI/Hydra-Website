﻿param(
  [string]$SiteRoot = "D:\HYDRA_SITE\V7",
  [string]$ResultBase = "D:\HYDRA\WEBSITE_TEST_RESULTS",
  [string]$PublicDeploymentUrl = ""
)
$ErrorActionPreference = "Stop"
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$ResultRoot = Join-Path $ResultBase ("W7_V005_BOUNDED_REPAIR_RETEST_" + $Stamp)
$BackupRoot = Join-Path $ResultRoot "BACKUP"
New-Item -ItemType Directory -Path $ResultRoot -Force | Out-Null
New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null
Write-Host "===================================================================="
Write-Host "HYDRA W7 V005 - BOUNDED COPY REPAIR + BROWSER RETEST"
Write-Host "===================================================================="
Write-Host "SITE_ROOT=$SiteRoot"
Write-Host "RESULT_ROOT=$ResultRoot"
Write-Host "REPAIR_SCOPE=EXACTLY_TWO_PUBLIC_LABELS"

if (-not (Test-Path -LiteralPath $SiteRoot -PathType Container)) { throw "Site root missing: $SiteRoot" }
if (-not (Test-Path -LiteralPath (Join-Path $SiteRoot "index.html") -PathType Leaf)) { throw "index.html missing under $SiteRoot" }

$Allowed = @('.html','.js','.css','.json','.md','.txt','.svelte','.ts','.tsx','.jsx')
$Files = Get-ChildItem -LiteralPath $SiteRoot -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
  $Allowed -contains $_.Extension.ToLowerInvariant() -and $_.FullName -notmatch '\\node_modules\\' -and $_.Length -le 10MB
}
$Repairs = @(
  [pscustomobject]@{Old='Multi-source ingestion';New='Multi-source evidence inputs';Id='W5_SAFE_MULTI_SOURCE'},
  [pscustomobject]@{Old='Lineage + release gates';New='Provenance + validation gates';Id='W5_SAFE_PROVENANCE'}
)
$MutationRows = New-Object System.Collections.Generic.List[object]
foreach ($File in $Files) {
  try { $Text = Get-Content -LiteralPath $File.FullName -Raw -ErrorAction Stop } catch { continue }
  $Original = $Text
  $HitIds = New-Object System.Collections.Generic.List[string]
  foreach ($Repair in $Repairs) {
    if ($Text.Contains($Repair.Old)) { $Text = $Text.Replace($Repair.Old,$Repair.New); $HitIds.Add($Repair.Id) }
  }
  if ($Text -ne $Original) {
    $Rel = $File.FullName.Substring($SiteRoot.Length).TrimStart('\\')
    $Backup = Join-Path $BackupRoot $Rel
    $BackupDir = Split-Path -Parent $Backup
    if ($BackupDir) { New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null }
    Copy-Item -LiteralPath $File.FullName -Destination $Backup -Force
    Set-Content -LiteralPath $File.FullName -Value $Text -Encoding UTF8
    $MutationRows.Add([pscustomobject]@{
      file=$File.FullName; backup=$Backup; repair_ids=($HitIds -join ';');
      old_sha256=(Get-FileHash -LiteralPath $Backup -Algorithm SHA256).Hash.ToLowerInvariant();
      new_sha256=(Get-FileHash -LiteralPath $File.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    })
  }
}
$MutationRows | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot 'W7_V005_MUTATIONS.csv')
Write-Host "FILES_MUTATED=$($MutationRows.Count)"

$CorpusBuilder = New-Object System.Text.StringBuilder
foreach ($File in $Files) {
  try { [void]$CorpusBuilder.AppendLine((Get-Content -LiteralPath $File.FullName -Raw -ErrorAction Stop)) } catch {}
  if ($CorpusBuilder.Length -gt 18000000) { break }
}
$Corpus=$CorpusBuilder.ToString()
$Checks=New-Object System.Collections.Generic.List[object]
function Add-Check([string]$Name,[string]$Status,[string]$Detail) {
  $Checks.Add([pscustomobject]@{check=$Name;status=$Status;detail=$Detail})
  Write-Host ($Name+'='+$Status+' :: '+$Detail)
}
Add-Check 'SITE_ROOT' 'PASS' $SiteRoot
Add-Check 'HYDRA_IDENTITY' ($(if($Corpus -match '\bHYDRA\b'){'PASS'}else{'FAIL'})) 'HYDRA'
Add-Check 'HERO_TITLE' ($(if($Corpus -match 'MARKET INTELLIGENCE DATA PLATFORM'){'PASS'}else{'FAIL'})) 'MARKET INTELLIGENCE DATA PLATFORM'
Add-Check 'TAGLINE' ($(if($Corpus -match 'Turn fragmented market data into traceable intelligence'){'PASS'}else{'FAIL'})) 'Turn fragmented market data into traceable intelligence.'
Add-Check 'BADGE_MULTI_SOURCE_EVIDENCE_INPUTS' ($(if($Corpus -match 'Multi-source evidence inputs'){'PASS'}else{'FAIL'})) 'W5-safe wording'
Add-Check 'BADGE_CONTRACT_BOUND_HANDOFFS' ($(if($Corpus -match 'Contract-bound handoffs'){'PASS'}else{'FAIL'})) 'Contract-bound handoffs'
Add-Check 'BADGE_PROVENANCE_VALIDATION_GATES' ($(if($Corpus -match 'Provenance \+ validation gates'){'PASS'}else{'FAIL'})) 'W5-safe wording'
Add-Check 'STALE_MULTI_SOURCE_INGESTION' ($(if($Corpus -notmatch 'Multi-source ingestion'){'PASS'}else{'FAIL'})) 'stale phrase absent'
Add-Check 'STALE_LINEAGE_RELEASE_GATES' ($(if($Corpus -notmatch 'Lineage \+ release gates'){'PASS'}else{'FAIL'})) 'stale phrase absent'
Add-Check 'PROOF_ENTRYPOINT' ($(if($Corpus -match 'Technical Proof|Inspect Technical Proof'){'PASS'}else{'FAIL'})) 'Technical Proof'
Add-Check 'GITHUB_LINK' ($(if($Corpus -match 'https://github\.com/HYDRADATAAI/hydra-website'){'PASS'}else{'FAIL'})) 'https://github.com/HYDRADATAAI/hydra-website'

$HtmlFiles=Get-ChildItem -LiteralPath $SiteRoot -Recurse -File -Filter '*.html' -ErrorAction SilentlyContinue
$PlaceholderCount=0;$MissingLocal=New-Object System.Collections.Generic.List[object];$ViewportFound=$false
foreach($Html in $HtmlFiles){
  $T=Get-Content -LiteralPath $Html.FullName -Raw -ErrorAction SilentlyContinue
  if($T -match '<meta[^>]+name=["'']viewport["'']'){$ViewportFound=$true}
  $PlaceholderCount += ([regex]::Matches($T,'href\s*=\s*["''](?:\s*|#|javascript:void\(0\);?|javascript:;?)["'']','IgnoreCase')).Count
  foreach($M in [regex]::Matches($T,'(?:src|href)\s*=\s*["'']([^"'']+)["'']','IgnoreCase')){
    $Ref=$M.Groups[1].Value
    if(-not $Ref -or $Ref.StartsWith('#') -or $Ref -match '^(https?:|mailto:|tel:|data:|javascript:)'){continue}
    $Clean=($Ref -split '[?#]')[0]; if(-not $Clean){continue}
    if($Clean.StartsWith('/')){$Target=Join-Path $SiteRoot $Clean.TrimStart('/')}else{$Target=Join-Path $Html.Directory.FullName $Clean}
    if(-not (Test-Path -LiteralPath $Target)){$MissingLocal.Add([pscustomobject]@{page=$Html.FullName;ref=$Ref;target=$Target})}
  }
}
Add-Check 'VIEWPORT_META' ($(if($ViewportFound){'PASS'}else{'FAIL'})) 'responsive viewport'
Add-Check 'PLACEHOLDER_LINKS' ($(if($PlaceholderCount -eq 0){'PASS'}else{'FAIL'})) ('count='+$PlaceholderCount)
Add-Check 'LOCAL_ASSETS' ($(if($MissingLocal.Count -eq 0){'PASS'}else{'FAIL'})) ('missing='+$MissingLocal.Count)
if($MissingLocal.Count -gt 0){$MissingLocal|Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot 'MISSING_LOCAL_ASSETS.csv')}

function Convert-DomToNormalizedText([string]$Html){
  if(-not $Html){return ''}
  $x=[regex]::Replace($Html,'<script\b[^>]*>.*?</script>',' ','IgnoreCase,Singleline')
  $x=[regex]::Replace($x,'<style\b[^>]*>.*?</style>',' ','IgnoreCase,Singleline')
  $x=[regex]::Replace($x,'<[^>]+>',' ')
  $x=[System.Net.WebUtility]::HtmlDecode($x)
  return ([regex]::Replace($x,'\s+',' ')).Trim()
}
$Browser=$null
foreach($Candidate in @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
)){if($Candidate -and (Test-Path -LiteralPath $Candidate)){$Browser=$Candidate;break}}
$Python=$null;if(Get-Command py -ErrorAction SilentlyContinue){$Python='py'}elseif(Get-Command python -ErrorAction SilentlyContinue){$Python='python'}
$ViewportRows=New-Object System.Collections.Generic.List[object];$BrowserOverall='BLOCKED'
if($Browser -and $Python){
  $Port=18785;$ServerOut=Join-Path $ResultRoot 'HTTP_SERVER.stdout.log';$ServerErr=Join-Path $ResultRoot 'HTTP_SERVER.stderr.log'
  $Server=Start-Process -FilePath $Python -ArgumentList @('-m','http.server',$Port,'--bind','127.0.0.1','--directory',$SiteRoot) -PassThru -WindowStyle Hidden -RedirectStandardOutput $ServerOut -RedirectStandardError $ServerErr
  Start-Sleep -Seconds 2
  try{
    $Url="http://127.0.0.1:$Port/index.html"
    foreach($Vp in @([pscustomobject]@{Name='DESKTOP';W=1440;H=1000},[pscustomobject]@{Name='TABLET';W=820;H=1180},[pscustomobject]@{Name='MOBILE';W=390;H=844})){
      $Stdout=Join-Path $ResultRoot ('CHROME_'+$Vp.Name+'.stdout.txt');$Stderr=Join-Path $ResultRoot ('CHROME_'+$Vp.Name+'.stderr.txt');$Screen=Join-Path $ResultRoot ('SCREENSHOT_'+$Vp.Name+'.png')
      $Args=@('--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking',('--window-size='+$Vp.W+','+$Vp.H),'--virtual-time-budget=8000',('--screenshot='+$Screen),'--dump-dom',$Url)
      $P=Start-Process -FilePath $Browser -ArgumentList $Args -PassThru -Wait -WindowStyle Hidden -RedirectStandardOutput $Stdout -RedirectStandardError $Stderr
      $Dom='';if(Test-Path -LiteralPath $Stdout){$Dom=Get-Content -LiteralPath $Stdout -Raw -ErrorAction SilentlyContinue}
      $Visible=Convert-DomToNormalizedText $Dom
      $Visible|Set-Content -LiteralPath (Join-Path $ResultRoot ('VISIBLE_TEXT_'+$Vp.Name+'.txt')) -Encoding UTF8
      $Hero=$Visible -match 'MARKET INTELLIGENCE DATA PLATFORM';$Tag=$Visible -match 'Turn fragmented market data into traceable intelligence';$M=$Visible -match 'Multi-source evidence inputs';$C=$Visible -match 'Contract-bound handoffs';$Pr=$Visible -match 'Provenance \+ validation gates'
      $Status=$(if($Hero -and $Tag -and $M -and $C -and $Pr){'PASS'}else{'FAIL'})
      $ViewportRows.Add([pscustomobject]@{viewport=$Vp.Name;chrome_exit_code=$P.ExitCode;dom_length=$(if($Dom){$Dom.Length}else{0});visible_text_length=$(if($Visible){$Visible.Length}else{0});hero=$Hero;tagline=$Tag;safe_multi_source=$M;contract_bound=$C;safe_provenance=$Pr;screenshot_exists=(Test-Path -LiteralPath $Screen);status=$Status})
    }
    $ViewportRows|Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot 'BROWSER_VIEWPORT_RESULTS.csv')
    $BrowserOverall=$(if(@($ViewportRows|Where-Object{$_.status -eq 'FAIL'}).Count -eq 0){'PASS'}else{'FAIL'})
  }finally{Stop-Process -Id $Server.Id -Force -ErrorAction SilentlyContinue}
}
Add-Check 'BROWSER_RENDER' $BrowserOverall ('browser='+$(if($Browser){$Browser}else{'NOT_FOUND'}))
foreach($Name in @('DESKTOP','TABLET','MOBILE')){$R=$ViewportRows|Where-Object{$_.viewport -eq $Name}|Select-Object -First 1;if($R){Add-Check $Name $R.status ('visible_text_length='+$R.visible_text_length+' screenshot='+$R.screenshot_exists)}else{Add-Check $Name 'BLOCKED' 'viewport not executed'}}

if(-not $PublicDeploymentUrl){if($env:HYDRA_PUBLIC_DEPLOYMENT_URL){$PublicDeploymentUrl=$env:HYDRA_PUBLIC_DEPLOYMENT_URL}elseif(Test-Path -LiteralPath (Join-Path $SiteRoot 'PUBLIC_DEPLOYMENT_URL.txt')){$PublicDeploymentUrl=(Get-Content -LiteralPath (Join-Path $SiteRoot 'PUBLIC_DEPLOYMENT_URL.txt') -Raw).Trim()}elseif(Test-Path -LiteralPath (Join-Path $SiteRoot 'CNAME')){$H=(Get-Content -LiteralPath (Join-Path $SiteRoot 'CNAME') -First 1).Trim();if($H -match '^[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'){$PublicDeploymentUrl='https://'+$H}}}
if($PublicDeploymentUrl -match '^https?://'){try{$Resp=Invoke-WebRequest -Uri $PublicDeploymentUrl -UseBasicParsing -TimeoutSec 20;$Ok=($Resp.StatusCode -ge 200 -and $Resp.StatusCode -lt 400 -and $Resp.Content -match '\bHYDRA\b');Add-Check 'PUBLIC_DEPLOYMENT' ($(if($Ok){'PASS'}else{'FAIL'})) ('url='+$PublicDeploymentUrl+' status='+$Resp.StatusCode)}catch{Add-Check 'PUBLIC_DEPLOYMENT' 'FAIL' ('url='+$PublicDeploymentUrl+' error='+$_.Exception.Message)}}else{Add-Check 'PUBLIC_DEPLOYMENT' 'BLOCKED' 'local V7 release can pass independently; no authoritative public deployment URL'}

$FailCount=@($Checks|Where-Object{$_.status -eq 'FAIL'}).Count;$BlockedCount=@($Checks|Where-Object{$_.status -eq 'BLOCKED'}).Count
$LocalCritical=@('SITE_ROOT','HYDRA_IDENTITY','HERO_TITLE','TAGLINE','BADGE_MULTI_SOURCE_EVIDENCE_INPUTS','BADGE_CONTRACT_BOUND_HANDOFFS','BADGE_PROVENANCE_VALIDATION_GATES','STALE_MULTI_SOURCE_INGESTION','STALE_LINEAGE_RELEASE_GATES','PROOF_ENTRYPOINT','GITHUB_LINK','VIEWPORT_META','PLACEHOLDER_LINKS','LOCAL_ASSETS','BROWSER_RENDER','DESKTOP','TABLET','MOBILE')
$LocalFailCount=@($Checks|Where-Object{($LocalCritical -contains $_.check) -and $_.status -eq 'FAIL'}).Count
if($LocalFailCount -gt 0){$Overall='FAIL_WITH_DEFECT'}elseif($FailCount -gt 0){$Overall='FAIL_WITH_DEFECT'}elseif($BlockedCount -gt 0){$Overall='PASS_LOCAL_BLOCKED_PUBLIC_DEPLOYMENT'}else{$Overall='PASS'}
$Receipt=[pscustomobject]@{version='W7_V005';generated_at=(Get-Date).ToString('o');site_root=$SiteRoot;files_mutated=$MutationRows.Count;fail_count=$FailCount;blocked_count=$BlockedCount;local_fail_count=$LocalFailCount;overall=$Overall;checks=$Checks}
$Receipt|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $ResultRoot 'W7_V005_RECEIPT.json') -Encoding UTF8
$Checks|Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot 'W7_V005_CHECKS.csv')
@('HYDRA W7 V005 BOUNDED COPY REPAIR + BROWSER RETEST',('SITE_ROOT='+$SiteRoot),('FILES_MUTATED='+$MutationRows.Count),('FAIL_COUNT='+$FailCount),('BLOCKED_COUNT='+$BlockedCount),('LOCAL_FAIL_COUNT='+$LocalFailCount),('OVERALL='+$Overall),('RESULT_ROOT='+$ResultRoot))|Set-Content -LiteralPath (Join-Path $ResultRoot 'W7_V005_SUMMARY.txt') -Encoding UTF8
$ResultZip=Join-Path $HOME ('Downloads\HYDRA_W7_V005_BOUNDED_REPAIR_RETEST_RESULT_'+$Stamp+'.zip');Compress-Archive -Path (Join-Path $ResultRoot '*') -DestinationPath $ResultZip -Force;$ResultHash=(Get-FileHash -LiteralPath $ResultZip -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host '====================================================================';Write-Host 'HYDRA W7 V005 VERDICT';Write-Host '====================================================================';Write-Host "SITE_ROOT=$SiteRoot";Write-Host "FILES_MUTATED=$($MutationRows.Count)";Write-Host "FAIL_COUNT=$FailCount";Write-Host "BLOCKED_COUNT=$BlockedCount";Write-Host "LOCAL_FAIL_COUNT=$LocalFailCount";Write-Host "OVERALL=$Overall";Write-Host "RESULT_ZIP=$ResultZip";Write-Host "RESULT_ZIP_SHA256=$ResultHash"
if($Overall -eq 'PASS'){exit 0}elseif($Overall -eq 'PASS_LOCAL_BLOCKED_PUBLIC_DEPLOYMENT'){exit 3}else{exit 2}

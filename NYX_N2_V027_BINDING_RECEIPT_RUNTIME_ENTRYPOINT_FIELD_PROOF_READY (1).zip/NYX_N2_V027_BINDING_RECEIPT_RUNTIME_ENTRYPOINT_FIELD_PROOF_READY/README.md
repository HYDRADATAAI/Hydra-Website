# NYX N2 V027 — Binding Receipt Runtime Entrypoint Field Proof

Parent defect:
`N2-DEFECT-022-RESOLVED-TARGETS-NON-EXECUTABLE`

Pinned V026 return SHA-256:
`f99515fbd8c0a022639fa7f3ea21c10f47dc7d87359b1463efa3e45ba93517e3`

Pinned selected Constraint surface:
`D:\HYDRA\phase0_surface_implementations\constraint_semantics_surface_v001.py`
SHA-256 `bc95f5f86142084234c2dc954c7f6f192bfcbbdcdf3f77ce53bedbda7262388c`

V026 proved:
- 7 raw resolved targets collapse to 2 unique targets
- 0 drift
- 0 strong entrypoints
- 0 runnable-unbound targets
- 0 explicit child entrypoints

V027 inspects binding receipts only.

A runtime entrypoint is accepted only when a receipt explicitly names a runner/entrypoint/
loader/launcher/executable/script/bootstrap/command field and that value resolves to a live
`.py`, `.ps1`, `.cmd`, or `.bat` file.

`selected_path`, `implementation_path`, target paths, receipt/proof fields, hashes and
candidate fields do NOT count as runtime-entrypoint authority.

No whole-tree search. No child traversal. No mutation.

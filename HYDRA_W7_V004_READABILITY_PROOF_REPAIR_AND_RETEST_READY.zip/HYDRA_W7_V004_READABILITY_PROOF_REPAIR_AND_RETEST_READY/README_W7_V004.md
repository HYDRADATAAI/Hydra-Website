# HYDRA W7 V004 — bounded website repair

Targets only the two defects proven by the V003 browser run:

- `W7-SITE-001_VISIBLE_TECHNICAL_PROOF_LABEL_ABSENT`
- `W7-SITE-002_TINY_TEXT_UNDER_11PX`

## Changes

1. Replaces the existing visible CTA text `EXPLORE THE SYSTEM` with `TECHNICAL PROOF`.
2. Raises explicit CSS font sizes below the W7 11px readability floor.
3. Installs a narrow runtime safeguard for only the exact nine micro-label texts reported by V003, and only when their computed font size remains below 11px.
4. Backs up every changed file under the W7 result directory.
5. Reruns the same V003 release gate.

## Explicitly not changed

- project claims;
- hero title/tagline;
- architecture;
- GitHub repository content;
- public deployment;
- data/ML/runtime systems.

If the retest becomes green locally but public deployment remains unproven, the correct result is expected to be `BLOCKED_PUBLIC_DEPLOYMENT_NOT_PROVEN`.

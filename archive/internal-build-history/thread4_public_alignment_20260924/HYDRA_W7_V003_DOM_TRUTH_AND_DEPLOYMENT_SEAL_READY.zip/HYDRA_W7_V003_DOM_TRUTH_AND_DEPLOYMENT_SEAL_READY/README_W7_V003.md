# HYDRA W7 V003 — DOM Truth + Deployment Seal

V003 is an auditor correction, not a website redesign.

## Corrects V002

- Static hero/tagline/badge checks now use parsed visible text, so inline markup such as
  `Turn fragmented market data into <span>traceable intelligence.</span>` is evaluated correctly.
- Browser output now prints every predicate capable of causing a viewport failure, including exact tiny-text findings.
- Public deployment may be discovered from an already-public GitHub repository only when the derived GitHub Pages URL actually returns HYDRA's exact title and tagline.
- No deployment is invented and no website copy is mutated.

## Default site

`D:\HYDRA_SITE\V7`

## Valid closure

- PASS_PUBLIC_SITE_RELEASE_SEAL
- FAIL_WITH_DEFECT
- BLOCKED_PUBLIC_DEPLOYMENT_NOT_PROVEN
- BLOCKED_BROWSER_RENDER_NOT_PROVEN
- BLOCKED_EXTERNAL_LINK_REACHABILITY_NOT_PROVEN

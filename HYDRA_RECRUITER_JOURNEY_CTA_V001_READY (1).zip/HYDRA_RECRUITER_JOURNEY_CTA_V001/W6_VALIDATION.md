# W6 VALIDATION

- `four_internal_routes_declared`: **PASS**
- `combined_target_proof_exists`: **PASS**
- `combined_target_case_exists`: **PASS**
- `combined_target_architecture_exists`: **PASS**
- `combined_target_index_exists`: **PASS**
- `w2_embedded`: **PASS**
- `w3_embedded`: **PASS**
- `w4_embedded`: **PASS**
- `w5_embedded`: **PASS**
- `github_unbound_truthful`: **PASS**
- `linkedin_unbound_truthful`: **PASS**
- `contact_unbound_truthful`: **PASS**
- `no_fake_github_url`: **PASS**
- `no_fake_linkedin_url`: **PASS**
- `no_fake_mailto`: **PASS**
- `frozen_hero_unchanged_note`: **PASS**

`W6_VALIDATION=PASS`

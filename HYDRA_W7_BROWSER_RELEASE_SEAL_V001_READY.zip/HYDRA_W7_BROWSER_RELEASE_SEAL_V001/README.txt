HYDRA W7 BROWSER RELEASE SEAL V001

Read-only against D:\HYDRA_SITE\V7. It copies the site to an instrumented temporary mirror.
Checks every HTML page at desktop/tablet/mobile sizes, JS/runtime errors, failed resources,
horizontal overflow, broken images, basic readability, screenshots, GitHub reachability,
and optionally a real public deployment URL.

Without -PublicUrl, a clean browser run intentionally returns:
BROWSER_LOCAL_VERDICT=PASS_BROWSER_LOCAL
PUBLIC_RELEASE_SEAL=BLOCKED

That means the browser checks are green but public deployment has not yet been proven.

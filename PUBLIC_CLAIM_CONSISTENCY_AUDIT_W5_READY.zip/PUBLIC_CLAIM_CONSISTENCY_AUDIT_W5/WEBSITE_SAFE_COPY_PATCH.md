# WEBSITE SAFE COPY PATCH — W5

This is the claim-safe website wording that matches the W5 GitHub front door.

## Keep exactly

**HYDRA / MARKET INTELLIGENCE DATA PLATFORM**

**Turn fragmented market data into traceable intelligence.**

## Hero capability badges

Use:

- **Multi-source evidence inputs**
- **Contract-bound handoffs**
- **Provenance + validation gates**

The previous phrases **Multi-source ingestion** and **Lineage + release gates** were slightly stronger than the compact public proof set could independently demonstrate. These replacements preserve the technical story without implying a proven public production ingestion or release runtime.

## Recruiter explainer

Use this claim-safe version:

> HYDRA is an engineering project for a market-intelligence data platform. It models market, reference, and history inputs through controlled normalization, deterministic identity, contract and authority checks, provenance/history linkage, and downstream intelligence structures. Executed test receipts demonstrate identity invariants, cross-stage seam behavior, baseline non-mutation, and fail-closed authority enforcement. Representative constraint examples are labeled non-live.

## Architecture labels

Use:

`Market / reference / history inputs`
→ `source normalization`
→ `identity resolution`
→ `contract + authority gate`
→ `data core`
→ `provenance + history`
→ `constraint / intelligence structures`

Add the side-path:

`missing authority → BLOCK / QUARANTINE`

## Do not claim yet

Do not add public claims of:

- public production ingestion runtime;
- production-scale deployment;
- completed public release seal;
- live market inference;
- live ML / GenAI inference;
- public runnable demo;
- unsupported throughput, record-count, or uptime numbers.

W7 is the proper place to prove deployment, routing, responsive behavior, links, and release readiness.

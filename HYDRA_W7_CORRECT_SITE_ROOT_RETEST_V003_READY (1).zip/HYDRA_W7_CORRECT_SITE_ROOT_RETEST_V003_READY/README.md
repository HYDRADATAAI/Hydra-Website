# HYDRA W7 Correct Site Root Retest V003

Repairs the W7 auditor defect that selected Gradio under `site-packages` instead of the recruiter-facing HYDRA site.

The resolver excludes dependency/runtime trees and requires the exact HYDRA recruiter hero + tagline before a directory may become `SITE_ROOT`.

This retest is read-only and uses the W5-safe labels:

- Multi-source evidence inputs
- Contract-bound handoffs
- Provenance + validation gates

It does not infer `gradio.app`, invent a GitHub URL, or mutate HYDRA.

## V003 parser correction

V002 never executed because Windows PowerShell 5.1 rejected:

`Sort-Object Score -Descending,SiteRoot`

V003 uses the compatible form:

`Sort-Object -Property @{Expression='Score';Descending=$true}, @{Expression='SiteRoot';Descending=$false}`

No HYDRA mutation occurred in V002 because the script failed during parse.

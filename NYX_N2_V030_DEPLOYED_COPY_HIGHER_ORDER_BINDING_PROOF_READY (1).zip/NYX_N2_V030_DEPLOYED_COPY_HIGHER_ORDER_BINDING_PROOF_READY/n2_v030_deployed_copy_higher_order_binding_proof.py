
from __future__ import annotations
import argparse, ast, hashlib, json, ntpath, os, re, shutil, tempfile, warnings
from pathlib import Path
from typing import Any

warnings.filterwarnings("ignore", category=SyntaxWarning)

EXPECTED_V029_SHA256 = "558f3518a9da4ca48e5053e314f3fd6e20e95efd97415b2a30b35d5398e5a3a5"
EXPECTED_WRITER_SHA256 = "84df9a26f4b210fa9feae4cbea2189097c784fdf290f27227fb472b37cb60469"
WRITER_PATHS = ['D:\\HYDRA\\execution_runtime\\nyx_175_phase0_real_v001\\implementation_discovery_tool\\tools\\scan_hydra_implementation.py', 'D:\\HYDRA\\execution_runtime\\nyx_175_phase0_real_v001\\phase0_binding_review\\_tools_discovery\\tools\\scan_hydra_implementation.py', 'D:\\HYDRA\\execution_runtime\\NYX_PHASE0_HOST_PREFLIGHT_20260906_165307\\nyx_runtime\\phase0_discovery_workspace\\implementation_discovery_tool\\tools\\scan_hydra_implementation.py']

TEXT_EXTS = {".py",".ps1",".cmd",".bat",".json",".yaml",".yml",".toml",".ini",".cfg",".txt"}
EXEC_EXTS = {".py",".ps1",".cmd",".bat"}
MANIFEST_EXTS = {".json",".yaml",".yml",".toml",".ini",".cfg"}

EXCLUDED_PARTS = {
    ".git",".hg",".svn","__pycache__",".pytest_cache",".mypy_cache",
    "node_modules","site-packages","dist-packages",".venv","venv","env",
    "archive","archives","_archive","backup","backups","_backup",
    "stash","_stash","hydra stash","temp","tmp","downloads",
    "test_results","fixtures","fixture","quarantine","tests","test",
}
EXCLUDED_SUBSTRINGS = {"_zip_control_layer_temp","_verify_","verification"}

ENTRY_NAME_RX = re.compile(
    r"(?i)(^run[_-]|runner|launcher|bootstrap|entrypoint|driver|pipeline|preflight|bind|discover|scan)"
)
MANIFEST_NAME_RX = re.compile(
    r"(?i)(manifest|binding|selection|runtime|entrypoint|runner|launcher|package|receipt)"
)

PY_EXEC_PRIMITIVES = {
    "subprocess.run","subprocess.Popen","subprocess.call","os.system",
    "runpy.run_path","runpy.run_module",
}
PS_EXEC_RX = re.compile(
    r"(?:\bpython(?:\.exe)?\b|\bpy(?:\.exe)?\b|"
    r"\bpowershell(?:\.exe)?\b.*?-File|"
    r"\bStart-Process\b|^\s*&\s+)",
    flags=re.IGNORECASE | re.MULTILINE,
)
CMD_EXEC_RX = re.compile(
    r"^\s*(?:call\s+|python(?:\.exe)?\s+|py(?:\.exe)?\s+|powershell(?:\.exe)?\s+)",
    flags=re.IGNORECASE | re.MULTILINE,
)

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()

def canon(v: str) -> str:
    s=str(v).strip().strip("'\"").replace("/","\\")
    while "\\\\" in s:
        s=s.replace("\\\\","\\")
    s=ntpath.normpath(s)
    if re.match(r"^[A-Za-z]:",s):
        s=s[0].upper()+s[1:]
    return s.casefold()

def display(v: str) -> str:
    s=str(v).strip().strip("'\"").replace("/","\\")
    while "\\\\" in s:
        s=s.replace("\\\\","\\")
    s=ntpath.normpath(s)
    if re.match(r"^[A-Za-z]:",s):
        s=s[0].upper()+s[1:]
    return s

def is_excluded(path: Path, root: Path) -> bool:
    try: rel=path.relative_to(root)
    except Exception: rel=path
    parts=[p.casefold() for p in rel.parts]
    for part in parts[:-1]:
        if part in EXCLUDED_PARTS:return True
        if any(x in part for x in EXCLUDED_SUBSTRINGS):return True
        if part.startswith("_nyx_") and "verify" in part:return True
    return False

def dotted(node):
    if isinstance(node,ast.Name):return node.id
    if isinstance(node,ast.Attribute):
        base=dotted(node.value)
        return (base+"."+node.attr) if base else node.attr
    return None

def python_exec_markers(path:Path):
    try:
        text=path.read_text(encoding="utf-8",errors="ignore")
        with warnings.catch_warnings():
            warnings.simplefilter("ignore",SyntaxWarning)
            tree=ast.parse(text)
    except Exception:
        return []
    rows=[]
    for n in ast.walk(tree):
        if isinstance(n,ast.Call):
            fn=dotted(n.func) or ""
            if fn in PY_EXEC_PRIMITIVES:
                rows.append({"primitive":fn,"lineno":getattr(n,"lineno",None)})
    return rows

def exec_markers(path:Path,text:str):
    ext=path.suffix.casefold()
    if ext==".py":
        return python_exec_markers(path)
    if ext==".ps1":
        return [{"match":m.group(0)[:200]} for m in PS_EXEC_RX.finditer(text)]
    if ext in {".cmd",".bat"}:
        return [{"match":m.group(0)[:200]} for m in CMD_EXEC_RX.finditer(text)]
    return []

def package_root(writer:Path) -> Path:
    # The three proven writers all live in <package>/tools/scan_hydra_implementation.py.
    if writer.parent.name.casefold()=="tools":
        return writer.parent.parent
    return writer.parent

def inventory_package(root:Path, package:Path, writer:Path):
    rows=[]
    if not package.is_dir():
        return rows
    for cur,dirs,files in os.walk(package,topdown=True):
        cp=Path(cur)
        dirs[:]=[d for d in dirs if not is_excluded(cp/d/"__probe__.py",root)]
        for fn in files:
            p=cp/fn
            if p==writer or p.suffix.casefold() not in TEXT_EXTS or is_excluded(p,root):
                continue
            try:
                if p.stat().st_size>5_000_000:
                    continue
                text=p.read_text(encoding="utf-8",errors="ignore")
            except Exception:
                continue

            markers=exec_markers(p,text)
            executable=False
            reason=[]
            if p.suffix.casefold() in EXEC_EXTS:
                if ENTRY_NAME_RX.search(p.name):
                    executable=True;reason.append("ENTRYPOINT_FILENAME")
                if markers:
                    executable=True;reason.append("EXECUTION_PRIMITIVE")
            manifest = p.suffix.casefold() in MANIFEST_EXTS and bool(MANIFEST_NAME_RX.search(p.name))

            if executable or manifest:
                rows.append({
                    "path":str(p),
                    "sha256":sha256_file(p),
                    "relative_path":str(p.relative_to(package)),
                    "executable_entrypoint":executable,
                    "manifest_surface":manifest,
                    "reasons":reason,
                    "execution_markers":markers[:30],
                })
    return rows

def suffix_for_target(path:Path, package:Path):
    try:
        rel=path.relative_to(package)
        pkgname=package.name
        return canon(str(Path(pkgname)/rel))
    except Exception:
        return canon(path.name)

def inspect_external_binding(path:Path, root:Path, package:Path, targets:list[dict]):
    try:text=path.read_text(encoding="utf-8",errors="ignore")
    except Exception:return []

    markers=exec_markers(path,text)
    is_exec=path.suffix.casefold() in EXEC_EXTS and bool(markers)
    text_canon=canon(text)
    package_full=canon(str(package))
    package_name=package.name.casefold()

    rows=[]
    for t in targets:
        target=Path(t["path"])
        full=canon(str(target))
        rel_suffix=suffix_for_target(target,package)

        full_hit=full in text_canon
        relative_hit=rel_suffix in text_canon
        package_full_hit=package_full in text_canon
        package_name_hit=package_name in text.casefold()

        if not (full_hit or relative_hit or package_full_hit or package_name_hit):
            continue

        authority="MENTION_ONLY"
        if is_exec and full_hit:
            authority="EXACT_ENTRYPOINT_FULL_PATH_EXEC_BINDING"
        elif is_exec and relative_hit:
            authority="PACKAGE_RELATIVE_ENTRYPOINT_EXEC_BINDING"
        elif is_exec and package_full_hit and t["executable_entrypoint"]:
            authority="EXACT_PACKAGE_ROOT_EXEC_BINDING"
        elif is_exec and package_name_hit and t["executable_entrypoint"]:
            authority="PACKAGE_NAME_EXEC_MENTION_ONLY"

        rows.append({
            "package_root":str(package),
            "target_path":str(target),
            "target_sha256":t["sha256"],
            "target_executable_entrypoint":t["executable_entrypoint"],
            "referrer_path":str(path),
            "referrer_sha256":sha256_file(path),
            "execution_marker_count":len(markers),
            "execution_markers":markers[:30],
            "full_path_hit":full_hit,
            "relative_path_hit":relative_hit,
            "package_full_path_hit":package_full_hit,
            "package_name_hit":package_name_hit,
            "authority":authority,
        })
    return rows

def selftest():
    td=Path(tempfile.mkdtemp(prefix="n2v030_"))
    try:
        root=td/"HYDRA"
        package=root/"execution_runtime"/"ACTIVE"/"implementation_discovery_tool"
        tools=package/"tools"
        tools.mkdir(parents=True)
        writer=tools/"scan_hydra_implementation.py"
        writer.write_text("print('writer')\n",encoding="utf-8")
        runner=package/"RUN_DISCOVERY.ps1"
        runner.write_text("python .\\tools\\scan_hydra_implementation.py\n",encoding="utf-8")
        external=root/"RUN_ACTIVE.ps1"
        external.parent.mkdir(parents=True,exist_ok=True)
        external.write_text('powershell.exe -File "'+str(runner)+'"\n',encoding="utf-8")

        inv=inventory_package(root,package,writer)
        assert any(Path(x["path"]).name=="RUN_DISCOVERY.ps1" and x["executable_entrypoint"] for x in inv)
        refs=inspect_external_binding(external,root,package,inv)
        strong=[r for r in refs if r["authority"]=="EXACT_ENTRYPOINT_FULL_PATH_EXEC_BINDING"]
        assert strong
        print("N2_V030_SELFTEST=PASS")
        print("N2_V030_PACKAGE_LOCAL_ENTRYPOINT_INVENTORY=PASS")
        print("N2_V030_EXACT_EXTERNAL_BINDING_GATE=PASS")
        print("N2_V030_PACKAGE_NAME_ONLY_REJECTED=PASS")
        print("N2_V030_IDENTICAL_WRITER_HASH_NOT_OWNER_AUTHORITY=PASS")
    finally:
        shutil.rmtree(td,ignore_errors=True)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--hydra-root",default=r"D:\HYDRA")
    ap.add_argument("--v029-evidence")
    ap.add_argument("--output-dir")
    ap.add_argument("--selftest",action="store_true")
    args=ap.parse_args()

    if args.selftest:
        selftest();return 0

    root=Path(args.hydra_root);ev=Path(args.v029_evidence);outdir=Path(args.output_dir)
    if not root.is_dir():raise RuntimeError(f"HYDRA root missing: {root}")
    if not ev.is_file():raise RuntimeError(f"V029 evidence missing: {ev}")
    if sha256_file(ev)!=EXPECTED_V029_SHA256:raise RuntimeError("V029 evidence SHA256 mismatch")

    writers=[Path(p) for p in WRITER_PATHS]
    packages=[]
    for idx,w in enumerate(writers,1):
        if not w.is_file():raise RuntimeError(f"writer missing: {w}")
        wsha=sha256_file(w)
        if wsha!=EXPECTED_WRITER_SHA256:raise RuntimeError(f"writer hash drift: {w}")
        package=package_root(w)
        inventory=inventory_package(root,package,w)
        packages.append({
            "candidate_index":idx,
            "writer_path":str(w),
            "writer_sha256":wsha,
            "package_root":str(package),
            "package_exists":package.is_dir(),
            "local_surface_count":len(inventory),
            "local_surfaces":inventory,
        })

    # Search active tree for exact references to package-local entrypoints/manifests.
    bindings=[]
    files_seen=0
    eligible=0
    package_paths={canon(p["package_root"]) for p in packages}
    local_paths={canon(s["path"]) for p in packages for s in p["local_surfaces"]}

    for cur,dirs,files in os.walk(root,topdown=True):
        cp=Path(cur)
        dirs[:]=[d for d in dirs if not is_excluded(cp/d/"__probe__.py",root)]
        for fn in files:
            files_seen+=1
            p=cp/fn
            if p.suffix.casefold() not in TEXT_EXTS or is_excluded(p,root):
                continue
            if canon(str(p)) in local_paths:
                continue
            try:
                if p.stat().st_size>5_000_000:
                    continue
            except Exception:
                continue
            eligible+=1
            for package in packages:
                bindings.extend(inspect_external_binding(
                    p,root,Path(package["package_root"]),package["local_surfaces"]
                ))

    strong_authorities={
        "EXACT_ENTRYPOINT_FULL_PATH_EXEC_BINDING",
        "PACKAGE_RELATIVE_ENTRYPOINT_EXEC_BINDING",
        "EXACT_PACKAGE_ROOT_EXEC_BINDING",
    }
    strong=[b for b in bindings if b["authority"] in strong_authorities]
    mention=[b for b in bindings if b["authority"]=="MENTION_ONLY"]
    package_name_only=[b for b in bindings if b["authority"]=="PACKAGE_NAME_EXEC_MENTION_ONLY"]

    branch_receipts=[]
    for package in packages:
        pr=canon(package["package_root"])
        sb=[b for b in strong if canon(b["package_root"])==pr]
        branch_receipts.append({
            **package,
            "strong_external_binding_count":len(sb),
            "strong_external_bindings":sb,
        })

    active=[b for b in branch_receipts if b["strong_external_binding_count"]>0]

    if len(active)==1:
        status="UNIQUE_DEPLOYED_COPY_HIGHER_ORDER_BINDING_PROVEN"
        defect=None
        selected=active[0]
        next_action="PIN_ACTIVE_PACKAGE_BRANCH_AND_INSPECT_ITS_ORCHESTRATOR_RUNTIME_CONTRACT_ONLY"
    elif len(active)>1:
        status="MULTIPLE_DEPLOYED_COPY_HIGHER_ORDER_BINDINGS_PROVEN"
        defect="N2-DEFECT-026-DEPLOYED-COPY-HIGHER-ORDER-BINDING-AMBIGUOUS"
        selected=None
        next_action="STOP_NO_MUTATION_MULTIPLE_PACKAGE_BRANCHES_ARE_EXTERNALLY_BOUND"
    else:
        status="NO_DEPLOYED_COPY_HIGHER_ORDER_BINDING_PROVEN"
        defect="N2-DEFECT-026-DEPLOYED-COPY-HIGHER-ORDER-BINDING-ABSENT"
        selected=None
        next_action="STOP_NO_MUTATION_NO_EXTERNAL_PACKAGE_RUNNER_BINDING_PROVES_ACTIVE_COPY"

    result={
        "version":"N2_V030_DEPLOYED_COPY_HIGHER_ORDER_BINDING_PROOF",
        "parent_defect":"N2-DEFECT-025-RECEIPT-WRITER-ACTIVE-COPY-NOT-PROVEN",
        "v029_sha256":sha256_file(ev),
        "hydra_root":str(root),
        "writer_sha256":EXPECTED_WRITER_SHA256,
        "candidate_count":len(writers),
        "files_seen":files_seen,
        "eligible_files_scanned":eligible,
        "package_branch_receipts":branch_receipts,
        "reference_count":len(bindings),
        "strong_external_binding_count":len(strong),
        "mention_only_count":len(mention),
        "package_name_exec_mention_count":len(package_name_only),
        "selected_package_branch":selected,
        "status":status,
        "defect_id":defect,
        "next_action":next_action,
        "read_only":True,
        "baseline_mutated":False,
        "canonical_core_mutated":False,
        "constraint_semantics_mutated":False,
        "n2_mutated":False,
        "writer_hash_owner_authority":"REJECTED",
        "mtime_authority":"NONE",
        "basename_popularity_authority":"REJECTED",
        "path_name_activity_inference":"REJECTED",
    }

    outdir.mkdir(parents=True,exist_ok=True)
    (outdir/"N2_V030_DEPLOYED_COPY_HIGHER_ORDER_BINDING_PROOF.json").write_text(
        json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")

    print("="*60)
    print("NYX N2 V030 - DEPLOYED COPY HIGHER-ORDER BINDING PROOF")
    print("="*60)
    print("FINAL="+status)
    print("PARENT_DEFECT="+result["parent_defect"])
    print("DEFECT_ID="+(defect or "NONE"))
    print("CANDIDATE_COUNT="+str(len(writers)))
    print("FILES_SEEN="+str(files_seen))
    print("ELIGIBLE_FILES_SCANNED="+str(eligible))
    print("REFERENCE_COUNT="+str(len(bindings)))
    print("STRONG_EXTERNAL_BINDING_COUNT="+str(len(strong)))
    print("MENTION_ONLY_COUNT="+str(len(mention)))
    print("PACKAGE_NAME_EXEC_MENTION_COUNT="+str(len(package_name_only)))

    for row in branch_receipts:
        i=row["candidate_index"]
        print(f"BRANCH_{i:02d}_PACKAGE_ROOT="+row["package_root"])
        print(f"BRANCH_{i:02d}_LOCAL_SURFACE_COUNT="+str(row["local_surface_count"]))
        print(f"BRANCH_{i:02d}_STRONG_EXTERNAL_BINDING_COUNT="+str(row["strong_external_binding_count"]))
        for j,b in enumerate(row["strong_external_bindings"][:10],1):
            print(f"BRANCH_{i:02d}_BINDING_{j:02d}_TARGET="+b["target_path"])
            print(f"BRANCH_{i:02d}_BINDING_{j:02d}_REFERRER="+b["referrer_path"])
            print(f"BRANCH_{i:02d}_BINDING_{j:02d}_AUTHORITY="+b["authority"])

    if selected:
        print("SELECTED_PACKAGE_ROOT="+selected["package_root"])
        print("SELECTED_WRITER_PATH="+selected["writer_path"])
        print("SELECTED_WRITER_SHA256="+selected["writer_sha256"])

    print("READ_ONLY=TRUE")
    print("BASELINE_MUTATED=FALSE")
    print("CANONICAL_CORE_MUTATED=FALSE")
    print("CONSTRAINT_SEMANTICS_MUTATED=FALSE")
    print("N2_MUTATED=FALSE")
    print("WRITER_HASH_OWNER_AUTHORITY=REJECTED")
    print("NO_MTIME_AUTHORITY=TRUE")
    print("BASENAME_POPULARITY_AUTHORITY=REJECTED")
    print("PATH_NAME_ACTIVITY_INFERENCE=REJECTED")
    print("NEXT_ACTION="+next_action)
    return 0

if __name__=="__main__":
    raise SystemExit(main())

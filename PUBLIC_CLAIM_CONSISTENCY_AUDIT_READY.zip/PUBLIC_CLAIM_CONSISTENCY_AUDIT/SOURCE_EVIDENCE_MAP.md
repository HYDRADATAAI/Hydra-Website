# Source evidence map

## E1 — Real options canonicalization

Source: historical HYDRA options canonicalizer v0.2.2 receipt.

Public-safe facts:
- `overall_status=PASS`
- `source_records_discovered=3353`
- `source_records_loaded=3353`
- `source_records_error=0`
- `rows_in_total=17766662`
- `canonical_rows_written=17766662`
- source manifest and quality-summary paths were emitted.

Scope: **REAL HISTORICAL DATA PROCESSING**.

## E2 — CI-TEST-005 lineage/replay

Public-safe facts:
- exact replay match
- stable lineage digest
- reverse trace complete
- why trace complete
- blocker behavior retained
- sealed baseline unchanged

Scope: **SYNTHETIC / SHADOW INTEGRATION**.

## E3 — CI-TEST-004 repair/rerun

Public-safe facts:
- `PASS_REPAIRED_CI_TEST_004`
- T1→T5 path pass
- zero fabricated historical mapping claims
- frozen baseline immutability pass
- failure count 0 after bounded repair

Scope: **SYNTHETIC / SHADOW INTEGRATION**.

## E4 — CI-TEST-008 authority rejection

Public-safe facts:
- native T5→T6 contract pinned
- five semantic fields missing across eligible candidates
- no ready candidate could satisfy the contract without fabrication
- `semantic_values_invented=false`
- blocked/failed rather than fabricated green

Scope: **SYNTHETIC / SHADOW INTEGRATION**.

## E5 — N1 semantic authority rules

Public-safe rules:
- classification may refine an existing Constraint but may not create one
- classifier may not mint canonical identity
- pricing pressure does not automatically imply shortage
- physical availability remains distinct from qualified availability
- ambiguity/unknown states are valid

Scope: **GOVERNED SEMANTIC CONTRACT / REPRESENTATIVE PUBLIC CASE**.

param(
  [string]$HydraRoot = "D:\HYDRA",
  [string]$SiteRoot = ""
)
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$ResultRoot = Join-Path $HydraRoot ("WEBSITE_TEST_RESULTS\W7_PUBLIC_SITE_RELEASE_SEAL_" + $Stamp)
New-Item -ItemType Directory -Force -Path $ResultRoot | Out-Null

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "HYDRA W7 - PUBLIC SITE RELEASE SEAL" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "HYDRA_ROOT=$HydraRoot"
if ($SiteRoot) { Write-Host "SITE_ROOT_OVERRIDE=$SiteRoot" }
Write-Host "RESULT_ROOT=$ResultRoot"

$Python = Get-Command python -ErrorAction SilentlyContinue
if (-not $Python) { $Python = Get-Command py -ErrorAction SilentlyContinue }
if (-not $Python) { throw "Python not found in PATH." }

$ArgsList = @(
  (Join-Path $Here "w7_public_site_release_seal.py"),
  "--hydra-root", $HydraRoot,
  "--result-root", $ResultRoot,
  "--repair-safe"
)
if ($SiteRoot) { $ArgsList += @("--site-root",$SiteRoot) }

& $Python.Source @ArgsList
$AuditExit = $LASTEXITCODE

$Downloads = Join-Path $HOME "Downloads"
$ResultZip = Join-Path $Downloads ("HYDRA_W7_PUBLIC_SITE_RELEASE_SEAL_RESULT_" + $Stamp + ".zip")
if (Test-Path $ResultZip) { Remove-Item $ResultZip -Force }
Compress-Archive -Path (Join-Path $ResultRoot "*") -DestinationPath $ResultZip -CompressionLevel Optimal
$Hash = (Get-FileHash $ResultZip -Algorithm SHA256).Hash.ToLowerInvariant()
"$Hash  $([IO.Path]::GetFileName($ResultZip))" | Set-Content ($ResultZip + ".sha256.txt") -Encoding ASCII

Write-Host ""
Write-Host "RESULT_ZIP=$ResultZip" -ForegroundColor Green
Write-Host "RESULT_ZIP_SHA256=$Hash" -ForegroundColor Green
Write-Host "AUDITOR_EXIT_CODE=$AuditExit"
Write-Host "NEXT=Return the RESULT ZIP or console output to Nyx for final W7 adjudication." -ForegroundColor Yellow
exit $AuditExit

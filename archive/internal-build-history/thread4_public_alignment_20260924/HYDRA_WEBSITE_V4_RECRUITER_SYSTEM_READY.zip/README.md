# HYDRA Website V4 — Recruiter Clarity Pass

A dependency-free static portfolio site for HYDRA, positioned first as a serious data engineering project with a clearly separated future intelligence / generative-AI division.

## Pages

- `index.html` — recruiter-facing overview, divisions, engineering signals, case study, repository CTA
- `architecture.html` — interactive architecture explorer and clearly labeled AWS target mapping
- `lab.html` — interactive browser simulation of fail-closed contract / authority behavior
- `roadmap.html` — data → AWS → analytical operations → intelligence roadmap
- `404.html` — custom error page

## Design rules built into the site

1. Data engineering is the current center of gravity.
2. Generative AI is visible, but explicitly downstream and emerging.
3. No fake production claims.
4. AWS services are labeled as a target / learning architecture until a real HYDRA slice runs through them.
5. The project story emphasizes contracts, lineage, provenance, testing, deterministic artifacts, failure containment, and engineering judgment.

## Configure the public links

Open `site.config.js` and fill in the values you want:

```js
window.HYDRA_CONFIG = {
  ownerName: "Cody",
  repositoryUrl: "https://github.com/YOUR_ACCOUNT/YOUR_REPO",
  linkedinUrl: "",
  contactEmail: "",
  repositoryLabel: "Repository refresh in progress"
};
```

If `repositoryUrl` is blank, repository buttons and the repository section stay hidden rather than advertising an unfinished public surface.

## Preview locally

Simplest: double-click `index.html`.

Better: run `OPEN_HYDRA_SITE.ps1`. If Python is available, it starts a local web server at `http://localhost:8080/`. If Python is unavailable, it opens the static page directly.

## GitHub Pages

This package includes `.github/workflows/pages.yml`. After the site is placed in a GitHub repository:

1. Push the files to the default branch.
2. In GitHub: **Settings → Pages → Source → GitHub Actions**.
3. The included workflow publishes the static site.

No npm install, framework build, or external CDN is required.

## Suggested next content upgrades

- Add the real public GitHub URL.
- Replace conceptual architecture blocks with polished diagrams derived from the real HYDRA pipeline.
- Add one genuine AWS vertical slice after it is implemented and tested.
- Add two or three short defect case studies with before / repair / rerun evidence.
- Add selected screenshots of logs, receipts, tests, or dashboards only when they clarify the story.

## Technical notes

- Vanilla HTML / CSS / JavaScript.
- Responsive desktop and mobile layouts.
- Reduced-motion support.
- Keyboard-accessible navigation and form controls.
- No analytics, tracking, remote fonts, or third-party JavaScript.
- All visuals are local SVG/CSS.


## V4 recruiter-facing changes
- Hero identifies HYDRA immediately as a market-intelligence data engineering system.
- Future AWS / GenAI badges were removed from the homepage hero.
- Architecture visual now shows current market/reference/history flow into governed query/intelligence outputs.
- Unconfigured repository UI is hidden rather than advertising unfinished work.
- Homepage AI-future language was pushed out of the primary recruiter story; roadmap remains the place for future work.

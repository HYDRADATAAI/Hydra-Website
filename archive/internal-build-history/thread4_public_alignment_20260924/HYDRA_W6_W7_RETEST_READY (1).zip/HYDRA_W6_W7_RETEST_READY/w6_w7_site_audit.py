#!/usr/bin/env python3
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import unquote
import argparse, hashlib, json, re, sys

FROZEN = {
    "hero_title": "HYDRA / MARKET INTELLIGENCE DATA PLATFORM",
    "tagline": "Turn fragmented market data into traceable intelligence.",
}
APPROVED_BADGES = [
    "Multi-source ingestion",
    "Contract-bound handoffs",
    "Lineage + release gates",
]
FORBIDDEN_PUBLIC = [
    "AWS CLOUD · NEXT",
    "GEN AI · EMERGING",
    "AI FUTURE",
    "SIMULATED FLOW",
    "Independent engineering project",
]
EVIDENCE_KEYS = ["SCHEMA", "TRANSFORMATION", "CONTRACT", "LINEAGE", "TEST", "DEFECT", "OUTPUT"]
PROOF_CTA_TERMS = ["INSPECT TECHNICAL PROOF", "TECHNICAL PROOF"]
EVIDENCE_LABELS = ["INTEGRATED", "SYNTHETIC", "SHADOW", "SYNTHETIC_SHADOW_ONLY", "REPRESENTATIVE"]

class PageParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.images = []
        self.scripts = []
        self.styles = []
        self.ids = set()
        self.text = []
        self._in_script = False
        self._in_style = False

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if a.get("id"):
            self.ids.add(a["id"])
        if tag == "a":
            self.links.append({"href": a.get("href", ""), "text": ""})
        elif tag == "img":
            self.images.append({"src": a.get("src", ""), "alt": a.get("alt")})
        elif tag == "script":
            self._in_script = True
            if a.get("src"):
                self.scripts.append(a["src"])
        elif tag == "style":
            self._in_style = True
        elif tag == "link" and a.get("href"):
            rel = a.get("rel", "")
            if isinstance(rel, str) and "stylesheet" in rel.lower():
                self.styles.append(a["href"])

    def handle_endtag(self, tag):
        if tag == "script":
            self._in_script = False
        elif tag == "style":
            self._in_style = False

    def handle_data(self, data):
        if not self._in_script and not self._in_style:
            s = " ".join(data.split())
            if s:
                self.text.append(s)
                if self.links:
                    self.links[-1]["text"] += (" " + s)

def resolve_local(page, ref, site_root):
    ref = ref.split("?", 1)[0].split("#", 1)[0]
    if not ref:
        return page
    ref = unquote(ref)
    if ref.startswith("/"):
        p = site_root / ref.lstrip("/")
    else:
        p = page.parent / ref
    return p.resolve()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--site-root", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    root = Path(args.site_root).resolve()
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)

    if not root.exists() or not root.is_dir():
        print(f"ERROR: site root not found: {root}", file=sys.stderr)
        return 2

    html_files = sorted(root.rglob("*.html"))
    if not html_files:
        print("ERROR: no HTML files found", file=sys.stderr)
        return 3

    index = root / "index.html"
    if not index.exists():
        candidates = [p for p in html_files if p.name.lower() == "index.html"]
        index = candidates[0] if candidates else html_files[0]

    corpus_parts = []
    broken_internal = []
    placeholder_links = []
    external_links = []
    github_links = []
    contact_links = []
    missing_assets = []
    image_alt_missing = []
    anchor_failures = []

    for page in html_files:
        parser = PageParser()
        parser.feed(page.read_text(encoding="utf-8", errors="replace"))
        corpus_parts.append(" ".join(parser.text))
        rel = str(page.relative_to(root)).replace("\\", "/")

        for link in parser.links:
            href = (link.get("href") or "").strip()
            low = href.lower()
            if not href or href == "#" or low.startswith("javascript:") or "placeholder" in low:
                placeholder_links.append({"page": rel, "href": href, "text": link.get("text", "").strip()[:120]})
                continue
            if low.startswith(("mailto:", "tel:")):
                contact_links.append({"page": rel, "href": href})
                continue
            if low.startswith(("http://", "https://")):
                external_links.append({"page": rel, "href": href})
                if "github.com" in low:
                    github_links.append({"page": rel, "href": href})
                continue
            if low.startswith(("data:", "blob:")):
                continue

            target = resolve_local(page, href, root)
            frag = href.split("#", 1)[1] if "#" in href else None
            if target.is_dir():
                target = target / "index.html"
            if not target.exists():
                alts = [Path(str(target) + ".html"), target / "index.html"]
                existing = [a for a in alts if a.exists()]
                if not existing:
                    broken_internal.append({"page": rel, "href": href})
                    continue
                target = existing[0]

            if frag and target.suffix.lower() == ".html":
                pp = PageParser()
                pp.feed(target.read_text(encoding="utf-8", errors="replace"))
                if frag not in pp.ids:
                    anchor_failures.append({"page": rel, "href": href, "missing_id": frag})

        for img in parser.images:
            src = (img.get("src") or "").strip()
            if src and not src.lower().startswith(("http://", "https://", "data:", "blob:")):
                if not resolve_local(page, src, root).exists():
                    missing_assets.append({"page": rel, "type": "image", "src": src})
            if img.get("alt") is None or not str(img.get("alt")).strip():
                image_alt_missing.append({"page": rel, "src": src})

        for src in parser.scripts:
            if not src.lower().startswith(("http://", "https://", "data:", "blob:")):
                if not resolve_local(page, src, root).exists():
                    missing_assets.append({"page": rel, "type": "script", "src": src})

        for href in parser.styles:
            if not href.lower().startswith(("http://", "https://", "data:", "blob:")):
                if not resolve_local(page, href, root).exists():
                    missing_assets.append({"page": rel, "type": "stylesheet", "src": href})

    corpus = "\n".join(corpus_parts)
    corpus_upper = corpus.upper()

    ip = PageParser()
    ip.feed(index.read_text(encoding="utf-8", errors="replace"))
    index_visible = " ".join(ip.text)

    checks = []
    def add(name, status, detail):
        checks.append({"check": name, "status": status, "detail": detail})

    add("HERO_TITLE", "PASS" if FROZEN["hero_title"] in index_visible else "FAIL", FROZEN["hero_title"])
    add("TAGLINE", "PASS" if FROZEN["tagline"] in index_visible else "FAIL", FROZEN["tagline"])
    for b in APPROVED_BADGES:
        add("BADGE_" + re.sub(r"\W+", "_", b).strip("_").upper(), "PASS" if b in index_visible else "FAIL", b)
    for f in FORBIDDEN_PUBLIC:
        add("FORBIDDEN_" + re.sub(r"\W+", "_", f).strip("_").upper(), "PASS" if f not in corpus else "FAIL", f"must be absent: {f}")

    add("PROOF_ENTRYPOINT", "PASS" if any(t in corpus_upper for t in PROOF_CTA_TERMS) else "FAIL",
        "Technical Proof / Inspect Technical Proof")
    found = [k for k in EVIDENCE_KEYS if k in corpus_upper]
    add("EVIDENCE_INDEX", "PASS" if len(found) == len(EVIDENCE_KEYS) else "FAIL",
        f"found {len(found)}/7: {', '.join(found)}")
    labels = [k for k in EVIDENCE_LABELS if k in corpus_upper]
    add("EVIDENCE_LABELS_PRESENT", "PASS" if labels else "FAIL", "found: " + (", ".join(labels) if labels else "none"))

    lifecycle = [k for k in ["NORMALIZE", "CONTRACT", "LINEAGE", "VALIDATE"] if k in corpus_upper]
    block = ("DEFECT" in corpus_upper) or ("BLOCKED_BY_MISSING_AUTHORITY" in corpus_upper)
    add("ENGINEERING_LIFECYCLE", "PASS" if len(lifecycle) >= 3 and block else "FAIL",
        f"lifecycle={lifecycle}; defect_or_block={block}")

    add("GITHUB_LINK", "PASS" if github_links else "FAIL", f"github links={len(github_links)}")
    add("BROKEN_INTERNAL_LINKS", "PASS" if not broken_internal else "FAIL", f"count={len(broken_internal)}")
    add("BROKEN_ANCHORS", "PASS" if not anchor_failures else "FAIL", f"count={len(anchor_failures)}")
    add("PLACEHOLDER_LINKS", "PASS" if not placeholder_links else "FAIL", f"count={len(placeholder_links)}")
    add("MISSING_LOCAL_ASSETS", "PASS" if not missing_assets else "FAIL", f"count={len(missing_assets)}")
    add("IMAGE_ALT", "PASS" if not image_alt_missing else "WARN", f"missing alt={len(image_alt_missing)}")

    for name in ["DESKTOP_RENDER", "TABLET_RENDER", "MOBILE_RENDER", "JS_CONSOLE_ERRORS",
                 "VISUAL_OVERFLOW", "READABILITY", "PUBLIC_DEPLOYMENT_HTTP_STATUS"]:
        add(name, "REQUIRES_BROWSER", "static preflight cannot certify this")

    hard_fail = [c for c in checks if c["status"] == "FAIL"]
    report = {
        "artifact": "HYDRA_W6_W7_STATIC_PREFLIGHT",
        "site_root": str(root),
        "entrypoint": str(index.relative_to(root)).replace("\\", "/"),
        "html_file_count": len(html_files),
        "checks": checks,
        "counts": {
            "hard_failures": len(hard_fail),
            "external_links": len(external_links),
            "github_links": len(github_links),
            "contact_links": len(contact_links),
            "broken_internal_links": len(broken_internal),
            "broken_anchors": len(anchor_failures),
            "placeholder_links": len(placeholder_links),
            "missing_assets": len(missing_assets),
            "image_alt_missing": len(image_alt_missing),
        },
        "details": {
            "broken_internal_links": broken_internal,
            "broken_anchors": anchor_failures,
            "placeholder_links": placeholder_links,
            "missing_assets": missing_assets,
            "github_links": github_links,
            "external_links": external_links,
            "contact_links": contact_links,
            "image_alt_missing": image_alt_missing,
        },
        "static_verdict": "PASS_STATIC_PREFLIGHT" if not hard_fail else "FAIL_STATIC_PREFLIGHT",
        "release_note": "W7 final seal still requires browser/deployment checks."
    }
    (out / "W6_W7_STATIC_PREFLIGHT.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

    md = [
        "# HYDRA W6/W7 STATIC PREFLIGHT", "",
        f"`SITE_ROOT={root}`",
        f"`ENTRYPOINT={report['entrypoint']}`",
        f"`HTML_FILES={len(html_files)}`",
        f"`STATIC_VERDICT={report['static_verdict']}`", "",
        "## Checks", "",
        "| Check | Status | Detail |",
        "|---|---|---|",
    ]
    for c in checks:
        md.append(f"| {c['check']} | **{c['status']}** | {c['detail'].replace('|','/')} |")
    md += ["", "A static PASS does not equal the final W7 release seal.",
           "Browser rendering, console, overflow, readability, and public deployment checks remain required."]
    (out / "W6_W7_STATIC_PREFLIGHT.md").write_text("\n".join(md) + "\n", encoding="utf-8")

    summary = (
        f"STATIC_VERDICT={report['static_verdict']}\n"
        f"HARD_FAILURES={len(hard_fail)}\n"
        f"BROKEN_INTERNAL_LINKS={len(broken_internal)}\n"
        f"BROKEN_ANCHORS={len(anchor_failures)}\n"
        f"PLACEHOLDER_LINKS={len(placeholder_links)}\n"
        f"MISSING_ASSETS={len(missing_assets)}\n"
        f"GITHUB_LINKS={len(github_links)}\n"
        f"BROWSER_CHECKS_REQUIRED=YES\n"
    )
    (out / "W6_W7_STATIC_PREFLIGHT_SUMMARY.txt").write_text(summary, encoding="utf-8")
    print(summary, end="")
    return 0 if not hard_fail else 10

if __name__ == "__main__":
    raise SystemExit(main())

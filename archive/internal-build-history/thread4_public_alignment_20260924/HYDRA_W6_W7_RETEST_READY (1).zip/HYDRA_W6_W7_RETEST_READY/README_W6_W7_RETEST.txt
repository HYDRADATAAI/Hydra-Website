HYDRA W6/W7 RETEST READY

Purpose:
Read-only static preflight for the merged recruiter website.

Checks:
- frozen hero/title/tagline
- approved capability badges
- forbidden stale hero language
- Technical Proof entrypoint
- Evidence Index: SCHEMA / TRANSFORMATION / CONTRACT / LINEAGE / TEST / DEFECT / OUTPUT
- evidence-state labels
- engineering lifecycle + defect/block handling
- GitHub handoff
- internal links and anchors
- placeholder/dead-looking links
- local images/scripts/stylesheets
- missing image alt text

It does NOT falsely certify browser-only items.
Desktop/tablet/mobile rendering, JS console errors, visual overflow,
readability, and live public deployment remain W7 browser/deployment checks.

Run:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$HOME\Downloads\EXTRACT_AND_RUN_HYDRA_W6_W7_RETEST_FROM_DOWNLOADS.ps1" -SiteRoot "D:\PATH\TO\MERGED_SITE"

If SiteRoot is omitted, only a small bounded list of likely roots is checked.
The harness will not recursively scan all of D:\HYDRA.

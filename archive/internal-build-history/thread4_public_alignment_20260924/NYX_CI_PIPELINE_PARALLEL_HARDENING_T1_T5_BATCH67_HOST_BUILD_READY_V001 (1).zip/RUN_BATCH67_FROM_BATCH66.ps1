param(
    [string]$Batch66Dir = "",
    [string]$Receipt = "",
    [string]$OutputDir = ""
)
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path

function Test-B66Dir([string]$Dir) {
    if (-not $Dir -or -not (Test-Path -LiteralPath $Dir)) { return $false }
    $sealed = Join-Path $Dir 'NYX_CI_PIPELINE_PARALLEL_HARDENING_T1_T5_BATCH66_V001.zip'
    if (Test-Path -LiteralPath $sealed) { return $true }
    $hits = Get-ChildItem -LiteralPath $Dir -Filter 'NYX_CI_PIPELINE_PARALLEL_HARDENING_T1_T5_BATCH66_TRANSFER_*_OF_10_V001*.zip' -File -ErrorAction SilentlyContinue
    $parts = @{}
    foreach ($f in $hits) { if ($f.Name -match 'BATCH66_TRANSFER_(\d{2})_OF_10_V001') { $parts[[int]$Matches[1]] = $true } }
    return ($parts.Count -eq 10)
}

if (-not $Batch66Dir) {
    $candidates = @('D:\NYX_BATCH66_BUILD', (Join-Path $HOME 'Downloads\NYX_BATCH66_BUILD'), (Join-Path $HOME 'Downloads'), $Here, 'D:\')
    foreach ($c in $candidates) { if (Test-B66Dir $c) { $Batch66Dir = $c; break } }
}
if (-not (Test-B66Dir $Batch66Dir)) { throw 'Could not find sealed Batch66 ZIP or all ten Batch66 transfer ZIPs.' }

if (-not $Receipt) {
    $candidates = @((Join-Path $Batch66Dir 'BATCH66_SEAL_RECEIPT.json'), 'D:\NYX_BATCH66_BUILD\BATCH66_SEAL_RECEIPT.json', (Join-Path $HOME 'Downloads\NYX_BATCH66_BUILD\BATCH66_SEAL_RECEIPT.json'))
    foreach ($c in $candidates) { if (Test-Path -LiteralPath $c) { $Receipt = $c; break } }
}
if (-not $Receipt -or -not (Test-Path -LiteralPath $Receipt)) { throw 'BATCH66_SEAL_RECEIPT.json not found. Batch66 must finish sealing first.' }

if (-not $OutputDir) {
    if (Test-Path 'D:\') { $OutputDir = 'D:\NYX_BATCH67_BUILD' }
    else { $OutputDir = Join-Path $HOME 'Downloads\NYX_BATCH67_BUILD' }
}
New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
$Builder = Join-Path $Here 'build_batch67.py'
if (-not (Test-Path -LiteralPath $Builder)) { throw "Builder missing: $Builder" }

Write-Host '============================================================'
Write-Host 'NYX T1-T5 BATCH 66 RECEIPT-BOUND LOCAL SEAL BUILDER'
Write-Host '============================================================'
Write-Host "BATCH66_DIR=$Batch66Dir"
Write-Host "BATCH66_RECEIPT=$Receipt"
Write-Host "OUTPUT_DIR=$OutputDir"
Write-Host 'MODE=DELTA_WITH_EXACT_SEALED_PREDECESSOR'
Write-Host 'BOUNDARY=SYNTHETIC_SHADOW_ONLY'
Write-Host 'SCHEMA_PROFILE=2.49'
Write-Host ''

$Py = Get-Command py -ErrorAction SilentlyContinue
if ($Py) { & $Py.Source -3 $Builder --source-dir $Batch66Dir --receipt $Receipt --output-dir $OutputDir }
else {
    $Python = Get-Command python -ErrorAction SilentlyContinue
    if (-not $Python) { throw 'Python 3 is required. Neither py nor python was found on PATH.' }
    & $Python.Source $Builder --source-dir $Batch66Dir --receipt $Receipt --output-dir $OutputDir
}
if ($LASTEXITCODE -ne 0) { throw "Batch67 builder failed with exit code $LASTEXITCODE" }
$R = Join-Path $OutputDir 'BATCH67_SEAL_RECEIPT.json'
if (-not (Test-Path -LiteralPath $R)) { throw "Batch67 seal receipt missing: $R" }
Write-Host ''
Write-Host 'BATCH67 LOCAL BUILD COMPLETE'
Write-Host "RECEIPT=$R"

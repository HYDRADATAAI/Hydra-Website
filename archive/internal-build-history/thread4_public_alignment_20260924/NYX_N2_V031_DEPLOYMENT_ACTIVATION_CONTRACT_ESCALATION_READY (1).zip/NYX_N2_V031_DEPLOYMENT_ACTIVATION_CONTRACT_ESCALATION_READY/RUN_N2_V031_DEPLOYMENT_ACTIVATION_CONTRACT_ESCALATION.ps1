param(
    [string]$V030Evidence=""
)
$ErrorActionPreference="Stop"
Set-StrictMode -Version Latest

$ExpectedV030="d20f8456775e1cd5e6fce5acfc8be33573b40c48909a81b01aad7950dcca0687"
$WriterSha="84df9a26f4b210fa9feae4cbea2189097c784fdf290f27227fb472b37cb60469"

Write-Host "============================================================"
Write-Host "NYX N2 V031 - DEPLOYMENT ACTIVATION CONTRACT ESCALATION"
Write-Host "============================================================"
Write-Host "PARENT_DEFECT=N2-DEFECT-026-HIGHER-ORDER-DEPLOYMENT-BINDING-NOT-PROVEN"
Write-Host "DEFECT_ID=N2-DEFECT-027-DEPLOYMENT-ACTIVATION-CONTRACT-ABSENT"
Write-Host "FAILED_SEAM=PHASE0_DEPLOYMENT_ROOT_TO_RUNTIME_ACTIVATION"
Write-Host "OWNER_LANE=PHASE0_DEPLOYMENT_RUNTIME_ACTIVATION_OWNER"
Write-Host "N2_DISPOSITION=PARKED_PENDING_DEPLOYMENT_ACTIVATION_OWNER"
Write-Host "MUTATION_AUTHORIZED=NO"
Write-Host "PATCH_BOTH_DEPLOYMENT_ROOTS=FORBIDDEN"
Write-Host "MTIME_AUTHORITY=NO"
Write-Host "NEWEST_WINS=NO"
Write-Host "DIRECTORY_NAME_ACTIVITY_INFERENCE=NO"

$Downloads=Join-Path $env:USERPROFILE "Downloads"

if(-not $V030Evidence){
    $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "N2_V030_RETURN_PACKET_*.zip" -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending
    $Found=$null
    foreach($C in $Candidates){
        $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        if($H -eq $ExpectedV030){$Found=$C;break}
    }
    if(-not $Found){
        $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "*V030*RETURN*.zip" -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending
        foreach($C in $Candidates){
            $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            if($H -eq $ExpectedV030){$Found=$C;break}
        }
    }
    if(-not $Found){throw "Exact V030 return packet not found with SHA256=$ExpectedV030"}
    $V030Evidence=$Found.FullName
}

$Actual=(Get-FileHash -LiteralPath $V030Evidence -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host "V030_EVIDENCE=$V030Evidence"
Write-Host "V030_EVIDENCE_SHA256=$Actual"
if($Actual -ne $ExpectedV030){throw "V030 evidence hash mismatch."}
Write-Host "V030_EVIDENCE_HASH_VERIFIED=PASS"

$Roots=@(
    "D:\HYDRA\execution_runtime\nyx_175_phase0_real_v001",
    "D:\HYDRA\execution_runtime\nyx_phase0_host_preflight_20260906_165307"
)

foreach($Root in $Roots){
    if(-not (Test-Path -LiteralPath $Root -PathType Container)){
        throw "Pinned deployment root missing: $Root"
    }
    Write-Host "DEPLOYMENT_ROOT_PRESENT=$Root"
}

$WriterCopies=@(
    "D:\HYDRA\execution_runtime\nyx_175_phase0_real_v001\implementation_discovery_tool\tools\scan_hydra_implementation.py",
    "D:\HYDRA\execution_runtime\nyx_175_phase0_real_v001\phase0_binding_review\_tools_discovery\tools\scan_hydra_implementation.py",
    "D:\HYDRA\execution_runtime\NYX_PHASE0_HOST_PREFLIGHT_20260906_165307\nyx_runtime\phase0_discovery_workspace\implementation_discovery_tool\tools\scan_hydra_implementation.py"
)

foreach($Writer in $WriterCopies){
    if(-not (Test-Path -LiteralPath $Writer -PathType Leaf)){
        throw "Pinned writer copy missing: $Writer"
    }
    $H=(Get-FileHash -LiteralPath $Writer -Algorithm SHA256).Hash.ToLowerInvariant()
    if($H -ne $WriterSha){throw "Writer code identity drift: $Writer"}
    Write-Host "WRITER_HASH_VERIFIED=$Writer"
}

$RunDir="D:\NYX_N2_WORK\V031_DEPLOYMENT_ACTIVATION_ESCALATION_$(Get-Date -Format yyyyMMdd_HHmmss)"
$ReturnDir=Join-Path $RunDir "N2_V031_RETURN"
New-Item -ItemType Directory -Path $ReturnDir -Force|Out-Null

$Receipt=[ordered]@{
    version="N2_V031_DEPLOYMENT_ACTIVATION_CONTRACT_ESCALATION"
    final="ESCALATED_MISSING_DEPLOYMENT_ACTIVATION_CONTRACT"
    parent_defect="N2-DEFECT-026-HIGHER-ORDER-DEPLOYMENT-BINDING-NOT-PROVEN"
    defect_id="N2-DEFECT-027-DEPLOYMENT-ACTIVATION-CONTRACT-ABSENT"
    failed_seam="PHASE0_DEPLOYMENT_ROOT_TO_RUNTIME_ACTIVATION"
    owner_lane="PHASE0_DEPLOYMENT_RUNTIME_ACTIVATION_OWNER"
    owner_component_status="FUNCTIONAL_OWNER_ONLY_EXACT_COMPONENT_NOT_YET_PROVEN"
    exact_cause="No current non-quarantined runner/manifest explicitly binds either V030 deployment root, so no active deployment copy is evidence-backed."
    minimum_repair="Expose or identify one explicit authoritative deployment activation contract selecting a legitimate deployment root and executable runtime entrypoint. Do not infer activity from directory names, timestamps, hashes, or basename popularity. If none exists, return BLOCKED_BY_MISSING_DEPLOYMENT_ACTIVATION_AUTHORITY."
    v030_evidence=$V030Evidence
    v030_sha256=$Actual
    writer_code_identity_sha256=$WriterSha
    deployment_roots=$Roots
    baseline_mutated="NO"
    canonical_core_mutated="NO"
    constraint_semantics_mutated="NO"
    n2_mutated="NO"
    n2_adjudication_semantics_changed="NO"
    rerun_result="NOT_RUN_PENDING_DEPLOYMENT_ACTIVATION_OWNER"
    n2_disposition="PARKED_PENDING_DEPLOYMENT_ACTIVATION_OWNER"
    allowed_owner_outcomes=@(
        "DEPLOYMENT_ACTIVATION_CONTRACT_PROVEN",
        "BLOCKED_BY_MISSING_DEPLOYMENT_ACTIVATION_AUTHORITY"
    )
    next_action="PHASE0_DEPLOYMENT_RUNTIME_OWNER_REPAIR_OR_BLOCKER"
}

$ReceiptPath=Join-Path $ReturnDir "N2_V031_DEPLOYMENT_ACTIVATION_CONTRACT_ESCALATION_RECEIPT.json"
$Receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $ReceiptPath -Encoding UTF8

$Summary=@"
NYX N2 V031 DEPLOYMENT ACTIVATION CONTRACT ESCALATION
FINAL=ESCALATED_MISSING_DEPLOYMENT_ACTIVATION_CONTRACT
PARENT_DEFECT=N2-DEFECT-026-HIGHER-ORDER-DEPLOYMENT-BINDING-NOT-PROVEN
DEFECT_ID=N2-DEFECT-027-DEPLOYMENT-ACTIVATION-CONTRACT-ABSENT
FAILED_SEAM=PHASE0_DEPLOYMENT_ROOT_TO_RUNTIME_ACTIVATION
OWNER_LANE=PHASE0_DEPLOYMENT_RUNTIME_ACTIVATION_OWNER
EXACT_CAUSE=No current non-quarantined runner/manifest explicitly binds either V030 deployment root, so no active deployment copy is evidence-backed.
MINIMUM_REPAIR=Expose or identify one explicit authoritative deployment activation contract selecting a legitimate deployment root and executable runtime entrypoint. Do not infer activity from directory names, timestamps, hashes, or basename popularity. If none exists, return BLOCKED_BY_MISSING_DEPLOYMENT_ACTIVATION_AUTHORITY.
BASELINE_MUTATED=NO
CANONICAL_CORE_MUTATED=NO
CONSTRAINT_SEMANTICS_MUTATED=NO
N2_MUTATED=NO
RERUN_RESULT=NOT_RUN_PENDING_DEPLOYMENT_ACTIVATION_OWNER
N2_DISPOSITION=PARKED_PENDING_DEPLOYMENT_ACTIVATION_OWNER
ALLOWED_OUTCOME_1=DEPLOYMENT_ACTIVATION_CONTRACT_PROVEN
ALLOWED_OUTCOME_2=BLOCKED_BY_MISSING_DEPLOYMENT_ACTIVATION_AUTHORITY
NEXT_ACTION=PHASE0_DEPLOYMENT_RUNTIME_OWNER_REPAIR_OR_BLOCKER
"@
$SummaryPath=Join-Path $ReturnDir "N2_V031_DEPLOYMENT_ACTIVATION_CONTRACT_ESCALATION_SUMMARY.txt"
$Summary | Set-Content -LiteralPath $SummaryPath -Encoding UTF8

$ReturnZip=Join-Path $Downloads ("N2_V031_DEPLOYMENT_ACTIVATION_CONTRACT_ESCALATION_RETURN_{0}.zip" -f (Get-Date -Format yyyyMMdd_HHmmss))
Compress-Archive -Path (Join-Path $ReturnDir "*") -DestinationPath $ReturnZip -CompressionLevel Optimal
$ReturnSha=(Get-FileHash -LiteralPath $ReturnZip -Algorithm SHA256).Hash.ToLowerInvariant()

Write-Host ""
Write-Host "============================================================"
Write-Host "N2 V031 FINAL"
Write-Host "============================================================"
Write-Host "FINAL=ESCALATED_MISSING_DEPLOYMENT_ACTIVATION_CONTRACT"
Write-Host "DEFECT_ID=N2-DEFECT-027-DEPLOYMENT-ACTIVATION-CONTRACT-ABSENT"
Write-Host "FAILED_SEAM=PHASE0_DEPLOYMENT_ROOT_TO_RUNTIME_ACTIVATION"
Write-Host "OWNER_LANE=PHASE0_DEPLOYMENT_RUNTIME_ACTIVATION_OWNER"
Write-Host "BASELINE_MUTATED=NO"
Write-Host "CANONICAL_CORE_MUTATED=NO"
Write-Host "CONSTRAINT_SEMANTICS_MUTATED=NO"
Write-Host "N2_MUTATED=NO"
Write-Host "RERUN_RESULT=NOT_RUN_PENDING_DEPLOYMENT_ACTIVATION_OWNER"
Write-Host "N2_DISPOSITION=PARKED_PENDING_DEPLOYMENT_ACTIVATION_OWNER"
Write-Host "RETURN_ZIP=$ReturnZip"
Write-Host "RETURN_SHA256=$ReturnSha"
Write-Host "RETURN_RUN_DIR=$RunDir"

# Public claim boundaries

The recruiter-facing market walkthrough is **REPRESENTATIVE** and **NON-LIVE**.

The public-safe CI-004 and CI-006 excerpts are **SYNTHETIC / SHADOW** control evidence.

The public-safe CI-008 authority example is **SHADOW** control evidence.

The site does **not** claim:

- live production validation;
- canonical production promotion;
- production constraint detection;
- real-world market signal execution;
- Baby ML training;
- Serious ML execution.

The public engineering claim is narrower: HYDRA contains tested mechanisms for contract-bound handoffs, lineage preservation, quarantine/release blocking, defect-scoped repair, deterministic validation, and fail-closed behavior when required authority is missing.

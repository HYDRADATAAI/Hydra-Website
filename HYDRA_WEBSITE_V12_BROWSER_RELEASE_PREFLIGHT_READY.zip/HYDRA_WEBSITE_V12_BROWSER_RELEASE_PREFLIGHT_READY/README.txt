HYDRA WEBSITE V12 - BROWSER RELEASE PREFLIGHT

Purpose:
- seal the V11 recruiter-facing build across desktop, tablet, and mobile;
- verify internal routes, fragments, labels, blocked-state visibility, and claim boundaries;
- apply only bounded usability repairs proven by the browser audit;
- prepare an exact public GitHub synchronization payload without claiming deployment occurred.

Local browser seal: PASS_REPAIRED
Public GitHub repository: VERIFIED_PUBLIC
Public repository content at seal time: V7 / STALE_RELATIVE_TO_V12
GitHub Pages deployment: NOT_PROVEN_BY_THIS_PACKAGE

Open index.html for the recruiter view.
Run RUN_HYDRA_WEBSITE_V12_RELEASE_PREFLIGHT.ps1 for a local deterministic preflight.

# RECRUITER_TECHNICAL_PROOF_STRIP

A standalone, dependency-free recruiter proof section for the HYDRA website.

## Purpose

Give a technical recruiter or engineer a 30-90 second path through the HYDRA engineering loop:

`INGEST → NORMALIZE → CONTRACT → TRACE → VALIDATE → DEFECT → RESOLUTION → OUTPUT`

The section deliberately distinguishes real-data canonicalization evidence from synthetic/shadow integration evidence. It also labels the final constraint JSON as representative rather than live production output.

## Files

- `index.html` - standalone preview and full section markup
- `styles.css` - responsive dark UI styling
- `evidence_manifest.json` - proof-to-source mapping used to keep claims honest
- `proof-strip-fragment.html` - section-only markup for site integration

## Integration

1. Copy the `<section class="proof-strip" ...>` block from `proof-strip-fragment.html` into the current HYDRA page below the architecture/hero and above deeper project detail.
2. Merge `styles.css` into the site stylesheet or load it after the existing foundation styles.
3. Preserve the evidence-scope tags. They are part of the claim-safety design, not decoration.
4. Do not replace the compact cards with terminal screenshots. The snippets are intentionally short enough to scan.

## Design intent

The proof strip should answer one question fast: **Can this project demonstrate disciplined data engineering behavior, not just architecture diagrams?**

It shows source accounting, canonicalization, explicit handoff contracts, lineage, integrated validation, named defect handling, minimum repair/rerun behavior, fail-closed authority behavior, and representative governed output.

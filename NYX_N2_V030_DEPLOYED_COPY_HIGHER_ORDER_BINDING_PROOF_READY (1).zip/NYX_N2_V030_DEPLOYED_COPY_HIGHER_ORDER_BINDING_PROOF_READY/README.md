# NYX N2 V030 — Deployed Copy Higher-Order Binding Proof

Parent defect:
`N2-DEFECT-025-RECEIPT-WRITER-ACTIVE-COPY-NOT-PROVEN`

Pinned V029 return SHA-256:
`558f3518a9da4ca48e5053e314f3fd6e20e95efd97415b2a30b35d5398e5a3a5`

Three exact deployed writer copies are byte-identical:
`84df9a26f4b210fa9feae4cbea2189097c784fdf290f27227fb472b37cb60469`

V030 does NOT choose an owner by identical code, mtime, basename popularity, or path-name activity.

It moves one level up:
1. derive each writer's enclosing package root;
2. inventory only package-local runnable entrypoints and binding/runtime manifests;
3. search current active HYDRA files for exact executable bindings to those package-local entrypoints or package roots;
4. select a branch only if exactly one package has strong external binding evidence.

Valid outcomes:
- `UNIQUE_DEPLOYED_COPY_HIGHER_ORDER_BINDING_PROVEN`
- `MULTIPLE_DEPLOYED_COPY_HIGHER_ORDER_BINDINGS_PROVEN`
- `NO_DEPLOYED_COPY_HIGHER_ORDER_BINDING_PROVEN`

Read-only. No mutation.

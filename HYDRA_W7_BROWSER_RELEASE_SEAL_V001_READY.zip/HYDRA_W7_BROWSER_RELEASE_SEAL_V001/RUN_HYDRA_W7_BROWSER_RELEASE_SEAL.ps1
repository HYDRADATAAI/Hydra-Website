param([string]$SiteRoot="D:\HYDRA_SITE\V7",[string]$PublicUrl="")
$ErrorActionPreference="Stop"
$Here=Split-Path -Parent $MyInvocation.MyCommand.Path
$Py=Get-Command python -ErrorAction SilentlyContinue
if(-not $Py){$Py=Get-Command py -ErrorAction SilentlyContinue}
if(-not $Py){throw "Python not found"}
$Stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$Out="D:\HYDRA\WEBSITE_TEST_RESULTS\W7_BROWSER_RELEASE_SEAL_$Stamp"
New-Item -ItemType Directory -Path $Out -Force|Out-Null
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "HYDRA W7 - BROWSER RELEASE SEAL" -ForegroundColor Cyan
Write-Host "READ-ONLY SOURCE / TEMP MIRROR / FAIL-CLOSED" -ForegroundColor DarkGray
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "SITE_ROOT=$SiteRoot"
Write-Host "OUTPUT_ROOT=$Out"
$Args=@((Join-Path $Here "w7_browser_release_seal.py"),"--site-root",$SiteRoot,"--out",$Out)
if($PublicUrl){$Args+=@("--public-url",$PublicUrl)}
if($Py.Name -match "^py(\.exe)?$"){& $Py.Source -3 @Args}else{& $Py.Source @Args}
exit $LASTEXITCODE

@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_BATCH65_FROM_BATCH64.ps1"
if errorlevel 1 (
  echo.
  echo BATCH65 BUILD FAILED. See the error above.
  pause
  exit /b 1
)
echo.
echo BATCH65 BUILD PASSED.
pause

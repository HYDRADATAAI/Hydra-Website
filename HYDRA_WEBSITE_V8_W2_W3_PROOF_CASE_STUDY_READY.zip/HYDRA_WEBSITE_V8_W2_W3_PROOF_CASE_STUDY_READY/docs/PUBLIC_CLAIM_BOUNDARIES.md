# PUBLIC CLAIM BOUNDARIES

## Allowed on this pass
- HYDRA has synthetic/shadow integrated control receipts proving selected contract, lineage, quarantine, deterministic rerun, and authority-block behavior.
- CI-004 reached `PASS_REPAIRED_CI_TEST_004` with `FAILURE_COUNT=0` and no canonical baseline mutation.
- CI-006 proved an expected quarantine path through a downstream release block with lineage/provenance preservation checks passing.
- CI-008 blocked when exact authoritative case data was missing and reported `semantic_values_invented=false`.
- The market-constraint walkthrough is representative and non-live.

## Do not imply
- production data validation;
- live trading signal generation;
- real-world market constraint detection from live sources;
- Baby ML training;
- Serious ML execution;
- canonical promotion from the representative walkthrough.

## Redaction rule
Public snippets should remove local drive paths, operator identities, unnecessary internal hashes, and exhaustive internal version lineage unless the hash is itself the proof being shown.

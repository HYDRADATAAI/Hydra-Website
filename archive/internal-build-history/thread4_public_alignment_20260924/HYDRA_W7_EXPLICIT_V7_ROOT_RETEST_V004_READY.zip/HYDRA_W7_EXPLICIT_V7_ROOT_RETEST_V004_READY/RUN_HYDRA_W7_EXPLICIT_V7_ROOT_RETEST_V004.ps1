﻿param(
    [string]$SiteRoot = "D:\HYDRA_SITE\V7",
    [string]$ResultBase = "D:\HYDRA\WEBSITE_TEST_RESULTS",
    [string]$PublicDeploymentUrl = ""
)

$ErrorActionPreference = "Stop"
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$ResultRoot = Join-Path $ResultBase ("W7_EXPLICIT_V7_ROOT_RETEST_" + $Stamp)
New-Item -ItemType Directory -Path $ResultRoot -Force | Out-Null

Write-Host "===================================================================="
Write-Host "HYDRA W7 V004 - EXPLICIT V7 ROOT RETEST"
Write-Host "===================================================================="
Write-Host "MODE=READ_ONLY"
Write-Host "SITE_ROOT=$SiteRoot"
Write-Host "RESULT_ROOT=$ResultRoot"

$Checks = New-Object System.Collections.Generic.List[object]

function Add-Check {
    param(
        [string]$Name,
        [string]$Status,
        [string]$Detail
    )
    $Row = [pscustomobject]@{
        check = $Name
        status = $Status
        detail = $Detail
    }
    $Checks.Add($Row)
    Write-Host ($Name + "=" + $Status + " :: " + $Detail)
}

if (-not (Test-Path -LiteralPath $SiteRoot -PathType Container)) {
    Add-Check "SITE_ROOT" "FAIL" "directory not found"
    $Overall = "FAIL_WITH_DEFECT"
    $Checks | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot "W7_V004_CHECKS.csv")
    Write-Host "OVERALL=$Overall"
    exit 2
}

$Index = Join-Path $SiteRoot "index.html"
if (-not (Test-Path -LiteralPath $Index -PathType Leaf)) {
    Add-Check "SITE_ROOT" "FAIL" "index.html missing"
    $Overall = "FAIL_WITH_DEFECT"
    $Checks | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot "W7_V004_CHECKS.csv")
    Write-Host "OVERALL=$Overall"
    exit 2
}

Add-Check "SITE_ROOT" "PASS" $SiteRoot

# Build a bounded text corpus from the exact V7 root only.
$CorpusBuilder = New-Object System.Text.StringBuilder
$AllowedExtensions = @(".html",".js",".css",".json",".md",".txt")
$Files = Get-ChildItem -LiteralPath $SiteRoot -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object {
        $AllowedExtensions -contains $_.Extension.ToLowerInvariant() -and
        $_.Length -le 8MB -and
        $_.FullName -notmatch '\\node_modules\\'
    } |
    Select-Object -First 500

foreach ($File in $Files) {
    try {
        [void]$CorpusBuilder.AppendLine((Get-Content -LiteralPath $File.FullName -Raw -ErrorAction Stop))
    } catch {}
    if ($CorpusBuilder.Length -gt 16000000) { break }
}
$Corpus = $CorpusBuilder.ToString()

# Identity proof: this exact root must be the HYDRA recruiter site.
$HeroTitle = $Corpus -match "MARKET INTELLIGENCE DATA PLATFORM"
$Tagline = $Corpus -match "Turn fragmented market data into traceable intelligence"
$HydraMarker = $Corpus -match "\bHYDRA\b"

Add-Check "HYDRA_IDENTITY" ($(if ($HydraMarker) { "PASS" } else { "FAIL" })) "HYDRA"
Add-Check "HERO_TITLE" ($(if ($HeroTitle) { "PASS" } else { "FAIL" })) "MARKET INTELLIGENCE DATA PLATFORM"
Add-Check "TAGLINE" ($(if ($Tagline) { "PASS" } else { "FAIL" })) "Turn fragmented market data into traceable intelligence."

# W5-approved public wording.
Add-Check "BADGE_MULTI_SOURCE_EVIDENCE_INPUTS" ($(if ($Corpus -match "Multi-source evidence inputs") { "PASS" } else { "FAIL" })) "W5-safe wording"
Add-Check "BADGE_CONTRACT_BOUND_HANDOFFS" ($(if ($Corpus -match "Contract-bound handoffs") { "PASS" } else { "FAIL" })) "Contract-bound handoffs"
Add-Check "BADGE_PROVENANCE_VALIDATION_GATES" ($(if ($Corpus -match "Provenance \+ validation gates") { "PASS" } else { "FAIL" })) "W5-safe wording"

# Proof entrypoint.
$ProofHit = $Corpus -match "Technical Proof|Inspect Technical Proof|Technical proof"
Add-Check "PROOF_ENTRYPOINT" ($(if ($ProofHit) { "PASS" } else { "FAIL" })) "Technical Proof / Inspect Technical Proof"

# HTML-only structural checks.
$HtmlFiles = Get-ChildItem -LiteralPath $SiteRoot -Recurse -File -Filter "*.html" -ErrorAction SilentlyContinue
$PlaceholderCount = 0
$MissingLocal = New-Object System.Collections.Generic.List[object]
$ViewportFound = $false

foreach ($Html in $HtmlFiles) {
    $Text = Get-Content -LiteralPath $Html.FullName -Raw -ErrorAction SilentlyContinue
    if ($Text -match '<meta[^>]+name=["'']viewport["'']') {
        $ViewportFound = $true
    }

    $PlaceholderCount += ([regex]::Matches(
        $Text,
        'href\s*=\s*["''](?:\s*|#|javascript:void\(0\);?|javascript:;?)["'']',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )).Count

    $Refs = [regex]::Matches(
        $Text,
        '(?:src|href)\s*=\s*["'']([^"'']+)["'']',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )

    foreach ($Match in $Refs) {
        $Ref = $Match.Groups[1].Value
        if (-not $Ref) { continue }
        if ($Ref.StartsWith("#")) { continue }
        if ($Ref -match '^(https?:|mailto:|tel:|data:|javascript:)') { continue }

        $Clean = ($Ref -split '[?#]')[0]
        if (-not $Clean) { continue }

        if ($Clean.StartsWith("/")) {
            $Target = Join-Path $SiteRoot $Clean.TrimStart("/")
        } else {
            $Target = Join-Path $Html.Directory.FullName $Clean
        }

        if (-not (Test-Path -LiteralPath $Target)) {
            $MissingLocal.Add([pscustomobject]@{
                page = $Html.FullName
                ref = $Ref
                target = $Target
            })
        }
    }
}

Add-Check "VIEWPORT_META" ($(if ($ViewportFound) { "PASS" } else { "FAIL" })) "responsive viewport"
Add-Check "PLACEHOLDER_LINKS" ($(if ($PlaceholderCount -eq 0) { "PASS" } else { "FAIL" })) ("count=" + $PlaceholderCount)
Add-Check "LOCAL_ASSETS" ($(if ($MissingLocal.Count -eq 0) { "PASS" } else { "FAIL" })) ("missing=" + $MissingLocal.Count)

if ($MissingLocal.Count -gt 0) {
    $MissingLocal | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot "MISSING_LOCAL_ASSETS.csv")
}

# GitHub authority. Existing site link counts as public authority.
$GithubMatches = [regex]::Matches(
    $Corpus,
    'https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',
    [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
)
$GithubUrls = @($GithubMatches | ForEach-Object { $_.Value.TrimEnd("/") } | Sort-Object -Unique)

$GitRemote = $null
$Probe = Get-Item -LiteralPath $SiteRoot
for ($i = 0; $i -lt 5; $i++) {
    if ($null -eq $Probe) { break }
    if (Test-Path -LiteralPath (Join-Path $Probe.FullName ".git")) {
        try {
            $RemoteValue = & git -C $Probe.FullName remote get-url origin 2>$null
            if ($LASTEXITCODE -eq 0 -and $RemoteValue) {
                $GitRemote = $RemoteValue.Trim()
                break
            }
        } catch {}
    }
    $Probe = $Probe.Parent
}

if ($GithubUrls.Count -gt 0) {
    Add-Check "GITHUB_LINK" "PASS" ("count=" + $GithubUrls.Count + " first=" + $GithubUrls[0])
} elseif ($GitRemote -match 'github\.com') {
    Add-Check "GITHUB_LINK" "BLOCKED" ("git remote exists but public site link absent: " + $GitRemote)
} else {
    Add-Check "GITHUB_LINK" "BLOCKED" "no authoritative GitHub URL found in V7 site or containing git repo"
}

# JavaScript syntax check when Node exists.
$JsFiles = Get-ChildItem -LiteralPath $SiteRoot -Recurse -File -Filter "*.js" -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -notmatch '\\node_modules\\' }

$Node = Get-Command node -ErrorAction SilentlyContinue
$JsFailures = New-Object System.Collections.Generic.List[object]

if ($Node) {
    foreach ($Js in $JsFiles) {
        $Out = & $Node.Source --check $Js.FullName 2>&1
        if ($LASTEXITCODE -ne 0) {
            $JsFailures.Add([pscustomobject]@{
                file = $Js.FullName
                error = ($Out -join "`n")
            })
        }
    }

    if ($JsFailures.Count -eq 0) {
        Add-Check "JS_SYNTAX" "PASS" ("files=" + $JsFiles.Count)
    } else {
        Add-Check "JS_SYNTAX" "FAIL" ("failures=" + $JsFailures.Count)
        $JsFailures | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot "JS_SYNTAX_FAILURES.csv")
    }
} else {
    Add-Check "JS_SYNTAX" "BLOCKED" "node executable not found; browser render still attempted"
}

# Browser render the exact V7 root only.
$Browser = $null
$BrowserCandidates = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
)

foreach ($Candidate in $BrowserCandidates) {
    if ($Candidate -and (Test-Path -LiteralPath $Candidate)) {
        $Browser = $Candidate
        break
    }
}

$Python = $null
if (Get-Command py -ErrorAction SilentlyContinue) {
    $Python = "py"
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $Python = "python"
}

$DesktopStatus = "BLOCKED"
$TabletStatus = "BLOCKED"
$MobileStatus = "BLOCKED"
$BrowserStatus = "BLOCKED"

if ($Browser -and $Python) {
    $Port = 18784
    $ServerArgs = @("-m","http.server",$Port,"--bind","127.0.0.1","--directory",$SiteRoot)
    $Server = Start-Process -FilePath $Python -ArgumentList $ServerArgs -PassThru -WindowStyle Hidden
    Start-Sleep -Seconds 2

    try {
        $Url = "http://127.0.0.1:$Port/index.html"

        $Viewports = @(
            [pscustomobject]@{ Name = "DESKTOP"; Width = 1440; Height = 1000 },
            [pscustomobject]@{ Name = "TABLET"; Width = 820; Height = 1180 },
            [pscustomobject]@{ Name = "MOBILE"; Width = 390; Height = 844 }
        )

        foreach ($Viewport in $Viewports) {
            $ArgsList = @(
                "--headless=new",
                "--disable-gpu",
                "--no-first-run",
                "--no-default-browser-check",
                ("--window-size=" + $Viewport.Width + "," + $Viewport.Height),
                "--virtual-time-budget=6000",
                "--dump-dom",
                $Url
            )

            $Dom = & $Browser @ArgsList 2>$null
            $DomText = $Dom -join "`n"
            $DomFile = Join-Path $ResultRoot ("DOM_" + $Viewport.Name + ".html")
            $DomText | Set-Content -LiteralPath $DomFile -Encoding UTF8

            $Rendered = ($DomText -match "MARKET INTELLIGENCE DATA PLATFORM") -and
                        ($DomText -match "Turn fragmented market data into traceable intelligence")

            $Status = $(if ($Rendered) { "PASS" } else { "FAIL" })

            if ($Viewport.Name -eq "DESKTOP") { $DesktopStatus = $Status }
            if ($Viewport.Name -eq "TABLET")  { $TabletStatus = $Status }
            if ($Viewport.Name -eq "MOBILE")  { $MobileStatus = $Status }
        }

        if ($DesktopStatus -eq "PASS" -and $TabletStatus -eq "PASS" -and $MobileStatus -eq "PASS") {
            $BrowserStatus = "PASS"
        } else {
            $BrowserStatus = "FAIL"
        }
    } finally {
        Stop-Process -Id $Server.Id -Force -ErrorAction SilentlyContinue
    }
}

Add-Check "BROWSER_RENDER" $BrowserStatus ("browser=" + $(if ($Browser) { $Browser } else { "NOT_FOUND" }))
Add-Check "DESKTOP" $DesktopStatus "1440x1000 V7 render"
Add-Check "TABLET" $TabletStatus "820x1180 V7 render"
Add-Check "MOBILE" $MobileStatus "390x844 V7 render"

# Public deployment is a separate authority question.
if (-not $PublicDeploymentUrl) {
    if ($env:HYDRA_PUBLIC_DEPLOYMENT_URL) {
        $PublicDeploymentUrl = $env:HYDRA_PUBLIC_DEPLOYMENT_URL
    } else {
        $PublicUrlFile = Join-Path $SiteRoot "PUBLIC_DEPLOYMENT_URL.txt"
        $CnameFile = Join-Path $SiteRoot "CNAME"

        if (Test-Path -LiteralPath $PublicUrlFile) {
            $PublicDeploymentUrl = (Get-Content -LiteralPath $PublicUrlFile -Raw).Trim()
        } elseif (Test-Path -LiteralPath $CnameFile) {
            $HostName = (Get-Content -LiteralPath $CnameFile -First 1).Trim()
            if ($HostName -match '^[A-Za-z0-9.-]+\.[A-Za-z]{2,}$') {
                $PublicDeploymentUrl = "https://" + $HostName
            }
        }
    }
}

if ($PublicDeploymentUrl -match '^https?://') {
    try {
        $Response = Invoke-WebRequest -Uri $PublicDeploymentUrl -UseBasicParsing -TimeoutSec 20
        $PublicPass = ($Response.StatusCode -ge 200 -and $Response.StatusCode -lt 400 -and $Response.Content -match "\bHYDRA\b")
        Add-Check "PUBLIC_DEPLOYMENT" ($(if ($PublicPass) { "PASS" } else { "FAIL" })) ("url=" + $PublicDeploymentUrl + " status=" + $Response.StatusCode)
    } catch {
        Add-Check "PUBLIC_DEPLOYMENT" "FAIL" ("url=" + $PublicDeploymentUrl + " error=" + $_.Exception.Message)
    }
} else {
    Add-Check "PUBLIC_DEPLOYMENT" "BLOCKED" "local V7 site proven separately; no authoritative public deployment URL"
}

$FailCount = @($Checks | Where-Object { $_.status -eq "FAIL" }).Count
$BlockedCount = @($Checks | Where-Object { $_.status -eq "BLOCKED" }).Count

$LocalCritical = @(
    "SITE_ROOT",
    "HYDRA_IDENTITY",
    "HERO_TITLE",
    "TAGLINE",
    "BADGE_MULTI_SOURCE_EVIDENCE_INPUTS",
    "BADGE_CONTRACT_BOUND_HANDOFFS",
    "BADGE_PROVENANCE_VALIDATION_GATES",
    "PROOF_ENTRYPOINT",
    "VIEWPORT_META",
    "PLACEHOLDER_LINKS",
    "LOCAL_ASSETS",
    "BROWSER_RENDER",
    "DESKTOP",
    "TABLET",
    "MOBILE"
)

$LocalFailures = @($Checks | Where-Object {
    $LocalCritical -contains $_.check -and $_.status -eq "FAIL"
}).Count

if ($LocalFailures -gt 0) {
    $Overall = "FAIL_WITH_DEFECT"
} elseif ($FailCount -gt 0) {
    $Overall = "FAIL_WITH_DEFECT"
} elseif ($BlockedCount -gt 0) {
    $Overall = "PASS_LOCAL_BLOCKED_EXTERNAL_AUTHORITY"
} else {
    $Overall = "PASS"
}

$Receipt = [pscustomobject]@{
    version = "W7_V004"
    generated_at = (Get-Date).ToString("o")
    mode = "READ_ONLY"
    site_root = $SiteRoot
    authority = "EXPLICIT_V7_ROOT"
    github_remote = $GitRemote
    github_urls = $GithubUrls
    public_deployment_url = $(if ($PublicDeploymentUrl) { $PublicDeploymentUrl } else { $null })
    fail_count = $FailCount
    blocked_count = $BlockedCount
    local_fail_count = $LocalFailures
    overall = $Overall
    checks = $Checks
}

$ReceiptPath = Join-Path $ResultRoot "W7_V004_EXPLICIT_V7_RECEIPT.json"
$Receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $ReceiptPath -Encoding UTF8
$Checks | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot "W7_V004_CHECKS.csv")

$Summary = @(
    "HYDRA W7 V004 EXPLICIT V7 ROOT RETEST",
    "MODE=READ_ONLY",
    ("SITE_ROOT=" + $SiteRoot),
    ("FAIL_COUNT=" + $FailCount),
    ("BLOCKED_COUNT=" + $BlockedCount),
    ("LOCAL_FAIL_COUNT=" + $LocalFailures),
    ("OVERALL=" + $Overall),
    ("RESULT_ROOT=" + $ResultRoot)
)
$Summary | Set-Content -LiteralPath (Join-Path $ResultRoot "W7_V004_SUMMARY.txt") -Encoding UTF8

$ResultZip = Join-Path $HOME ("Downloads\HYDRA_W7_EXPLICIT_V7_ROOT_RETEST_RESULT_" + $Stamp + ".zip")
Compress-Archive -Path (Join-Path $ResultRoot "*") -DestinationPath $ResultZip -Force
$ResultHash = (Get-FileHash -LiteralPath $ResultZip -Algorithm SHA256).Hash.ToLowerInvariant()

Write-Host "===================================================================="
Write-Host "HYDRA W7 V004 EXPLICIT V7 VERDICT"
Write-Host "===================================================================="
Write-Host "MODE=READ_ONLY"
Write-Host "SITE_ROOT=$SiteRoot"
Write-Host "FAIL_COUNT=$FailCount"
Write-Host "BLOCKED_COUNT=$BlockedCount"
Write-Host "LOCAL_FAIL_COUNT=$LocalFailures"
Write-Host "OVERALL=$Overall"
Write-Host "RESULT_ZIP=$ResultZip"
Write-Host "RESULT_ZIP_SHA256=$ResultHash"

if ($Overall -eq "PASS") {
    exit 0
} elseif ($Overall -eq "PASS_LOCAL_BLOCKED_EXTERNAL_AUTHORITY") {
    exit 3
} else {
    exit 2
}

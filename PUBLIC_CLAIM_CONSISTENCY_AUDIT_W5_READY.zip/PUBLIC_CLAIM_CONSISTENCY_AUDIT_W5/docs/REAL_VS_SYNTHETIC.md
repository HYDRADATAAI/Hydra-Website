# Real vs Synthetic

HYDRA uses explicit evidence labels so a recruiter can tell what has actually been executed from what is explanatory, representative, or synthetic.

| Label | Meaning in this front door | Example |
|---|---|---|
| Executed test evidence | A real local test/result receipt with recorded outcome and integrity metadata | CI-TEST-005, CI-TEST-008, N1 sealed result |
| Integrated | A test that exercised an actual cross-stage or cross-thread seam | CI-TEST-005 |
| Representative / non-live | Public-safe example used to explain data structures and flow | Representative constraint case |
| Synthetic / shadow | Controlled hardening or validation that does not claim live production behavior | Broader HYDRA hardening lanes |
| Live production | Operational live market inference or a public production runtime | **Not claimed by this front door** |

## Public claim boundary

This recruiter package may claim:

- executed validation and seam-test outcomes shown by the included receipts;
- the tested N1 deterministic identity invariant;
- contract and authority enforcement demonstrated by CI-TEST-008;
- explicit PASS / BLOCK behavior;
- baseline mutation checks shown by the included receipts;
- representative constraint structures when labeled representative/non-live;
- provenance/history as part of the documented architecture and data model.

It does **not** claim:

- a proven public production ingestion runtime;
- live production trading signals;
- live production market inference;
- a public runnable demo that has not been safely packaged;
- unqualified production scale, production deployment, or cloud-runtime claims;
- authority for downstream fields that CI-TEST-008 showed were missing from the native T5→T6 handoff.

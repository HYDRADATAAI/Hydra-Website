@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_BATCH66_FROM_BATCH65.ps1"
if errorlevel 1 (
  echo.
  echo BATCH66 BUILD FAILED. See the error above.
  pause
  exit /b 1
)
echo.
echo BATCH66 BUILD PASSED.
pause

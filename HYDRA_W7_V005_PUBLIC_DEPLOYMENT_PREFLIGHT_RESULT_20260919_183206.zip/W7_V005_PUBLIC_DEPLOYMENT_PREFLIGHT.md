# W7 V005 PUBLIC DEPLOYMENT PREFLIGHT

`OVERALL=BLOCKED_PUBLIC_DEPLOYMENT_NOT_CONFIGURED_OR_NOT_DISCOVERABLE`

- SITE_ROOT: `D:\HYDRA_SITE\V7`
- GITHUB_URLS_FOUND: `1`
- GIT_ORIGIN: `NONE`
- GH_CLI_INSTALLED: `False`
- GH_AUTHENTICATED: `False`
- PUBLIC_HYDRA_URL: `NOT_PROVEN`

## Repository candidates

- `https://github.com/HYDRADATAAI/hydra-website`
  - `https://hydradataai.github.io/hydra-website/` reachable=False hydra_title=None hydra_tagline=None

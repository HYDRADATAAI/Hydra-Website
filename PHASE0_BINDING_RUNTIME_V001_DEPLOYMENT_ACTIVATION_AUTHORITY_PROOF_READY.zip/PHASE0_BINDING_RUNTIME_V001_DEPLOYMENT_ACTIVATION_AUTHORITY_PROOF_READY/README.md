# Phase-0 Binding/Runtime V001 — Deployment Activation Authority Proof

Source defect: `N2-DEFECT-026-HIGHER-ORDER-DEPLOYMENT-BINDING-NOT-PROVEN`

Pinned sealed N2 V031 return: `620677b7e81a29e77627879dc9005e5bd696dff12be8d037e6e45a8699f8cf1b`

Read-only owner-lane proof. A valid activation contract must explicitly bind one proven deployment
root and a live executable runtime entrypoint. No mtime, newest-wins, directory-name activity
inference, code-identity inference, or selected-path aliasing is allowed.

Valid outcomes:
- `DEPLOYMENT_ACTIVATION_CONTRACT_PROVEN`
- `MULTIPLE_DEPLOYMENT_ACTIVATION_CONTRACTS_AMBIGUOUS`
- `BLOCKED_BY_MISSING_DEPLOYMENT_ACTIVATION_AUTHORITY`

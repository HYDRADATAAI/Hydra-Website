HYDRA V13 PUBLIC GITHUB DEPLOYMENT RUNNER

PURPOSE
Deploy the exact V12 public sync payload to:
  https://github.com/HYDRADATAAI/Hydra-Website
branch:
  main

BOUNDARIES
- Exact V12 payload SHA-256 required: 3bee70bc6ddd6987e3a07e3434cdab9e79b3d7cf4cc521823ec3a3106b6e3ff0
- Only files listed in DEPLOYMENT_MANIFEST.json may change.
- Unlisted repository files are not deleted.
- GitHub Pages settings are NOT changed by this runner.
- Git commit identity is never invented. If user.name/user.email are missing, the run BLOCKS.
- A failed push returns a blocker packet instead of pretending deployment succeeded.
- Public GitHub API and GitHub Pages checks are read-only.

POSSIBLE FINAL STATES
PASS_PUBLIC_GITHUB_SYNC_AND_PAGES_VERIFIED
PASS_REPO_SYNC_PUBLIC_PAGES_NOT_PROVEN
BLOCKED

ROLLBACK
The included rollback helper is review-only. Normal rollback policy is git revert, not force-push.

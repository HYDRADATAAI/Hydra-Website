(() => {
  "use strict";

  const qs = (sel, root = document) => root.querySelector(sel);
  const qsa = (sel, root = document) => [...root.querySelectorAll(sel)];
  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  // Footer year.
  qsa("[data-year]").forEach(el => { el.textContent = new Date().getFullYear(); });

  // Repository wiring. If no public repository is configured, keep unfinished
  // project plumbing off the recruiter-facing surface entirely.
  const config = window.HYDRA_CONFIG || {};
  const repoLinks = qsa("[data-repo-link]");
  const repoSection = qs("[data-repo-section]");
  if (config.repositoryUrl) {
    repoLinks.forEach(link => {
      link.href = config.repositoryUrl;
      link.target = "_blank";
      link.rel = "noreferrer";
      link.removeAttribute("aria-disabled");
      link.hidden = false;
      if (link.classList.contains("repo-button")) link.textContent = "Open repository ↗";
    });
    if (repoSection) repoSection.hidden = false;
  } else {
    repoLinks.forEach(link => { link.hidden = true; });
    if (repoSection) repoSection.hidden = true;
  }

  // Mobile navigation.
  const navToggle = qs("[data-nav-toggle]");
  const nav = qs("[data-nav]");
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const open = nav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(open));
    });
    qsa("a", nav).forEach(a => a.addEventListener("click", () => {
      nav.classList.remove("is-open");
      navToggle.setAttribute("aria-expanded", "false");
    }));
  }

  // Scroll state + progress meter.
  const header = qs("[data-header]");
  const meter = qs(".scroll-meter span");
  const updateScroll = () => {
    const y = window.scrollY || 0;
    if (header) header.classList.toggle("is-scrolled", y > 18);
    if (meter) {
      const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      meter.style.width = `${Math.min(100, (y / max) * 100)}%`;
    }
  };
  updateScroll();
  window.addEventListener("scroll", updateScroll, { passive: true });

  // Soft cursor glow on pointer devices.
  const glow = qs(".cursor-glow");
  if (glow && window.matchMedia("(pointer:fine)").matches) {
    window.addEventListener("pointermove", (event) => {
      document.documentElement.style.setProperty("--mx", `${event.clientX}px`);
      document.documentElement.style.setProperty("--my", `${event.clientY}px`);
    }, { passive: true });
  }

  // Reveal system.
  const revealEls = qsa("[data-reveal]");
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reducedMotion || !("IntersectionObserver" in window)) {
    revealEls.forEach(el => el.classList.add("is-visible"));
  } else {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    revealEls.forEach(el => observer.observe(el));
  }

  // Architecture explorer.
  const stages = {
    source: {
      kicker: "STAGE 01",
      owner: "OWNER · SOURCE LANE",
      title: "Source Intake",
      summary: "Capture source material without losing the context required to identify and audit it later.",
      question: "What entered the system?",
      preserve: "origin · source identity · arrival context",
      failure: "quarantine unknown or malformed source state",
      output: "normalized source envelope",
      principle: "Do not clean away the evidence needed to explain what arrived."
    },
    identity: {
      kicker: "STAGE 02",
      owner: "OWNER · IDENTITY LANE",
      title: "Identity",
      summary: "Resolve what the object is before downstream stages assume two records refer to the same thing.",
      question: "Which entity or case does this represent?",
      preserve: "canonical IDs · aliases · crosswalk evidence",
      failure: "stop ambiguous or conflicting identity bindings",
      output: "resolved identity with binding evidence",
      principle: "Similarity is not identity. Bind deliberately and keep the proof."
    },
    contract: {
      kicker: "STAGE 03",
      owner: "OWNER · CONTRACT LANE",
      title: "Contracts",
      summary: "Validate shape, semantics, ownership, and derivation rights before a consumer receives the handoff.",
      question: "Is this producer allowed to supply this requirement?",
      preserve: "field ownership · version · authority · derivation rules",
      failure: "BLOCKED_BY_MISSING_AUTHORITY when proof is absent",
      output: "admissible contract-bound handoff",
      principle: "A field being discoverable is not the same as a field being authorized."
    },
    transform: {
      kicker: "STAGE 04",
      owner: "OWNER · TRANSFORM LANE",
      title: "Transform",
      summary: "Apply bounded, inspectable transformations without breaking the connection between input and output.",
      question: "What changed, under which rule?",
      preserve: "input references · transform version · output receipt",
      failure: "reject non-reproducible or out-of-contract mutation",
      output: "canonical transformed object",
      principle: "A transformation should reduce ambiguity, not erase its own history."
    },
    lineage: {
      kicker: "STAGE 05",
      owner: "OWNER · LINEAGE LANE",
      title: "Lineage",
      summary: "Link outputs back to the source, transform, and predecessor state required to reproduce or audit them.",
      question: "Where did this output come from?",
      preserve: "source refs · parent artifacts · stage receipts · hashes",
      failure: "block orphaned or stale lineage references",
      output: "traceable lineage chain",
      principle: "A useful answer should still know the route it took through the system."
    },
    trust: {
      kicker: "STAGE 06",
      owner: "OWNER · TRUST / HISTORY LANE",
      title: "Trust / History",
      summary: "Preserve contradictory evidence, reversals, freshness, and history instead of flattening uncertainty into one value.",
      question: "What agrees, conflicts, reversed, or became stale?",
      preserve: "competing evidence · timestamps · reversals · source context",
      failure: "do not silently delete or overwrite conflict",
      output: "adjudicable evidence state",
      principle: "Raw volume is not truth, and source quality is not a shortcut to truth."
    },
    release: {
      kicker: "STAGE 07",
      owner: "OWNER · RELEASE GATE",
      title: "Release Gate",
      summary: "Make the final handoff contingent on evidence that upstream authority, lineage, and contract requirements remain intact.",
      question: "May this object leave the governed pipeline?",
      preserve: "gate decision · blocker reason · baseline mutation status",
      failure: "quarantine, fail, or block with a named reason",
      output: "released object + machine-readable receipt",
      principle: "A truthful blocker is better than a fake green pipeline."
    }
  };

  const stageList = qs("[data-stage-list]");
  const stagePanel = qs("[data-stage-panel]");
  if (stageList && stagePanel) {
    const fields = {
      kicker: qs("[data-stage-kicker]", stagePanel),
      owner: qs("[data-stage-owner]", stagePanel),
      title: qs("[data-stage-title]", stagePanel),
      summary: qs("[data-stage-summary]", stagePanel),
      question: qs("[data-stage-question]", stagePanel),
      preserve: qs("[data-stage-preserve]", stagePanel),
      failure: qs("[data-stage-failure]", stagePanel),
      output: qs("[data-stage-output]", stagePanel),
      principle: qs("[data-stage-principle]", stagePanel)
    };

    const setStage = (key) => {
      const data = stages[key];
      if (!data) return;
      qsa("[data-stage]", stageList).forEach(button => {
        const active = button.dataset.stage === key;
        button.classList.toggle("is-active", active);
        button.setAttribute("aria-selected", String(active));
      });
      Object.entries(fields).forEach(([field, el]) => { if (el) el.textContent = data[field]; });
      stagePanel.animate?.([
        { opacity: .65, transform: "translateY(5px)" },
        { opacity: 1, transform: "translateY(0)" }
      ], { duration: 220, easing: "ease-out" });
    };

    qsa("[data-stage]", stageList).forEach(button => button.addEventListener("click", () => setStage(button.dataset.stage)));
  }

  // Integrity Lab.
  const labRun = qs("[data-lab-run]");
  const labReset = qs("[data-lab-reset]");
  const consoleEl = qs("[data-console]");
  const consoleState = qs("[data-console-state]");
  const receipt = qs("[data-console-receipt]");
  const receiptOutcome = qs("[data-receipt-outcome]");
  const receiptHash = qs("[data-receipt-hash]");

  const scenarioOptions = qsa(".scenario-option");
  scenarioOptions.forEach(label => {
    const input = qs("input", label);
    if (!input) return;
    input.addEventListener("change", () => {
      scenarioOptions.forEach(item => item.classList.toggle("is-selected", qs("input", item)?.checked));
    });
  });

  const scenarioData = {
    valid: {
      outcome: "PASS",
      tone: "good",
      state: "PASS",
      lines: [
        ["info", "Loading frozen baseline receipt ... OK"],
        ["info", "Resolving producer contract for downstream handoff ... FOUND"],
        ["good", "Required fields are owned by the same authoritative producer."],
        ["good", "Lineage chain resolves to the expected source snapshot."],
        ["good", "Derivation rules: no unauthorized synthesis detected."],
        ["good", "Release gate satisfied. Handoff is admissible."],
        ["good", "OVERALL=PASS"]
      ]
    },
    missing: {
      outcome: "BLOCKED_BY_MISSING_AUTHORITY",
      tone: "warn",
      state: "BLOCKED",
      lines: [
        ["info", "Loading frozen baseline receipt ... OK"],
        ["info", "Resolving producer contract for downstream handoff ... PARTIAL"],
        ["warn", "Consumer requires fields with no authoritative native producer."],
        ["warn", "No contract grants a derivation path for the missing requirements."],
        ["info", "Synthetic defaulting is disabled by policy."],
        ["warn", "Release gate stopped before downstream consumption."],
        ["warn", "OVERALL=BLOCKED_BY_MISSING_AUTHORITY"]
      ]
    },
    ambiguous: {
      outcome: "FAIL_WITH_DEFECT",
      tone: "bad",
      state: "DEFECT",
      lines: [
        ["info", "Loading frozen baseline receipt ... OK"],
        ["info", "Resolving case identifier across candidate records ... MULTIPLE MATCHES"],
        ["bad", "Fields can be discovered in sibling records outside the producer-owned case scope."],
        ["bad", "Complete handoff would be possible only by crossing ownership boundaries."],
        ["info", "Selector containment rule engaged."],
        ["bad", "Named defect required before repair. Neighboring construction remains frozen."],
        ["bad", "OVERALL=FAIL_WITH_DEFECT"]
      ]
    },
    drift: {
      outcome: "QUARANTINE",
      tone: "warn",
      state: "QUARANTINE",
      lines: [
        ["info", "Loading expected lineage snapshot ... OK"],
        ["info", "Reading active source cursor ... CHANGED"],
        ["warn", "Source snapshot no longer matches the lineage receipt pinned by the handoff."],
        ["info", "Downstream release is withheld while drift is classified."],
        ["warn", "Object moved to quarantine path; frozen baseline remains untouched."],
        ["warn", "OVERALL=QUARANTINE"]
      ]
    }
  };

  const checksum = (text) => {
    let h1 = 0x811c9dc5;
    let h2 = 0x9e3779b1;
    for (let i = 0; i < text.length; i++) {
      const c = text.charCodeAt(i);
      h1 ^= c;
      h1 = Math.imul(h1, 0x01000193) >>> 0;
      h2 ^= (c + i) >>> 0;
      h2 = Math.imul(h2, 0x85ebca6b) >>> 0;
    }
    const a = h1.toString(16).padStart(8, "0");
    const b = h2.toString(16).padStart(8, "0");
    return `${a}${b}${a}${b}`.slice(0, 28);
  };

  const appendConsoleLine = (tone, text, idx) => {
    if (!consoleEl) return;
    const line = document.createElement("div");
    line.className = `console-line console-${tone}`;
    line.innerHTML = `<span>${String(idx).padStart(2, "0")}</span><p></p>`;
    qs("p", line).textContent = text;
    consoleEl.appendChild(line);
    consoleEl.scrollTop = consoleEl.scrollHeight;
  };

  const resetConsole = () => {
    if (!consoleEl) return;
    consoleEl.innerHTML = '<div class="console-line console-muted"><span>00</span><p>Ready. Select a scenario and run the integrity check.</p></div><div class="console-line console-muted"><span>01</span><p>No production systems are contacted by this demo.</p></div>';
    if (receipt) receipt.hidden = true;
    if (consoleState) consoleState.textContent = "IDLE";
    if (labRun) labRun.disabled = false;
  };

  if (labReset) labReset.addEventListener("click", resetConsole);

  if (labRun && consoleEl) {
    labRun.addEventListener("click", async () => {
      const selected = qs('input[name="scenario"]:checked');
      const key = selected?.value || "valid";
      const scenario = scenarioData[key];
      labRun.disabled = true;
      if (receipt) receipt.hidden = true;
      consoleEl.innerHTML = "";
      if (consoleState) consoleState.textContent = "RUNNING";

      appendConsoleLine("muted", `SCENARIO=${key.toUpperCase()}`, 0);
      let idx = 1;
      for (const [tone, text] of scenario.lines) {
        await sleep(reducedMotion ? 25 : 260 + (idx % 2) * 70);
        appendConsoleLine(tone, text, idx++);
      }

      const hash = checksum(`HYDRA:${key}:${scenario.outcome}:BASELINE_MUTATED=NO`);
      if (receiptOutcome) {
        receiptOutcome.textContent = scenario.outcome;
        receiptOutcome.style.color = scenario.tone === "good" ? "var(--green)" : scenario.tone === "bad" ? "var(--red)" : "var(--amber)";
      }
      if (receiptHash) receiptHash.textContent = hash;
      if (receipt) receipt.hidden = false;
      if (consoleState) consoleState.textContent = scenario.state;
      labRun.disabled = false;
    });
  }
})();

# HYDRA W7 V005 — Bounded Copy Repair + Browser Retest

V004 proved the correct root and two actual copy defects. V005 repairs only those exact two labels, backs up every touched file, and retests browser output using normalized visible text rather than raw contiguous DOM text.

Repairs:
- `Multi-source ingestion` -> `Multi-source evidence inputs`
- `Lineage + release gates` -> `Provenance + validation gates`

The browser retest preserves visible-text captures, Chrome stderr, HTTP logs, and screenshots. Public deployment remains a separate authority check.

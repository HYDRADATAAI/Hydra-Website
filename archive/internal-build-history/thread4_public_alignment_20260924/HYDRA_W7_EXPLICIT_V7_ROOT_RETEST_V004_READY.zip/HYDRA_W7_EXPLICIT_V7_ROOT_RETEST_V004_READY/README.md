# HYDRA W7 V004 — Explicit V7 Root Retest

This package supersedes the failed discovery attempts.

## Authority

The recruiter-facing website root is explicitly bound to:

`D:\HYDRA_SITE\V7`

The runner does **not** search `D:\HYDRA` for a replacement website.

## Mode

`READ_ONLY`

No website files are modified.

## Checks

- HYDRA site identity
- recruiter hero/title/tagline
- W5-safe public badges
- Technical Proof entrypoint
- viewport
- placeholder links
- local asset existence
- GitHub authority/link
- JavaScript syntax where Node is available
- headless desktop/tablet/mobile rendering
- public deployment only when an authoritative URL is supplied/discovered

## Outcome semantics

`PASS`
- local V7 site and all external authority checks pass.

`PASS_LOCAL_BLOCKED_EXTERNAL_AUTHORITY`
- local site is clean, but GitHub/public-deployment authority is not fully available.

`FAIL_WITH_DEFECT`
- an actual V7 site defect is proven.

This runner does not infer a deployment URL from unrelated package metadata.

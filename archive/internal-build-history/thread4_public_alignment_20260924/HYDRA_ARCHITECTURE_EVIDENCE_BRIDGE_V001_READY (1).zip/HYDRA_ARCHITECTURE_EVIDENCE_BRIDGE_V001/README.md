# HYDRA Architecture + Evidence Bridge V001

Standalone preview:
- `index.html`

Drop-in website files:
- `architecture-evidence-component.html`
- `architecture-evidence.css`

Structured evidence map:
- `architecture-evidence-data.json`

Review:
- `W4_BUILD_REPORT.md`
- `W4_VALIDATION.md`

The component is designed to sit below the Constraint Case Study V2.

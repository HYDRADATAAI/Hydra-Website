# HYDRA — Recruiter Proof Strip V1

## Purpose

A fast 30–90 second technical proof path for recruiters and engineering managers.

Sequence:

`INGEST → NORMALIZE → CONTRACT → TRACE → VALIDATE → DEFECT → RESOLUTION → OUTPUT`

## Files

- `HYDRA_RECRUITER_PROOF_STRIP_V1.html` — standalone responsive preview.
- `recruiter-proof-strip.fragment.html` — drop-in section.
- `recruiter-proof-strip.css` — scoped styles.
- `PROOF_STRIP_EVIDENCE_MAP.json` — claim-to-evidence map.
- `evidence/` — public-safe excerpts and representative structures.
- W1 claim-authority artifacts — carried forward for audit continuity.
- `W2_ACCEPTANCE_RECEIPT.json` — machine-readable closeout.

## Integration note

The original full website source package is not present in this lane, so this ZIP does **not**
silently mutate the deployed site. It provides a bounded drop-in section and standalone preview.

## Truth boundary

- INGEST uses genuine source-file samples, explicitly **not** as proof of a live HYDRA ingestion runtime.
- NORMALIZE and OUTPUT are explicitly **REPRESENTATIVE**.
- Integrated testing cards retain `SYNTHETIC_SHADOW_ONLY` / controlled labels as required.
- CI-008 is intentionally shown as a valid blocked outcome:
  **discoverable data is not automatically authorized data**.
- No production, live-ML, or canonical-promotion claim is made.

## Acceptance

PASS when:
- pipeline is understandable in under 90 seconds;
- real vs representative vs synthetic/shadow labels are visible;
- source-to-result story is visually coherent;
- defect + bounded repair are visible;
- missing authority produces BLOCK rather than fabricated values;
- no live-production claim is implied.

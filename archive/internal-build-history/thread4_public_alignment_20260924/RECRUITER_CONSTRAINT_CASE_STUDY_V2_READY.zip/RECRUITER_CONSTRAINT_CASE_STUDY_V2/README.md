# RECRUITER_CONSTRAINT_CASE_STUDY_V2

Recruiter-facing HYDRA case study showing the engineering path:

`FRAGMENTED MARKET EVIDENCE → SOURCE NORMALIZATION → IDENTITY RESOLUTION → CONTRACT / AUTHORITY CHECK → PROVENANCE + HISTORY → CONSTRAINT INTERPRETATION → AUDITABLE RESULT`

## Files

- `index.html` — standalone preview.
- `styles.css` — responsive styling.
- `case-study-fragment.html` — integration-ready section markup.
- `evidence_manifest.json` — public-claim scope and evidence labels.

## Evidence boundaries

The canonicalization counts are real-data proof. Lineage and admissibility receipts are integrated synthetic/shadow proof. The market example itself is explicitly `REPRESENTATIVE / NON-LIVE` and should retain that label on every public surface.

The case intentionally concludes only `LOCAL BOTTLENECK` and refuses `SYSTEMIC SHORTAGE` because the illustrative evidence does not authorize the broader claim. This demonstrates HYDRA's core public story: correctness, authority, provenance, identity, and scope are enforced before an intelligence result moves downstream.

## Integration

Insert `case-study-fragment.html` after the recruiter proof strip or use it as the main body of a dedicated Case Study page. Carry the relevant selectors from `styles.css` into the site's existing stylesheet rather than loading a second global theme if the production site already has equivalent tokens.

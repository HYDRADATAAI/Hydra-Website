HYDRA_CONSTRAINT_CASE_STUDY_V2

Open index.html for the recruiter-facing preview.

Core principle:
DISCOVERABLE DATA IS NOT AUTOMATICALLY AUTHORIZED DATA.

Labels are explicit:
REPRESENTATIVE = market walkthrough structures/output
SYNTHETIC / SHADOW = selected control receipts
SHADOW = authority-block control receipt

No live-production market claim is made.

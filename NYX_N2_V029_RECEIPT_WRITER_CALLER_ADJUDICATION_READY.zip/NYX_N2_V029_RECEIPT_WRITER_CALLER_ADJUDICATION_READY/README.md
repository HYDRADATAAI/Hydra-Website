# NYX N2 V029 — Receipt Writer Caller Adjudication

Parent defect: `N2-DEFECT-024-RUNTIME-BINDING-CONTRACT-OWNER-NOT-PROVEN`

Pinned V028 return SHA-256: `274c9040e80d1479e8feda0ac4005e1b047166d693ffdb0f0ca6613f87b052c5`

V028 proved three byte-identical receipt-writer candidates, all SHA-256 `84df9a26f4b210fa9feae4cbea2189097c784fdf290f27227fb472b37cb60469`, each writing only `implementation_candidates.json`, with no unique owner metadata.

V029 treats identical hashes, basename mentions, mtimes and scores as non-authoritative. It grants caller authority only to executable scripts that reference one exact writer by full path or branch-unique relative path.

Outcomes:
- `UNIQUE_RECEIPT_WRITER_RUNTIME_BRANCH_PROVEN`
- `MULTIPLE_RECEIPT_WRITER_RUNTIME_BRANCHES_ACTIVE`
- `NO_RECEIPT_WRITER_CALLER_PROVEN`

Read-only. No Core, Constraint semantics, or N2 mutation.

# NYX Constraint Intelligence T1-T5 — Batch 66 Receipt-Bound Host Builder

This ZIP does **not** claim Batch 66 is already sealed. It builds Batch 66 only after your local Batch 65 build has produced a real `BATCH65_SEAL_RECEIPT.json`.

## One click

1. Finish Batch 65 with the prior host builder.
2. Leave its output in the default `D:\NYX_BATCH65_BUILD` folder, or keep the sealed Batch 65 ZIP / ten Batch 65 transfer ZIPs plus `BATCH65_SEAL_RECEIPT.json` together.
3. Extract this ZIP.
4. Double-click `RUN_BATCH66_FROM_BATCH65.cmd`.

The runner prefers the already sealed Batch 65 ZIP if present. If absent, it reconstructs Batch 65 from the ten transfer ZIPs. The bytes and SHA-256 must match the Batch 65 seal receipt exactly before Batch 66 construction begins.

## Batch 66 target

- Packaging: `DELTA_WITH_EXACT_SEALED_PREDECESSOR`
- Boundary: `SYNTHETIC_SHADOW_ONLY`
- Schema profile: `2.48`
- Golden seeds: `66001` through `66012`
- Outer members: `8,915`
- Manifest-governed entries: `8,912`
- Shadow QA checks: `3,517`
- Transfer ZIPs: exactly `10`
- Thread 6: `NOT_STARTED`
- Real production data: not used
- Automatic canonical promotion: disabled
- Baby-ML training: disabled
- Trading-signal generation: disabled

## Batch 66 focus

T1 expands into IDNA ContextJ rule-version drift, timezone-abbreviation region ambiguity, day-count rounding-order drift, snapshot-compaction generation tokens, nonfinite-number semantic-hash policies, and provenance offset integrity after escape/newline normalization.

T2 adds PDF ActualText structure duplication, currency/per-share table scope collisions, security crosswalk as-of collisions, parenthetical exception scope flips, and resume-token pagination duplication.

A successful run writes the sealed Batch 66 ZIP, ten Batch 66 transfer ZIPs, and `BATCH66_SEAL_RECEIPT.json`.

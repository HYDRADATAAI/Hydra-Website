HYDRA WEBSITE V11 - HOSTILE RECRUITER FRICTION SEAL

Purpose:
- preserve the frozen recruiter hero;
- remove recruiter/navigation friction;
- repair GitHub-root README links;
- bind the verified public repository without claiming V11 is already deployed;
- preserve explicit REPRESENTATIVE / SYNTHETIC / SHADOW claim boundaries.

Open index.html or run RUN_HYDRA_WEBSITE_V11_LOCAL_AUDIT.ps1.

Public repository target:
https://github.com/HYDRADATAAI/Hydra-Website

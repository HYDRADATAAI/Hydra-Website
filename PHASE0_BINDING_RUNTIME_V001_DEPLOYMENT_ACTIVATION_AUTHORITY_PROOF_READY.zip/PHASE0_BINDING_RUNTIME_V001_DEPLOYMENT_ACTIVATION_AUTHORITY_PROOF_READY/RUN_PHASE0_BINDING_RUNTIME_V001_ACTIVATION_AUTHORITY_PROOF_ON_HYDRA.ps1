param(
    [string]$HydraRoot="D:\HYDRA",
    [string]$V031Evidence=""
)
$ErrorActionPreference="Stop"
Set-StrictMode -Version Latest
Write-Host "============================================================"
Write-Host "PHASE0 BINDING/RUNTIME V001 - DEPLOYMENT ACTIVATION AUTHORITY PROOF"
Write-Host "============================================================"
Write-Host "SOURCE_DEFECT=N2-DEFECT-026-HIGHER-ORDER-DEPLOYMENT-BINDING-NOT-PROVEN"
Write-Host "FAILED_SEAM=PHASE0_DEPLOYMENT_ROOT_TO_RUNTIME_ACTIVATION"
Write-Host "OWNER_LANE=PHASE0_BINDING_RUNTIME"
Write-Host "MODE=READ_ONLY_OWNER_AUTHORITY_PROOF"
Write-Host "UPSTREAM_MUTATION_AUTHORIZED=NO"
Write-Host "N2_REOPEN=NO_UNTIL_PASS"
Write-Host "MTIME_AUTHORITY=NO"
Write-Host "NEWEST_WINS=NO"
Write-Host "DIRECTORY_NAME_ACTIVITY_INFERENCE=NO"

$Downloads=Join-Path $env:USERPROFILE "Downloads"
if(-not $V031Evidence){
    $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "N2_V031_RETURN_PACKET_*.zip" -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending
    $Found=$null
    foreach($C in $Candidates){
        $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        if($H -eq "620677b7e81a29e77627879dc9005e5bd696dff12be8d037e6e45a8699f8cf1b"){$Found=$C;break}
    }
    if(-not $Found){throw "Exact V031 sealed return packet not found with SHA256=620677b7e81a29e77627879dc9005e5bd696dff12be8d037e6e45a8699f8cf1b"}
    $V031Evidence=$Found.FullName
}
$Actual=(Get-FileHash -LiteralPath $V031Evidence -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host "V031_EVIDENCE=$V031Evidence"
Write-Host "V031_EVIDENCE_SHA256=$Actual"
if($Actual -ne "620677b7e81a29e77627879dc9005e5bd696dff12be8d037e6e45a8699f8cf1b"){throw "V031 evidence hash mismatch."}
Write-Host "V031_EVIDENCE_HASH_VERIFIED=PASS"

$PkgRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
$Py=Join-Path $PkgRoot "phase0_v001_deployment_activation_authority_proof.py"
$PythonCmd=Get-Command python.exe -ErrorAction SilentlyContinue
$PyLauncher=Get-Command py.exe -ErrorAction SilentlyContinue
if($PythonCmd){$PythonExe=$PythonCmd.Source;$Prefix=@()}
elseif($PyLauncher){$PythonExe=$PyLauncher.Source;$Prefix=@("-3")}
else{throw "Python not found."}

& $PythonExe @Prefix $Py --selftest
if($LASTEXITCODE -ne 0){throw "Phase0 V001 selftest failed."}

$RunDir="D:\NYX_PHASE0_BINDING_RUNTIME_WORK\V001_ACTIVATION_AUTHORITY_$(Get-Date -Format yyyyMMdd_HHmmss)"
$ReturnDir=Join-Path $RunDir "PHASE0_V001_RETURN"
New-Item -ItemType Directory -Path $ReturnDir -Force|Out-Null
Write-Host "RUN_DIR=$RunDir"

& $PythonExe @Prefix $Py --hydra-root $HydraRoot --v031-evidence $V031Evidence --output-dir $ReturnDir
if($LASTEXITCODE -ne 0){throw "Phase0 V001 authority proof failed."}

$R=Get-Content -LiteralPath (Join-Path $ReturnDir "PHASE0_V001_DEPLOYMENT_ACTIVATION_AUTHORITY_PROOF.json") -Raw|ConvertFrom-Json
$ReturnZip=Join-Path $Downloads ("PHASE0_BINDING_RUNTIME_V001_ACTIVATION_AUTHORITY_RETURN_{0}.zip" -f (Get-Date -Format yyyyMMdd_HHmmss))
Compress-Archive -Path (Join-Path $ReturnDir "*") -DestinationPath $ReturnZip -CompressionLevel Optimal
$ReturnSha=(Get-FileHash -LiteralPath $ReturnZip -Algorithm SHA256).Hash.ToLowerInvariant()

Write-Host ""
Write-Host "============================================================"
Write-Host "PHASE0 BINDING/RUNTIME V001 FINAL"
Write-Host "============================================================"
Write-Host "FINAL=$($R.status)"
Write-Host "DEFECT_ID=$($R.defect_id)"
Write-Host "CONTRACT_HIT_COUNT=$($R.contract_hit_count)"
Write-Host "UNIQUE_ACTIVATION_COMBO_COUNT=$($R.unique_activation_combo_count)"
if($null -ne $R.selected_activation_contract){
    Write-Host "SELECTED_DEPLOYMENT_ROOT=$($R.selected_activation_contract.deployment_root)"
    Write-Host "ACTIVATION_CONTRACT_PATH=$($R.selected_activation_contract.contract_path)"
    Write-Host "ACTIVATION_CONTRACT_SHA256=$($R.selected_activation_contract.contract_sha256)"
    Write-Host "RUNTIME_ENTRYPOINT_PATH=$($R.selected_activation_contract.runtime_entrypoint_path)"
    Write-Host "RUNTIME_ENTRYPOINT_SHA256=$($R.selected_activation_contract.runtime_entrypoint_sha256)"
}
Write-Host "READ_ONLY=TRUE"
Write-Host "BASELINE_MUTATED=FALSE"
Write-Host "CANONICAL_CORE_MUTATED=FALSE"
Write-Host "CONSTRAINT_SEMANTICS_MUTATED=FALSE"
Write-Host "N2_MUTATED=FALSE"
Write-Host "NEXT_ACTION=$($R.next_action)"
Write-Host "RETURN_ZIP=$ReturnZip"
Write-Host "RETURN_SHA256=$ReturnSha"
Write-Host "RETURN_RUN_DIR=$RunDir"

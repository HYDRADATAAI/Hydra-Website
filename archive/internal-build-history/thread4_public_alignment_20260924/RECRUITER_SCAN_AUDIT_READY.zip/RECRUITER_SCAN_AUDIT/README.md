# W6 — Recruiter Scan Audit

This package tests whether HYDRA's public story works for a recruiter who spends roughly 10–90 seconds before deciding whether to inspect further.

Start with:

- `RECRUITER_SCAN_AUDIT.md` — human verdict
- `RECRUITER_SCAN_MATRIX.csv` — scan-window acceptance matrix
- `PATCH_NOTES.md` — bounded changes made during W6
- `W6_RECRUITER_SCAN_RECEIPT.json` — machine validation receipt
- `HERO_SCAN_CONTRACT.md` — frozen 10-second hero contract
- `PATCHED_PUBLIC_SURFACES/` — W2, W3, and GitHub copies with W5/W6 scan fixes applied

W7 remains responsible for public deployment, browser rendering, responsive layouts, navigation, routes, links, overflow, JavaScript errors, and final release sealing.

# NYX Constraint Intelligence T1-T5 — Batch 68 Receipt-Bound Host Builder

This ZIP does **not** claim Batch 68 is already sealed. It builds Batch 68 only after your local Batch 67 build has produced a real `BATCH67_SEAL_RECEIPT.json`.

## One click

1. Finish Batch 67 with the prior host builder.
2. Leave its output in the default `D:\NYX_BATCH67_BUILD` folder, or keep the sealed Batch 67 ZIP / ten Batch 67 transfer ZIPs plus `BATCH67_SEAL_RECEIPT.json` together.
3. Extract this ZIP.
4. Double-click `RUN_BATCH68_FROM_BATCH67.cmd`.

The runner prefers the sealed Batch 67 ZIP. If absent, it reconstructs Batch 67 from the ten transfer ZIPs. The SHA-256 and byte count must match the Batch 67 seal receipt before Batch 68 construction begins.

## Batch 68 target

- Packaging: `DELTA_WITH_EXACT_SEALED_PREDECESSOR`
- Boundary: `SYNTHETIC_SHADOW_ONLY`
- Schema profile: `2.50`
- Golden seeds: `68001` through `68012`
- Outer members: `8,915`
- Manifest-governed entries: `8,912`
- Shadow QA checks: `3,625`
- Transfer ZIPs: exactly `10`
- Thread 6: `NOT_STARTED`
- Real production data: not used
- Automatic canonical promotion: disabled
- Baby-ML training: disabled
- Trading-signal generation: disabled

## Batch 68 focus

T1 expands into grapheme-cluster boundary version drift, timezone second-offset precision loss, negative-zero significance, branch snapshot generation tokens, locale-collated semantic-hash member order, and zero-width stripping provenance offsets.

T2 adds floating-textbox PDF reading-order interleaving, pivot/unpivot table-axis drift, share-class name reuse after reverse splits, comparative-baseline ellipsis scope loss, and equal-sort-key pagination instability.

A successful run writes the sealed Batch 68 ZIP, ten Batch 68 transfer ZIPs, and `BATCH68_SEAL_RECEIPT.json`.

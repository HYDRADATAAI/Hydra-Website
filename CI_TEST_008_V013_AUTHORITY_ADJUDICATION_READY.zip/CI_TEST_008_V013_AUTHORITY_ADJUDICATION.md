# CI-TEST-008 V013 Authority Adjudication

**Outcome:** `BLOCKED_BY_MISSING_AUTHORITY`

This is an adjudication receipt over the existing pinned native-contract / authority-audit evidence through V012. It is **not** a fresh execution against `D:\HYDRA`.

## Native T6 contract

The pinned native T6 input contract exists and requires:

`upstream_object_id`, `object_type`, `subject_entity_id`, `as_of`, `confidence`, `evidence_ids`, `payload`

Native handoff version: `T5_TO_T6_V001`.

## Field disposition

| Field | T5 native state | Legitimately derivable under proven existing authority? | Disposition |
|---|---|---|---|
| `upstream_object_id` | already satisfied in focused native check | not required | SATISFIED |
| `payload` | already satisfied in focused native check | not required | SATISFIED |
| `object_type` | absent | no | MISSING_AUTHORITY |
| `subject_entity_id` | absent | no | MISSING_AUTHORITY |
| `as_of` | absent | no | MISSING_AUTHORITY |
| `confidence` | absent | no | MISSING_AUTHORITY |
| `evidence_ids` | absent from T5 native materialization | no proven native derivation | MISSING_AUTHORITY |

The earlier external scan found some `evidence_ids` field-source candidates, but found **zero complete authoritative bindings**. Those candidates are not promoted to native authority.

## Handoff finding

The T6 contract and validator authority exist. The exact authoritative Batch60 T5→T6 binding does not.

Therefore:

- native T6 contract exists;
- exact Batch60 T5 binding is absent;
- no complete authoritative handoff currently satisfies T6;
- the five semantic fields must not be defaulted, guessed, inferred from filenames/IDs, or synthesized.

## Why this is not `FAIL_WITH_DEFECT`

A materialization defect would require proof that an authoritative upstream producer owns the missing values and that T5 drops them. Current evidence does not establish that producer/ownership. The authority is missing before an implementation defect can be honestly assigned.

If an authoritative producer/source is later supplied and T5 still omits the owned values, the correct disposition becomes `FAIL_WITH_DEFECT`.

## Minimum unblock condition

Supply one exact authoritative native case source or producer contract for one nonblocked Batch60 T5 case that legally owns/binds the missing semantic fields. Then rerun the same admissibility test without changing the frozen Batch60 baseline and without semantic invention.

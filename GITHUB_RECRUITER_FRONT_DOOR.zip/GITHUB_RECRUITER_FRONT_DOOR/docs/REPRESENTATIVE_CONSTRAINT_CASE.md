# Representative Constraint Case

**Evidence class: REPRESENTATIVE / NON-LIVE**

This case is designed to show how HYDRA structures a market-constraint decision path. It is intentionally simplified and does not claim a live production market conclusion.

## 1. Fragmented market evidence

Different sources may describe the same subject with different field names, identifiers, timestamps, and levels of historical context.

```json
{
  "source_a": {"symbol": "EXAMPLE", "observation": "pressure_signal"},
  "source_b": {"instrument_key": "EXAMPLE-REF", "reference_state": "active"},
  "source_c": {"history_key": "EXAMPLE-HIST", "history_window": "available"}
}
```

The values above are illustrative. The engineering problem is the shape mismatch and authority question.

## 2. Source normalization

HYDRA first maps source-shaped records into a controlled internal representation.

```json
{
  "source_record_id": "src-example-001",
  "subject_hint": "EXAMPLE",
  "observation_type": "pressure_signal",
  "source_class": "market",
  "provenance_attached": true
}
```

Normalization does not grant semantic authority. It only creates a controlled structure for later stages.

## 3. Identity resolution

The record must bind to an authoritative identity before downstream classification can rely on it.

```text
source hints
   ↓
identity resolution
   ↓
canonical subject identity
```

HYDRA's sealed N1 proof demonstrates the related identity invariant:

```text
INPUT_CASE_CONSTRAINT_ID = CANONICAL_IDENTITY_AUTHORITY
```

## 4. Contract / authority check

A field being discoverable somewhere in a document or neighboring record is not enough. The producer and handoff must actually own it.

```text
DISCOVERABLE ≠ AUTHORIZED
```

CI-TEST-008 demonstrates this rule operationally: the T6 native contract was proven, but the authoritative T5→T6 binding was absent, so the pipeline returned `BLOCKED_BY_MISSING_AUTHORITY` rather than inventing the missing semantic values.

## 5. Provenance + history

A valid downstream object should preserve the trail needed to answer:

- which source records contributed;
- which canonical identity was used;
- which contract admitted the handoff;
- which history/provenance links support the result;
- which validation result allowed or blocked release.

## 6. Constraint classification

A representative controlled output might look like this:

```json
{
  "constraint_id": "constraint-example-001",
  "constraint_class": "bottleneck",
  "identity_authority": "resolved",
  "provenance_state": "linked",
  "history_state": "linked",
  "admissibility": "passed",
  "evidence_class": "REPRESENTATIVE_NON_LIVE"
}
```

The class value above is illustrative. It demonstrates the output shape, not a live market claim.

## 7. Traceable output or block

The intended end state is binary in an important way:

```text
required authority + valid evidence
              ↓
       TRACEABLE OUTPUT

missing authoritative handoff
              ↓
             BLOCK
```

That distinction is central to HYDRA: a truthful blocker is preferable to a fabricated result.

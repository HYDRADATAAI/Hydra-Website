# HYDRA Recruiter Journey + CTA V001

Best preview:
- `RECRUITER_JOURNEY_PREVIEW.html`

Standalone W6 section:
- `index.html`

Drop-in W6 website files:
- `recruiter-journey-component.html`
- `recruiter-journey.css`

Binding state:
- `action-bindings.json`

Combined preview assets:
- `journey_sections/w2`
- `journey_sections/w3`
- `journey_sections/w4`
- `journey_sections/w5`

Important:
GitHub, LinkedIn, and Contact are intentionally UNBOUND until exact destinations are supplied.

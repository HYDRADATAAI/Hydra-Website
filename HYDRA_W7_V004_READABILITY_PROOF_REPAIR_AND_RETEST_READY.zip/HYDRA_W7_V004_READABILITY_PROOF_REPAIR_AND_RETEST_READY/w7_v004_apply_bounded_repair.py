#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re, shutil, sys, time
from pathlib import Path

KNOWN_TINY_LABELS = [
    "HYDRA / MARKET INTELLIGENCE DATA PLATFORM",
    "01 / SYSTEM SURFACE",
    "02 / CONSTRAINT INTELLIGENCE",
    "WHAT THE LAYER ASKS",
    "03 / END-TO-END WALKTHROUGH",
    "04 / ENGINEERING DEPTH",
    "05 / DEFECT STORY",
    "05 / DATA ENGINEERING SIGNAL",
    "EXPLORE THE SYSTEM",
    "TECHNICAL PROOF",
]

PROOF_OLD = "EXPLORE THE SYSTEM"
PROOF_NEW = "TECHNICAL PROOF"
RUNTIME_MARKER = "HYDRA_W7_V004_READABILITY_FLOOR"

def sha(path:Path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
    return h.hexdigest()

def backup(path:Path,site:Path,result:Path):
    rel=path.relative_to(site)
    dst=result/"BACKUP_BEFORE_W7_V004"/rel
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(path,dst)
    return dst

def raise_css_floor(text:str):
    changes=[]
    pat=re.compile(r'(?i)(font-size\s*:\s*)(-?\d+(?:\.\d+)?)(px|rem|em|pt)\b')
    def repl(m):
        n=float(m.group(2));unit=m.group(3).lower()
        floor={"px":11.0,"rem":0.6875,"em":0.6875,"pt":8.25}[unit]
        if n < floor:
            new=("11" if unit=="px" else "0.6875" if unit in ("rem","em") else "8.25")+unit
            changes.append({"old":m.group(0),"new":m.group(1)+new})
            return m.group(1)+new
        return m.group(0)
    return pat.sub(repl,text),changes

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--site-root",default=r"D:\HYDRA_SITE\V7")
    ap.add_argument("--result-root",required=True)
    args=ap.parse_args()
    site=Path(args.site_root);result=Path(args.result_root)
    result.mkdir(parents=True,exist_ok=True)

    required=[site/"index.html",site/"styles.css",site/"app.js"]
    missing=[str(p) for p in required if not p.is_file()]
    if missing:
        receipt={"overall":"BLOCKED_REQUIRED_SITE_FILE_MISSING","missing":missing}
        (result/"W7_V004_REPAIR_RECEIPT.json").write_text(json.dumps(receipt,indent=2),encoding="utf-8")
        print("OVERALL=BLOCKED_REQUIRED_SITE_FILE_MISSING")
        return 3

    before={str(p.relative_to(site)):sha(p) for p in required}
    mutations=[]

    # 1. Visible proof-path repair.
    proof_hits=[]
    for p in [site/"index.html",site/"app.js"]:
        txt=p.read_text(encoding="utf-8",errors="strict")
        count=txt.count(PROOF_OLD)
        if count:
            proof_hits.append({"file":str(p.relative_to(site)),"count":count})
    total_hits=sum(x["count"] for x in proof_hits)
    if total_hits == 0:
        receipt={"overall":"BLOCKED_PROOF_CTA_SOURCE_NOT_FOUND","searched":["index.html","app.js"],"expected":PROOF_OLD}
        (result/"W7_V004_REPAIR_RECEIPT.json").write_text(json.dumps(receipt,indent=2),encoding="utf-8")
        print("OVERALL=BLOCKED_PROOF_CTA_SOURCE_NOT_FOUND")
        return 4
    if total_hits > 4:
        receipt={"overall":"BLOCKED_PROOF_CTA_AMBIGUOUS","hits":proof_hits}
        (result/"W7_V004_REPAIR_RECEIPT.json").write_text(json.dumps(receipt,indent=2),encoding="utf-8")
        print("OVERALL=BLOCKED_PROOF_CTA_AMBIGUOUS")
        return 5

    for hit in proof_hits:
        p=site/hit["file"]
        old=p.read_text(encoding="utf-8",errors="strict")
        new=old.replace(PROOF_OLD,PROOF_NEW)
        if new!=old:
            b=backup(p,site,result)
            p.write_text(new,encoding="utf-8")
            mutations.append({"file":hit["file"],"repair":"VISIBLE_PROOF_CTA","backup":str(b),"replacement_count":hit["count"]})

    # 2. CSS readability floor for explicit sub-11px font-size declarations.
    css=site/"styles.css"
    old_css=css.read_text(encoding="utf-8",errors="strict")
    new_css,css_changes=raise_css_floor(old_css)
    if new_css!=old_css:
        if not any(m["file"]=="styles.css" for m in mutations):
            b=backup(css,site,result)
        else:
            b=result/"BACKUP_BEFORE_W7_V004"/"styles.css"
        css.write_text(new_css,encoding="utf-8")
        mutations.append({"file":"styles.css","repair":"CSS_MIN_11PX_FLOOR","backup":str(b),"declarations_changed":len(css_changes),"changes":css_changes[:50]})

    # 3. Exact-text runtime safeguard. This affects ONLY the nine known W7 findings,
    # and only if the element still computes below 11px after CSS.
    app=site/"app.js"
    app_text=app.read_text(encoding="utf-8",errors="strict")
    if RUNTIME_MARKER not in app_text:
        labels_json=json.dumps(KNOWN_TINY_LABELS,ensure_ascii=False)
        snippet=f"""
/* {RUNTIME_MARKER}
   Bounded release-readability safeguard. Only exact known W7 labels below 11px
   are raised to 11px. No content, layout, architecture, or claims are changed. */
;(()=>{{
  const W7_LABELS=new Set({labels_json});
  const apply=()=>{{
    document.querySelectorAll('body *').forEach(el=>{{
      const t=(el.textContent||'').replace(/\\s+/g,' ').trim();
      if(!W7_LABELS.has(t)) return;
      const s=getComputedStyle(el);
      const px=parseFloat(s.fontSize||'0');
      if(Number.isFinite(px) && px < 11){{
        el.style.setProperty('font-size','11px','important');
        el.setAttribute('data-w7-readable','true');
      }}
    }});
  }};
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>setTimeout(apply,0),{{once:true}});
  else setTimeout(apply,0);
}})();
"""
        if not any(m["file"]=="app.js" for m in mutations):
            b=backup(app,site,result)
        else:
            b=result/"BACKUP_BEFORE_W7_V004"/"app.js"
        app.write_text(app_text.rstrip()+"\n"+snippet+"\n",encoding="utf-8")
        mutations.append({"file":"app.js","repair":"EXACT_KNOWN_LABEL_READABILITY_SAFEGUARD","backup":str(b),"labels":KNOWN_TINY_LABELS})

    after={str(p.relative_to(site)):sha(p) for p in required}
    receipt={
        "repair_id":"HYDRA_W7_V004_READABILITY_PROOF_REPAIR",
        "timestamp":time.strftime("%Y-%m-%dT%H:%M:%S"),
        "site_root":str(site),
        "defects":["W7-SITE-001_VISIBLE_TECHNICAL_PROOF_LABEL_ABSENT","W7-SITE-002_TINY_TEXT_UNDER_11PX"],
        "public_deployment_mutated":False,
        "github_mutated":False,
        "claims_changed":False,
        "before_sha256":before,
        "after_sha256":after,
        "mutations":mutations,
        "overall":"REPAIR_APPLIED",
    }
    (result/"W7_V004_REPAIR_RECEIPT.json").write_text(json.dumps(receipt,indent=2),encoding="utf-8")
    print("REPAIR_ID=HYDRA_W7_V004_READABILITY_PROOF_REPAIR")
    print(f"PROOF_CTA_REPLACEMENTS={total_hits}")
    print(f"CSS_DECLARATIONS_RAISED={len(css_changes)}")
    print("EXACT_LABEL_RUNTIME_SAFEGUARD=INSTALLED")
    print(f"MUTATED_FILES={len(set(m['file'] for m in mutations))}")
    print("PUBLIC_DEPLOYMENT_MUTATED=NO")
    print("GITHUB_MUTATED=NO")
    print("CLAIMS_CHANGED=NO")
    print("OVERALL=REPAIR_APPLIED")
    return 0

if __name__=="__main__":
    raise SystemExit(main())

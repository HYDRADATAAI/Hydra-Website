param(
 [string]$SiteRoot="D:\HYDRA_SITE\V7",
 [string]$GitHubUrl=""
)
$ErrorActionPreference="Stop"
$Here=Split-Path -Parent $MyInvocation.MyCommand.Path
$Python=Get-Command python -ErrorAction SilentlyContinue
if(-not $Python){$Python=Get-Command py -ErrorAction SilentlyContinue}
if(-not $Python){throw "Python not found"}
$Args=@((Join-Path $Here "patch_v7_w6.py"),"--site-root",$SiteRoot)
if($GitHubUrl){$Args+=@("--github-url",$GitHubUrl)}
if($Python.Name -match "^py(\.exe)?$"){& $Python.Source -3 @Args}else{& $Python.Source @Args}
exit $LASTEXITCODE

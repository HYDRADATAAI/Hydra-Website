param(
    [Parameter(Mandatory=$false)]
    [string]$SiteRoot = "",
    [Parameter(Mandatory=$false)]
    [string]$OutputRoot = ""
)

$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "HYDRA W6/W7 RETEST - STATIC PREFLIGHT" -ForegroundColor Cyan
Write-Host "READ-ONLY / FAIL-CLOSED" -ForegroundColor DarkGray
Write-Host "============================================================" -ForegroundColor Cyan

if (-not $SiteRoot) {
    $Candidates = @(
        "D:\HYDRA\website",
        "D:\HYDRA\site",
        "D:\HYDRA\public",
        "D:\HYDRA\docs\website",
        "$HOME\Downloads\HYDRA_WEBSITE",
        "$HOME\Downloads\hydra-site"
    )
    foreach ($c in $Candidates) {
        if (Test-Path (Join-Path $c "index.html")) {
            $SiteRoot = $c
            break
        }
    }
}

if (-not $SiteRoot) {
    Write-Host "BLOCKED: SITE_ROOT_NOT_RESOLVED" -ForegroundColor Yellow
    Write-Host 'Re-run with -SiteRoot "D:\PATH\TO\MERGED_SITE"' -ForegroundColor White
    exit 20
}
if (-not (Test-Path -LiteralPath $SiteRoot -PathType Container)) {
    throw "SiteRoot does not exist: $SiteRoot"
}

if (-not $OutputRoot) {
    $Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $OutputRoot = "D:\HYDRA\WEBSITE_TEST_RESULTS\W6_W7_RETEST_$Stamp"
}
New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null

$Python = Get-Command python -ErrorAction SilentlyContinue
if (-not $Python) { $Python = Get-Command py -ErrorAction SilentlyContinue }
if (-not $Python) {
    Write-Host "BLOCKED: PYTHON_NOT_FOUND" -ForegroundColor Yellow
    exit 21
}

$Audit = Join-Path $Here "w6_w7_site_audit.py"
if (-not (Test-Path -LiteralPath $Audit)) { throw "Missing audit script: $Audit" }

Write-Host "SITE_ROOT=$SiteRoot"
Write-Host "OUTPUT_ROOT=$OutputRoot"

if ($Python.Name -match "^py(\.exe)?$") {
    & $Python.Source -3 $Audit --site-root $SiteRoot --out $OutputRoot
} else {
    & $Python.Source $Audit --site-root $SiteRoot --out $OutputRoot
}
$Code = $LASTEXITCODE

if ($Code -eq 0) {
    Write-Host "STATIC_PREFLIGHT=PASS" -ForegroundColor Green
    Write-Host "NEXT=BROWSER_AND_PUBLIC_DEPLOYMENT_CHECKS" -ForegroundColor Yellow
} elseif ($Code -eq 10) {
    Write-Host "STATIC_PREFLIGHT=FAIL" -ForegroundColor Red
    Write-Host "NEXT=REPAIR_ONLY_OBSERVED_STATIC_DEFECTS_THEN_RERUN" -ForegroundColor Yellow
} else {
    Write-Host "STATIC_PREFLIGHT=BLOCKED" -ForegroundColor Yellow
}

Write-Host "REPORT_MD=$(Join-Path $OutputRoot 'W6_W7_STATIC_PREFLIGHT.md')"
Write-Host "REPORT_JSON=$(Join-Path $OutputRoot 'W6_W7_STATIC_PREFLIGHT.json')"
exit $Code

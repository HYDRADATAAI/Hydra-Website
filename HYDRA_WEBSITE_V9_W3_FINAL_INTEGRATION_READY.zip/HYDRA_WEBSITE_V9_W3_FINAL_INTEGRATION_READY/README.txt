HYDRA WEBSITE V9 - W3 FINAL INTEGRATION

Open index.html for the recruiter front door.
Open constraint-case-study-v2.html for the full technical case study.

This package intentionally keeps the homepage scan-fast while preserving a deeper technical path.
All representative/synthetic/shadow material is visibly labeled.

# NYX Constraint Intelligence T1-T5 — Batch 64 Receipt-Bound Host Builder

This ZIP does **not** pretend Batch 64 is already sealed. It builds Batch 64 only after your local Batch 63 build has produced a real `BATCH63_SEAL_RECEIPT.json`.

## One click

1. Finish Batch 63 with the prior host builder.
2. Leave its output in the default `D:\NYX_BATCH63_BUILD` folder, or keep the sealed Batch 63 ZIP / ten Batch 63 transfer ZIPs plus `BATCH63_SEAL_RECEIPT.json` together.
3. Extract this ZIP.
4. Double-click `RUN_BATCH64_FROM_BATCH63.cmd`.

The runner prefers the already sealed Batch 63 ZIP if present. If absent, it reconstructs Batch 63 from the ten transfer ZIPs. In both cases the bytes and SHA-256 must match the Batch 63 seal receipt exactly before Batch 64 construction begins.

## Batch 64 target

- Packaging: `DELTA_WITH_EXACT_SEALED_PREDECESSOR`
- Boundary: `SYNTHETIC_SHADOW_ONLY`
- Schema profile: `2.46`
- Golden seeds: `64001` through `64012`
- Outer members: `8,915`
- Manifest-governed entries: `8,912`
- Shadow QA checks: `3,409`
- Transfer ZIPs: exactly `10`
- Thread 6: `NOT_STARTED`
- Real production data: not used
- Automatic canonical promotion: disabled
- Baby-ML training: disabled
- Trading-signal generation: disabled

A successful run writes the sealed Batch 64 ZIP, ten Batch 64 transfer ZIPs, and `BATCH64_SEAL_RECEIPT.json`.

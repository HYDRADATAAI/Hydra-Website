$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Evidence = Join-Path $Root '_V12_LOCAL_BROWSER_EVIDENCE'
New-Item -ItemType Directory -Path $Evidence -Force | Out-Null

Write-Host '============================================================' -ForegroundColor Cyan
Write-Host 'HYDRA WEBSITE V12 - LOCAL BROWSER RELEASE PREFLIGHT' -ForegroundColor Cyan
Write-Host '============================================================' -ForegroundColor Cyan
Write-Host "ROOT=$Root"

$Required = @(
  'index.html',
  'constraint-case-study-v2.html',
  'repository.html',
  'assets\site.css',
  'docs\V12_BROWSER_RELEASE_SEAL.json',
  'docs\V12_BROWSER_RELEASE_SEAL.txt',
  'PUBLIC_GITHUB_SYNC_PAYLOAD\README.md'
)
$Failures = New-Object System.Collections.Generic.List[string]
foreach($Rel in $Required){
  $P = Join-Path $Root $Rel
  if(Test-Path -LiteralPath $P){ Write-Host "FILE::$Rel=PASS" -ForegroundColor Green }
  else { Write-Host "FILE::$Rel=FAIL" -ForegroundColor Red; $Failures.Add("MISSING::$Rel") }
}

$SealPath = Join-Path $Root 'docs\V12_BROWSER_RELEASE_SEAL.json'
if(Test-Path $SealPath){
  $Seal = Get-Content $SealPath -Raw | ConvertFrom-Json
  if($Seal.summary.overall -eq 'PASS') { Write-Host 'PACKAGED_BROWSER_SEAL=PASS' -ForegroundColor Green }
  else { Write-Host 'PACKAGED_BROWSER_SEAL=FAIL' -ForegroundColor Red; $Failures.Add('PACKAGED_BROWSER_SEAL') }
}

$Index = Get-Content (Join-Path $Root 'index.html') -Raw
foreach($Token in @('REPRESENTATIVE','SYNTHETIC','SHADOW','Discoverable data is not automatically authorized data.')){
  if($Index.Contains($Token)){ Write-Host "CLAIM_TOKEN::$Token=PASS" -ForegroundColor Green }
  else { Write-Host "CLAIM_TOKEN::$Token=FAIL" -ForegroundColor Red; $Failures.Add("CLAIM_TOKEN::$Token") }
}

# Internal route/file check. External URLs are intentionally not fetched by this local runner.
$HtmlFiles = Get-ChildItem -LiteralPath $Root -File -Filter '*.html'
foreach($Html in $HtmlFiles){
  $Text = Get-Content $Html.FullName -Raw
  $Matches = [regex]::Matches($Text, 'href="([^"]+)"')
  foreach($M in $Matches){
    $Href = $M.Groups[1].Value
    if($Href -match '^(https?://|mailto:|tel:|#)'){ continue }
    $Parts = $Href.Split('#',2)
    $Rel = $Parts[0]
    if([string]::IsNullOrWhiteSpace($Rel)){ continue }
    $Target = Join-Path $Root ($Rel -replace '/', '\')
    if(-not (Test-Path -LiteralPath $Target)){
      Write-Host "BROKEN_ROUTE::$($Html.Name)::$Href" -ForegroundColor Red
      $Failures.Add("BROKEN_ROUTE::$($Html.Name)::$Href")
    }
  }
}
if(-not ($Failures | Where-Object { $_ -like 'BROKEN_ROUTE*' })) { Write-Host 'INTERNAL_ROUTES=PASS' -ForegroundColor Green }

# Optional reproducible screenshots using installed Edge/Chrome.
$BrowserCandidates = @(
  "$env:ProgramFiles(x86)\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "$env:ProgramFiles(x86)\Google\Chrome\Application\chrome.exe"
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
$Browser = $BrowserCandidates | Select-Object -First 1
if($Browser){
  Write-Host "BROWSER=$Browser"
  $Targets = @('index.html','constraint-case-study-v2.html','repository.html')
  $Viewports = @(
    @{Name='desktop';W=1440;H=1000},
    @{Name='tablet';W=820;H=1180},
    @{Name='mobile';W=390;H=844}
  )
  foreach($T in $Targets){
    $Uri = ([uri](Join-Path $Root $T)).AbsoluteUri
    foreach($V in $Viewports){
      $Stem = [IO.Path]::GetFileNameWithoutExtension($T)
      $Shot = Join-Path $Evidence ("{0}_{1}.png" -f $Stem,$V.Name)
      & $Browser --headless=new --disable-gpu --hide-scrollbars "--window-size=$($V.W),$($V.H)" "--screenshot=$Shot" $Uri 2>$null | Out-Null
      if(Test-Path $Shot){ Write-Host "SCREENSHOT::$Stem::$($V.Name)=PASS" -ForegroundColor Green }
      else { Write-Host "SCREENSHOT::$Stem::$($V.Name)=WARN" -ForegroundColor Yellow }
    }
  }
} else {
  Write-Host 'BROWSER_SCREENSHOTS=SKIPPED_NO_EDGE_OR_CHROME_FOUND' -ForegroundColor Yellow
}

$Summary = Join-Path $Evidence 'V12_LOCAL_PREFLIGHT_SUMMARY.txt'
@(
  'HYDRA WEBSITE V12 LOCAL PREFLIGHT',
  "TIMESTAMP=$(Get-Date -Format o)",
  "ROOT=$Root",
  "FAILURE_COUNT=$($Failures.Count)",
  "LOCAL_PREFLIGHT=$(if($Failures.Count -eq 0){'PASS'}else{'FAIL'})",
  'PUBLIC_GITHUB_SYNC_EXECUTED=NO',
  'PUBLIC_DEPLOYMENT_PROOF=NOT_ESTABLISHED_BY_LOCAL_PREFLIGHT'
) | Set-Content -LiteralPath $Summary -Encoding UTF8

Write-Host '============================================================' -ForegroundColor Cyan
Write-Host "FAILURE_COUNT=$($Failures.Count)"
if($Failures.Count -eq 0){
  Write-Host 'OVERALL=PASS_LOCAL_RELEASE_PREFLIGHT' -ForegroundColor Green
  Write-Host "EVIDENCE=$Evidence"
  exit 0
}
Write-Host 'OVERALL=FAIL_LOCAL_RELEASE_PREFLIGHT' -ForegroundColor Red
$Failures | ForEach-Object { Write-Host "FAILURE=$_" -ForegroundColor Red }
exit 1

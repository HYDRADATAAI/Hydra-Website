param(
    [string]$V027Evidence=""
)
$ErrorActionPreference="Stop"
Set-StrictMode -Version Latest

$ExpectedV027="0b14b1dc7ab2603fcb80752c8e057eb003ef575afbd755737145b488a9dc789e"
$ExpectedAnchor="bc95f5f86142084234c2dc954c7f6f192bfcbbdcdf3f77ce53bedbda7262388c"
$AnchorPath="D:\HYDRA\phase0_surface_implementations\constraint_semantics_surface_v001.py"

Write-Host "============================================================"
Write-Host "NYX N2 V028 - RUNTIME BINDING CONTRACT ESCALATION"
Write-Host "============================================================"
Write-Host "DEFECT_ID=N2-DEFECT-023-RUNTIME-ENTRYPOINT-CONTRACT-ABSENT"
Write-Host "FAILED_SEAM=PHASE0_SELECTED_CONSTRAINT_SURFACE_TO_RUNTIME_ENTRYPOINT"
Write-Host "OWNER_LANE=PHASE0_BINDING_RUNTIME_OWNER"
Write-Host "N2_DISPOSITION=PARKED_PENDING_OWNER_REPAIR"
Write-Host "MUTATION_AUTHORIZED=NO"

$Downloads=Join-Path $env:USERPROFILE "Downloads"

if(-not $V027Evidence){
    $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "N2_V027_RETURN_PACKET_*.zip" -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending
    $Found=$null
    foreach($C in $Candidates){
        $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        if($H -eq $ExpectedV027){$Found=$C;break}
    }
    if(-not $Found){
        $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "*V027*RETURN*.zip" -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending
        foreach($C in $Candidates){
            $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            if($H -eq $ExpectedV027){$Found=$C;break}
        }
    }
    if(-not $Found){throw "Exact V027 return packet not found with SHA256=$ExpectedV027"}
    $V027Evidence=$Found.FullName
}

$V027Actual=(Get-FileHash -LiteralPath $V027Evidence -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host "V027_EVIDENCE=$V027Evidence"
Write-Host "V027_EVIDENCE_SHA256=$V027Actual"
if($V027Actual -ne $ExpectedV027){throw "V027 evidence hash mismatch."}
Write-Host "V027_EVIDENCE_HASH_VERIFIED=PASS"

if(-not (Test-Path -LiteralPath $AnchorPath -PathType Leaf)){
    throw "Pinned Constraint semantics anchor missing: $AnchorPath"
}
$AnchorActual=(Get-FileHash -LiteralPath $AnchorPath -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host "ANCHOR_PATH=$AnchorPath"
Write-Host "ANCHOR_SHA256=$AnchorActual"
if($AnchorActual -ne $ExpectedAnchor){throw "Pinned anchor hash drift."}
Write-Host "ANCHOR_HASH_VERIFIED=PASS"

$RunDir="D:\NYX_N2_WORK\V028_RUNTIME_BINDING_ESCALATION_$(Get-Date -Format yyyyMMdd_HHmmss)"
$ReturnDir=Join-Path $RunDir "N2_V028_RETURN"
New-Item -ItemType Directory -Path $ReturnDir -Force|Out-Null

$Receipt=[ordered]@{
    version="N2_V028_RUNTIME_BINDING_CONTRACT_ESCALATION"
    final="ESCALATED_TO_PHASE0_BINDING_RUNTIME_OWNER"
    defect_id="N2-DEFECT-023-RUNTIME-ENTRYPOINT-CONTRACT-ABSENT"
    failed_seam="PHASE0_SELECTED_CONSTRAINT_SURFACE_TO_RUNTIME_ENTRYPOINT"
    owner_lane="PHASE0_BINDING_RUNTIME_OWNER"
    exact_cause="Authoritative binding receipts select the Constraint semantics surface but contain no explicit runtime entrypoint/runner/launcher/executable/script/loader field; resolved selection targets are non-executable and no child runtime entrypoint is proven."
    minimum_repair="Owner lane must expose one explicit authoritative runtime binding contract to a legitimate pre-existing executable entrypoint. Do not fabricate or infer a loader. If none exists, return BLOCKED_BY_MISSING_RUNTIME_AUTHORITY."
    v027_evidence=$V027Evidence
    v027_sha256=$V027Actual
    anchor_path=$AnchorPath
    anchor_sha256=$AnchorActual
    baseline_mutated="NO"
    canonical_core_mutated="NO"
    n2_mutated="NO"
    n2_adjudication_semantics_changed="NO"
    rerun_result="NOT_RUN_PENDING_OWNER_REPAIR"
    n2_disposition="PARKED_PENDING_OWNER_REPAIR"
    next_action="PHASE0_BINDING_RUNTIME_OWNER_REPAIR_OR_BLOCKER"
}

$ReceiptPath=Join-Path $ReturnDir "N2_V028_RUNTIME_BINDING_CONTRACT_ESCALATION_RECEIPT.json"
$Receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $ReceiptPath -Encoding UTF8

$Txt=@"
NYX N2 V028 RUNTIME BINDING CONTRACT ESCALATION
FINAL=ESCALATED_TO_PHASE0_BINDING_RUNTIME_OWNER
DEFECT_ID=N2-DEFECT-023-RUNTIME-ENTRYPOINT-CONTRACT-ABSENT
FAILED_SEAM=PHASE0_SELECTED_CONSTRAINT_SURFACE_TO_RUNTIME_ENTRYPOINT
OWNER_LANE=PHASE0_BINDING_RUNTIME_OWNER
EXACT_CAUSE=Authoritative binding receipts select the Constraint semantics surface but contain no explicit runtime entrypoint/runner/launcher/executable/script/loader field; resolved selection targets are non-executable and no child runtime entrypoint is proven.
MINIMUM_REPAIR=Owner lane must expose one explicit authoritative runtime binding contract to a legitimate pre-existing executable entrypoint. Do not fabricate or infer a loader. If none exists, return BLOCKED_BY_MISSING_RUNTIME_AUTHORITY.
BASELINE_MUTATED=NO
CANONICAL_CORE_MUTATED=NO
N2_MUTATED=NO
RERUN_RESULT=NOT_RUN_PENDING_OWNER_REPAIR
N2_DISPOSITION=PARKED_PENDING_OWNER_REPAIR
NEXT_ACTION=PHASE0_BINDING_RUNTIME_OWNER_REPAIR_OR_BLOCKER
"@
$TxtPath=Join-Path $ReturnDir "N2_V028_RUNTIME_BINDING_CONTRACT_ESCALATION_SUMMARY.txt"
$Txt | Set-Content -LiteralPath $TxtPath -Encoding UTF8

$ReturnZip=Join-Path $Downloads ("N2_V028_RUNTIME_BINDING_CONTRACT_ESCALATION_RETURN_{0}.zip" -f (Get-Date -Format yyyyMMdd_HHmmss))
Compress-Archive -Path (Join-Path $ReturnDir "*") -DestinationPath $ReturnZip -CompressionLevel Optimal
$ReturnSha=(Get-FileHash -LiteralPath $ReturnZip -Algorithm SHA256).Hash.ToLowerInvariant()

Write-Host ""
Write-Host "============================================================"
Write-Host "N2 V028 FINAL"
Write-Host "============================================================"
Write-Host "FINAL=ESCALATED_TO_PHASE0_BINDING_RUNTIME_OWNER"
Write-Host "DEFECT_ID=N2-DEFECT-023-RUNTIME-ENTRYPOINT-CONTRACT-ABSENT"
Write-Host "FAILED_SEAM=PHASE0_SELECTED_CONSTRAINT_SURFACE_TO_RUNTIME_ENTRYPOINT"
Write-Host "OWNER_LANE=PHASE0_BINDING_RUNTIME_OWNER"
Write-Host "BASELINE_MUTATED=NO"
Write-Host "CANONICAL_CORE_MUTATED=NO"
Write-Host "N2_MUTATED=NO"
Write-Host "RERUN_RESULT=NOT_RUN_PENDING_OWNER_REPAIR"
Write-Host "N2_DISPOSITION=PARKED_PENDING_OWNER_REPAIR"
Write-Host "RETURN_ZIP=$ReturnZip"
Write-Host "RETURN_SHA256=$ReturnSha"
Write-Host "RETURN_RUN_DIR=$RunDir"

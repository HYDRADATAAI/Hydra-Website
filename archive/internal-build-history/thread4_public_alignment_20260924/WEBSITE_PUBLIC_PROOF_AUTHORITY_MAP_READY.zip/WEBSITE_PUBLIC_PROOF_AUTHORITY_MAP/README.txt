WEBSITE_PUBLIC_PROOF_AUTHORITY_MAP

W1_ACCEPTANCE=PASS
PUBLIC_CLAIM_GATE=PASS

Open WEBSITE_PUBLIC_PROOF_AUTHORITY_MAP.md for the human-readable gate.
Use WEBSITE_PUBLIC_PROOF_AUTHORITY_MAP.csv for filtering/sorting.
Use WEBSITE_PUBLIC_PROOF_AUTHORITY_MAP.json for automation or website tooling.

Key W1 rule:
No website claim is allowed merely because an internal label sounds impressive.
Every current-capability claim must resolve to receipt-backed evidence and retain its evidence class.

Important:
W1 promotes zero claims to REAL.
Strong current proof is primarily INTEGRATED component evidence or explicitly SHADOW/SYNTHETIC evidence.

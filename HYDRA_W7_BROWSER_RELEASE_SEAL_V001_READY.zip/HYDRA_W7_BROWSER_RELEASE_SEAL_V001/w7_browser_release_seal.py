#!/usr/bin/env python3
from pathlib import Path
from urllib.parse import urljoin
from urllib.request import Request, urlopen
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import argparse, base64, datetime, html, json, os, re, shutil, subprocess, sys, threading

VIEWPORTS={"desktop":(1440,1000),"tablet":(1024,1366),"mobile":(390,844)}
PRE='''<script id="__w7_pre">(function(){window.__W7E=[];function p(k,m){try{window.__W7E.push({kind:String(k),message:String(m)})}catch(_){}}window.addEventListener("error",function(e){if(e&&e.target&&e.target!==window){p("resource_error",(e.target.tagName||"RESOURCE")+":"+(e.target.src||e.target.href||""))}else{p("window_error",(e&&(e.message||e.error))||"unknown")}},true);window.addEventListener("unhandledrejection",function(e){p("unhandled_rejection",e&&e.reason?e.reason:"unknown")});var o=console.error;console.error=function(){p("console_error",Array.prototype.map.call(arguments,String).join(" "));if(o)o.apply(console,arguments)}})();</script>'''
PROBE='''<script id="__w7_probe">setTimeout(function(){try{function v(el){var s=getComputedStyle(el),r=el.getBoundingClientRect();return s.display!=="none"&&s.visibility!=="hidden"&&parseFloat(s.opacity||"1")>0&&r.width>0&&r.height>0}var a=[].slice.call(document.body?document.body.querySelectorAll("*"):[]);var ov=a.filter(function(el){if(!v(el))return false;var r=el.getBoundingClientRect();return r.right>innerWidth+2||r.left<-2}).slice(0,30).map(function(el){var r=el.getBoundingClientRect();return{tag:el.tagName,id:el.id||"",cls:(typeof el.className==="string"?el.className:"").slice(0,100),left:Math.round(r.left),right:Math.round(r.right)}});var imgs=[].slice.call(document.images||[]).map(function(im){return{src:im.currentSrc||im.src||"",complete:!!im.complete,naturalWidth:+(im.naturalWidth||0),naturalHeight:+(im.naturalHeight||0),visible:v(im)}});var te=a.filter(function(el){return v(el)&&(!el.children||!el.children.length)&&(el.textContent||"").trim().length>0});var fs=te.map(function(el){return parseFloat(getComputedStyle(el).fontSize||"0")}).filter(function(x){return isFinite(x)&&x>0});var d={url:location.href,title:document.title||"",viewport:{w:innerWidth,h:innerHeight},doc:{scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth,bodyTextLength:(document.body&&document.body.innerText?document.body.innerText.trim().length:0)},horizontalOverflow:document.documentElement.scrollWidth>innerWidth+2,overflowElements:ov,jsErrors:window.__W7E||[],images:imgs,brokenImages:imgs.filter(function(x){return x.complete&&x.naturalWidth===0}),visibleTextElements:te.length,minFontPx:fs.length?Math.min.apply(null,fs):null,tinyTextCountUnder9Px:fs.filter(function(x){return x<9}).length};var s=unescape(encodeURIComponent(JSON.stringify(d)));document.documentElement.setAttribute("data-w7-probe",btoa(s))}catch(e){document.documentElement.setAttribute("data-w7-probe-error",String(e&&e.message?e.message:e))}},1200);</script>'''

def browser_path():
    c=[]
    for cmd in ("chrome","chrome.exe","msedge","msedge.exe"):
        p=shutil.which(cmd)
        if p:c.append(Path(p))
    for root in (os.getenv("PROGRAMFILES"),os.getenv("PROGRAMFILES(X86)"),os.getenv("LOCALAPPDATA")):
        if root:
            r=Path(root); c += [r/"Google/Chrome/Application/chrome.exe",r/"Microsoft/Edge/Application/msedge.exe"]
    return next((p for p in c if p.exists()),None)

def inject(s):
    if '__w7_pre' not in s:
        m=re.search(r'(?is)<head\b[^>]*>',s); s=s[:m.end()]+PRE+s[m.end():] if m else PRE+s
    if '__w7_probe' not in s:
        m=re.search(r'(?is)</body\s*>',s); s=s[:m.start()]+PROBE+s[m.start():] if m else s+PROBE
    return s

def copy_site(src,dst):
    if dst.exists():shutil.rmtree(dst)
    shutil.copytree(src,dst)
    hs=sorted(dst.rglob('*.html'))
    for p in hs:p.write_text(inject(p.read_text(encoding='utf-8',errors='replace')),encoding='utf-8')
    return hs

class Q(SimpleHTTPRequestHandler):
    def log_message(self,*a):pass

def serve(d):
    class H(Q):
        def __init__(self,*a,**k):super().__init__(*a,directory=str(d),**k)
    s=ThreadingHTTPServer(('127.0.0.1',0),H); threading.Thread(target=s.serve_forever,daemon=True).start(); return s,s.server_address[1]

def status(url):
    try:
        with urlopen(Request(url,headers={'User-Agent':'HYDRA-W7/1.0'}),timeout=10) as r:return int(getattr(r,'status',200)),r.geturl()
    except Exception as e:return int(getattr(e,'code',0) or 0),str(e)

def probe(dom):
    m=re.search(r'data-w7-probe="([^"]+)"',dom)
    if not m:return None
    try:return json.loads(base64.b64decode(html.unescape(m.group(1))).decode('utf-8'))
    except:return None

def safe(s):return re.sub(r'[^A-Za-z0-9._-]+','_',s)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--site-root',required=True); ap.add_argument('--out',required=True); ap.add_argument('--public-url',default=''); a=ap.parse_args()
    root=Path(a.site_root).resolve(); out=Path(a.out).resolve(); out.mkdir(parents=True,exist_ok=True)
    if not (root/'index.html').exists():print('BLOCKED=SITE_ROOT_OR_INDEX_MISSING'); return 20
    b=browser_path()
    if not b:print('BLOCKED=BROWSER_NOT_FOUND'); return 21
    mirror=out/'_instrumented_site'; hs=copy_site(root,mirror); rels=[str(p.relative_to(mirror)).replace('\\','/') for p in hs]
    srv,port=serve(mirror); base=f'http://127.0.0.1:{port}/'; hard=[]; warns=[]; rows=[]; shots=[]
    try:
      for rel in rels:
        u=urljoin(base,rel); st,rr=status(u)
        if st!=200:hard.append({'type':'LOCAL_ROUTE_STATUS','page':rel,'status':st,'detail':rr})
        for vp,(w,h) in VIEWPORTS.items():
          key=safe(rel)+'__'+vp; (out/'dom').mkdir(exist_ok=True); (out/'stderr').mkdir(exist_ok=True); (out/'screenshots').mkdir(exist_ok=True); prof=out/'profiles'/key; prof.mkdir(parents=True,exist_ok=True)
          args=[str(b),'--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking',f'--window-size={w},{h}','--virtual-time-budget=3500',f'--user-data-dir={prof}','--dump-dom',u]
          try:cp=subprocess.run(args,text=True,capture_output=True,timeout=45)
          except Exception as e:hard.append({'type':'BROWSER_EXCEPTION','page':rel,'viewport':vp,'detail':str(e)});continue
          (out/'dom'/f'{key}.html').write_text(cp.stdout or '',encoding='utf-8',errors='replace'); (out/'stderr'/f'{key}.txt').write_text(cp.stderr or '',encoding='utf-8',errors='replace')
          pr=probe(cp.stdout or ''); png=out/'screenshots'/f'{key}.png'
          sargs=[str(b),'--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--hide-scrollbars',f'--window-size={w},{h}','--virtual-time-budget=2500',f'--user-data-dir={prof}',f'--screenshot={png}',u]
          try:sc=subprocess.run(sargs,text=True,capture_output=True,timeout=45); scode=sc.returncode
          except Exception as e:scode=999
          if png.exists():shots.append(str(png.relative_to(out)).replace('\\','/'))
          rows.append({'page':rel,'viewport':vp,'browser_exit':cp.returncode,'screenshot_exit':scode,'probe':pr})
          if cp.returncode!=0:hard.append({'type':'BROWSER_EXIT','page':rel,'viewport':vp,'code':cp.returncode})
          if pr is None:hard.append({'type':'PROBE_MISSING','page':rel,'viewport':vp});continue
          if pr.get('horizontalOverflow'):hard.append({'type':'HORIZONTAL_OVERFLOW','page':rel,'viewport':vp,'elements':pr.get('overflowElements',[])[:8]})
          if pr.get('jsErrors'):hard.append({'type':'JS_RUNTIME_ERRORS','page':rel,'viewport':vp,'errors':pr.get('jsErrors',[])[:8]})
          if pr.get('brokenImages'):hard.append({'type':'BROKEN_IMAGES','page':rel,'viewport':vp,'images':pr.get('brokenImages',[])[:8]})
          if (pr.get('doc') or {}).get('bodyTextLength',0)<20:hard.append({'type':'READABILITY_EMPTY_CONTENT','page':rel,'viewport':vp})
          if (pr.get('tinyTextCountUnder9Px') or 0)>0:warns.append({'type':'TINY_TEXT_UNDER_9PX','page':rel,'viewport':vp,'count':pr['tinyTextCountUnder9Px']})
          if scode!=0 or not png.exists():hard.append({'type':'SCREENSHOT_FAILURE','page':rel,'viewport':vp,'code':scode})
    finally:srv.shutdown();srv.server_close()
    gs,gr=status('https://github.com/HYDRADATAAI/hydra-website')
    if gs not in (200,301,302):hard.append({'type':'GITHUB_PUBLIC_STATUS','status':gs,'detail':gr})
    pu=a.public_url.strip(); pc={'supplied':bool(pu),'url':pu or None,'status':None,'resolved':None}
    if pu:
      ps,pr=status(pu); pc.update(status=ps,resolved=pr)
      if ps not in (200,301,302):hard.append({'type':'PUBLIC_DEPLOYMENT_STATUS','status':ps,'detail':pr})
    else:warns.append({'type':'PUBLIC_DEPLOYMENT_URL_NOT_SUPPLIED'})
    vs={vp:('FAIL' if any(x.get('viewport')==vp for x in hard) else 'PASS') for vp in VIEWPORTS}
    local='PASS_BROWSER_LOCAL' if not [x for x in hard if x.get('type')!='PUBLIC_DEPLOYMENT_STATUS'] else 'FAIL_BROWSER_LOCAL'
    seal='PASS' if local=='PASS_BROWSER_LOCAL' and pu and pc['status'] in (200,301,302) else 'BLOCKED'
    rep={'artifact':'HYDRA_W7_BROWSER_RELEASE_SEAL_V001','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'site_root':str(root),'browser':str(b),'pages':rels,'viewport_summary':vs,'results':rows,'hard_failures':hard,'warnings':warns,'screenshots':shots,'github_public_check':{'url':'https://github.com/HYDRADATAAI/hydra-website','status':gs,'resolved':gr},'public_deployment_check':pc,'browser_local_verdict':local,'public_release_seal':seal}
    (out/'W7_BROWSER_RELEASE_SEAL.json').write_text(json.dumps(rep,indent=2),encoding='utf-8')
    md=['# HYDRA W7 Browser Release Seal','',f'`BROWSER_LOCAL_VERDICT={local}`',f'`PUBLIC_RELEASE_SEAL={seal}`',f'`HARD_FAILURES={len(hard)}`',f'`WARNINGS={len(warns)}`','']+[f'- `{k.upper()}={v}`' for k,v in vs.items()]
    if not pu:md+=['','Public deployment is not certified until a real public site URL is supplied.']
    (out/'W7_BROWSER_RELEASE_SEAL.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
    print(f'BROWSER={b}');print(f'PAGES_TESTED={len(rels)}');print(f'SCREENSHOTS={len(shots)}');[print(f'{k.upper()}={v}') for k,v in vs.items()];print(f'GITHUB_PUBLIC_STATUS={gs}');print(f'HARD_FAILURES={len(hard)}');print(f'WARNINGS={len(warns)}');print(f'BROWSER_LOCAL_VERDICT={local}');print(f'PUBLIC_DEPLOYMENT_URL_SUPPLIED={"YES" if pu else "NO"}');
    if pu:print(f'PUBLIC_DEPLOYMENT_STATUS={pc["status"]}')
    print(f'PUBLIC_RELEASE_SEAL={seal}');print(f'REPORT_JSON={out/"W7_BROWSER_RELEASE_SEAL.json"}');print(f'REPORT_MD={out/"W7_BROWSER_RELEASE_SEAL.md"}')
    return 10 if local!='PASS_BROWSER_LOCAL' else (12 if not pu else (13 if seal!='PASS' else 0))
if __name__=='__main__':raise SystemExit(main())

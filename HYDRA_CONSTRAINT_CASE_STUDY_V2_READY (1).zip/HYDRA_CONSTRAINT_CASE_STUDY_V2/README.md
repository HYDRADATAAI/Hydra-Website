# HYDRA Constraint Case Study V2

Standalone preview:
- `index.html`

Drop-in website files:
- `case-study-component.html`
- `case-study.css`

Evidence map:
- `case-study-data.json`

Review:
- `W3_BUILD_REPORT.md`
- `W3_VALIDATION.md`

This package deliberately treats blocked authority as a valid engineering result.

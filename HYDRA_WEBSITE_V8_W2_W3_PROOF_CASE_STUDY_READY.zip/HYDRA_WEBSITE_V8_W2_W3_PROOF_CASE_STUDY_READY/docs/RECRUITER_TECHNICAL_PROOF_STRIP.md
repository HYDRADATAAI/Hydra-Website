# RECRUITER_TECHNICAL_PROOF_STRIP

## Goal
Give a technical recruiter or engineer a complete HYDRA engineering loop in roughly 30–90 seconds.

## Sequence
`INGEST → NORMALIZE → CONTRACT → TRACE → VALIDATE → DEFECT → RESOLUTION → OUTPUT`

## Public-safe proof choices
- **INGEST / NORMALIZE / OUTPUT:** representative market-data structures, explicitly labeled non-live.
- **CONTRACT:** the real CI-TEST-008 native handoff field requirement.
- **TRACE:** the real CI-TEST-006 lineage and reverse-reference checks.
- **VALIDATE / DEFECT / REPAIR:** the real CI-TEST-004 defect-scoped repaired rerun.
- **RESOLUTION / BLOCK:** the real CI-TEST-008 authoritative-source block with `semantic_values_invented=false`.

## Recruiter takeaway
HYDRA treats source identity, contracts, authority, lineage, quarantine, validation, and release behavior as explicit engineering surfaces.

## Acceptance
PASS: the strip can be understood without knowing HYDRA's internal version history. Internal versions appear only inside tiny proof snippets where they authenticate a result.

# HYDRA Website V6 — Recruiter System + Engineering Proof

A dependency-free static project site for HYDRA, positioned as a market-intelligence data engineering platform with a visible proof layer behind the recruiter-facing story.

## Pages

- `index.html` — recruiter-facing overview and system hook
- `architecture.html` — interactive architecture explorer and AWS target mapping
- `constraint.html` — Constraint Intelligence domain model
- `lab.html` — browser-only integrity/failure-semantics simulation
- `proof.html` — engineering proof, defect discipline, and receipt model
- `roadmap.html` — data → AWS → analytical operations → intelligence roadmap
- `404.html` — custom error page

## Public positioning

The front page stays simple:

**HYDRA / MARKET INTELLIGENCE DATA PLATFORM**

**Turn fragmented market data into traceable intelligence.**

The deeper pages carry the technical proof. The site should not force a recruiter to decode internal architecture before understanding what HYDRA is.

## Engineering proof model

V6 adds a dedicated proof surface around the operating pattern:

`TEST → NAME DEFECT → MINIMUM REPAIR → RERUN → FREEZE`

The public case study explains a real class of authority-scope failure without exposing private project material or inventing production claims.

## Configure public links

Open `site.config.js`:

```js
window.HYDRA_CONFIG = {
  ownerName: "Cody",
  repositoryUrl: "",
  linkedinUrl: "",
  contactEmail: "",
  repositoryLabel: "Repository"
};
```

- Empty `repositoryUrl`: repository buttons and section stay hidden.
- Empty `linkedinUrl`: LinkedIn controls stay hidden.
- Empty `contactEmail`: contact controls stay hidden.

Nothing unfinished is advertised by default.

## Preview locally

Simplest: double-click `index.html`.

Better: run `OPEN_HYDRA_SITE.ps1`. If Python is installed it starts a local server at `http://localhost:8080/`; otherwise it opens the static page directly.

## GitHub Pages

The package includes `.github/workflows/pages.yml` and `.nojekyll`.

1. Put the site in the public repository.
2. Push to the default branch.
3. In GitHub, use **Settings → Pages → Source → GitHub Actions**.

No npm install, framework build, CDN, remote fonts, analytics, or third-party JavaScript are required.

## Design / truth rules

1. Current capabilities lead the recruiter-facing story.
2. Future AWS/GenAI work stays in the roadmap until implemented.
3. Browser demonstrations are labeled as simulations.
4. No fake production metrics or fabricated field ownership.
5. Real proof should gradually replace conceptual surfaces as HYDRA's public repo is cleaned.
6. The landing-page visual direction is frozen unless there is a concrete usability problem.

## Next content upgrades

- Configure the real GitHub, LinkedIn, and contact surfaces.
- Add one sanitized market-constraint case from source evidence through final classification.
- Add one genuine AWS vertical slice after it is implemented and tested.
- Replace conceptual architecture blocks with diagrams exported from the actual public HYDRA repo.
- Add selected logs, receipts, or screenshots only when they improve comprehension.

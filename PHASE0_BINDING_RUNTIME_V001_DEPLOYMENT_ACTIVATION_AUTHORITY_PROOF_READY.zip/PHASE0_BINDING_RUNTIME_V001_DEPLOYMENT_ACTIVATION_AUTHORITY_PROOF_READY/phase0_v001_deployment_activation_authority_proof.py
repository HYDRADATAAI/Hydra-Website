
from __future__ import annotations
import argparse, hashlib, json, ntpath, os, re, shutil, tempfile
from pathlib import Path
from typing import Any, Mapping

EXPECTED_V031_SHA256 = "620677b7e81a29e77627879dc9005e5bd696dff12be8d037e6e45a8699f8cf1b"
DEPLOYMENT_ROOTS = ['D:\\HYDRA\\execution_runtime\\nyx_175_phase0_real_v001', 'D:\\HYDRA\\execution_runtime\\nyx_phase0_host_preflight_20260906_165307']

TEXT_EXTS = {".json",".yaml",".yml",".toml",".ini",".cfg",".py",".ps1",".cmd",".bat"}
EXEC_EXTS = {".py",".ps1",".cmd",".bat"}

NAME_RX = re.compile(r"(?i)(phase0|binding|runtime|activation|deploy|entrypoint|runner|launcher|manifest|config|receipt|bootstrap)")
DEPLOYMENT_KEY_RX = re.compile(r"(?i)(active_?deployment|deployment_?root|runtime_?root|selected_?deployment|active_?root|deployment)")
ENTRYPOINT_KEY_RX = re.compile(r"(?i)(runtime_?entrypoint|entry_?point|runner|launcher|loader|executable|bootstrap|script|command)")

EXCLUDED_PARTS = {
    ".git",".hg",".svn","__pycache__",".pytest_cache",".mypy_cache",
    "node_modules","site-packages","dist-packages",".venv","venv","env",
    "archive","archives","_archive","backup","backups","_backup",
    "stash","_stash","hydra stash","temp","tmp","downloads","test_results",
    "fixtures","fixture","quarantine","tests","test",
}
EXCLUDED_SUBSTRINGS = {"_zip_control_layer_temp","_verify_","verification"}

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()

def canon(v: str) -> str:
    s=str(v).strip().strip("'\"").replace("/","\\")
    while "\\\\" in s:
        s=s.replace("\\\\","\\")
    s=ntpath.normpath(s)
    if re.match(r"^[A-Za-z]:",s):
        s=s[0].upper()+s[1:]
    return s.casefold()

def display(v: str) -> str:
    s=str(v).strip().strip("'\"").replace("/","\\")
    while "\\\\" in s:
        s=s.replace("\\\\","\\")
    s=ntpath.normpath(s)
    if re.match(r"^[A-Za-z]:",s):
        s=s[0].upper()+s[1:]
    return s

def is_win_path(v: Any) -> bool:
    return isinstance(v,str) and bool(re.match(r"^[A-Za-z]:[\\/]",v.strip()))

def is_excluded(path: Path, root: Path) -> bool:
    try: rel=path.relative_to(root)
    except Exception: rel=path
    parts=[p.casefold() for p in rel.parts]
    for part in parts[:-1]:
        if part in EXCLUDED_PARTS:return True
        if any(x in part for x in EXCLUDED_SUBSTRINGS):return True
        if part.startswith("_nyx_") and "verify" in part:return True
    return False

def recursive(obj: Any, ptr="#"):
    if isinstance(obj,Mapping):
        yield ptr,obj
        for k,v in obj.items():
            yield from recursive(v,ptr+"/"+str(k))
    elif isinstance(obj,list):
        for i,v in enumerate(obj):
            yield from recursive(v,ptr+"/"+str(i))

def extract_script_candidates(value: str, source: Path, hydra_root: Path):
    vals=[]
    s=value.strip()
    if is_win_path(s):
        vals.append(Path(display(s)))
    for m in re.finditer(r'(?i)([A-Za-z]:[\\/][^"\']+?\.(?:py|ps1|cmd|bat)|[A-Za-z0-9_.$%{}()/:\\+-]+\.(?:py|ps1|cmd|bat))',s):
        raw=m.group(1).strip()
        if is_win_path(raw):
            vals.append(Path(display(raw)))
        else:
            vals.extend([source.parent/raw,hydra_root/raw])
    uniq={}
    for p in vals:uniq[canon(str(p))]=p
    return list(uniq.values())

def inspect_json_contract(path: Path, hydra_root: Path):
    try:doc=json.loads(path.read_text(encoding="utf-8"))
    except Exception:return []

    root_canons={canon(r):r for r in DEPLOYMENT_ROOTS}
    contracts=[]
    for ptr,obj in recursive(doc):
        if not isinstance(obj,Mapping):continue
        deployment_fields=[]
        entrypoint_fields=[]

        for k,v in obj.items():
            if not isinstance(v,str):continue
            kc=str(k)

            if DEPLOYMENT_KEY_RX.search(kc):
                vc=canon(v)
                for rc,raw_root in root_canons.items():
                    if vc==rc:
                        deployment_fields.append({"key":kc,"value":v,"deployment_root":raw_root})

            if ENTRYPOINT_KEY_RX.search(kc):
                for candidate in extract_script_candidates(v,path,hydra_root):
                    exists=candidate.is_file()
                    if exists and candidate.suffix.casefold() in EXEC_EXTS:
                        entrypoint_fields.append({
                            "key":kc,
                            "value":v,
                            "resolved_path":str(candidate),
                            "sha256":sha256_file(candidate),
                        })

        if deployment_fields and entrypoint_fields:
            contracts.append({
                "pointer":ptr,
                "deployment_fields":deployment_fields,
                "entrypoint_fields":entrypoint_fields,
                "basis":"SAME_OBJECT_EXPLICIT_DEPLOYMENT_ROOT_PLUS_RUNNABLE_ENTRYPOINT",
            })
    return contracts

def inspect_text_contract(path: Path, hydra_root: Path):
    try:text=path.read_text(encoding="utf-8",errors="ignore")
    except Exception:return []

    root_hits=[r for r in DEPLOYMENT_ROOTS if canon(r) in canon(text)]
    if not root_hits:return []

    low=text.casefold()
    if not any(term in low for term in ("deployment","activation","runtime","entrypoint","runner","launcher")):
        return []

    scripts=[]
    for m in re.finditer(r'(?i)([A-Za-z]:[\\/][^"\']+?\.(?:py|ps1|cmd|bat)|[A-Za-z0-9_.$%{}()/:\\+-]+\.(?:py|ps1|cmd|bat))',text):
        raw=m.group(1).strip()
        cands=[Path(display(raw))] if is_win_path(raw) else [path.parent/raw,hydra_root/raw]
        for c in cands:
            try:
                if c.is_file() and c.suffix.casefold() in EXEC_EXTS:
                    scripts.append({"raw":raw,"resolved_path":str(c),"sha256":sha256_file(c)})
                    break
            except Exception:pass

    if not scripts:return []
    return [{
        "pointer":"TEXT_SURFACE",
        "deployment_fields":[{"key":"TEXT_EXACT_ROOT","value":r,"deployment_root":r} for r in root_hits],
        "entrypoint_fields":scripts,
        "basis":"TEXT_EXACT_DEPLOYMENT_ROOT_PLUS_RUNNABLE_ENTRYPOINT_WITH_ACTIVATION_LANGUAGE",
    }]

def selftest():
    td=Path(tempfile.mkdtemp(prefix="phase0v001_"))
    try:
        root=td/"HYDRA";execroot=root/"execution_runtime";execroot.mkdir(parents=True)
        dep=execroot/"active";dep.mkdir()
        runner=execroot/"RUN_ACTIVE.py";runner.write_text("print('run')\n",encoding="utf-8")
        manifest=execroot/"activation_manifest.json"
        manifest.write_text(json.dumps({"deployment_root":str(dep),"runtime_entrypoint":"RUN_ACTIVE.py"}),encoding="utf-8")

        global DEPLOYMENT_ROOTS
        old=DEPLOYMENT_ROOTS
        DEPLOYMENT_ROOTS=[str(dep)]
        try:
            found=inspect_json_contract(manifest,root)
            assert len(found)==1
            assert found[0]["entrypoint_fields"][0]["resolved_path"]==str(runner)
        finally:
            DEPLOYMENT_ROOTS=old

        bad=execroot/"selection.json"
        bad.write_text(json.dumps({"selected_path":str(dep)}),encoding="utf-8")
        DEPLOYMENT_ROOTS=[str(dep)]
        try:
            assert not inspect_json_contract(bad,root)
        finally:
            DEPLOYMENT_ROOTS=old

        print("PHASE0_V001_SELFTEST=PASS")
        print("PHASE0_V001_SAME_OBJECT_CONTRACT_GATE=PASS")
        print("PHASE0_V001_RUNNABLE_ENTRYPOINT_RESOLUTION=PASS")
        print("PHASE0_V001_SELECTED_PATH_ONLY_REJECTED=PASS")
        print("PHASE0_V001_NO_MTIME_OR_FOLDERNAME_AUTHORITY=PASS")
    finally:
        shutil.rmtree(td,ignore_errors=True)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--hydra-root",default=r"D:\HYDRA")
    ap.add_argument("--v031-evidence")
    ap.add_argument("--output-dir")
    ap.add_argument("--selftest",action="store_true")
    args=ap.parse_args()
    if args.selftest:selftest();return 0

    hydra=Path(args.hydra_root);ev=Path(args.v031_evidence);outdir=Path(args.output_dir)
    if not hydra.is_dir():raise RuntimeError(f"HYDRA root missing: {hydra}")
    if not ev.is_file():raise RuntimeError(f"V031 evidence missing: {ev}")
    if sha256_file(ev)!=EXPECTED_V031_SHA256:raise RuntimeError("V031 evidence SHA256 mismatch")

    exec_root=hydra/"execution_runtime"
    if not exec_root.is_dir():raise RuntimeError(f"execution_runtime missing: {exec_root}")

    root_receipts=[{"path":r,"exists":Path(r).is_dir()} for r in DEPLOYMENT_ROOTS]

    candidate_files=[]
    for cur,dirs,files in os.walk(exec_root,topdown=True):
        cp=Path(cur)
        dirs[:]=[d for d in dirs if not is_excluded(cp/d/"__probe__.json",exec_root)]
        for fn in files:
            p=cp/fn
            if p.suffix.casefold() not in TEXT_EXTS or is_excluded(p,exec_root):continue
            if not NAME_RX.search(p.name) and not NAME_RX.search(str(p.parent)):continue
            try:
                if p.stat().st_size>5_000_000:continue
            except Exception:continue
            candidate_files.append(p)

    contract_hits=[]
    for p in candidate_files:
        rows=inspect_json_contract(p,hydra) if p.suffix.casefold()==".json" else inspect_text_contract(p,hydra)
        for row in rows:
            contract_hits.append({"contract_path":str(p),"contract_sha256":sha256_file(p),**row})

    combos={}
    for hit in contract_hits:
        for df in hit["deployment_fields"]:
            for ef in hit["entrypoint_fields"]:
                root=display(df["deployment_root"]);entry=display(ef["resolved_path"])
                combos[(canon(root),canon(entry))]={
                    "deployment_root":root,
                    "runtime_entrypoint_path":entry,
                    "runtime_entrypoint_sha256":ef["sha256"],
                    "contract_path":hit["contract_path"],
                    "contract_sha256":hit["contract_sha256"],
                    "basis":hit["basis"],
                    "pointer":hit["pointer"],
                    "deployment_field":df,
                    "entrypoint_field":ef,
                }

    proven=list(combos.values())
    if len(proven)==1:
        status="DEPLOYMENT_ACTIVATION_CONTRACT_PROVEN";defect=None;selected=proven[0]
        next_action="RETURN_OWNER_EVIDENCE_TO_N2_REOPEN_GATE_AND_RERUN_V030"
    elif len(proven)>1:
        status="MULTIPLE_DEPLOYMENT_ACTIVATION_CONTRACTS_AMBIGUOUS";defect="PHASE0-DEFECT-001-DEPLOYMENT-ACTIVATION-AUTHORITY-AMBIGUOUS";selected=None
        next_action="STOP_NO_MUTATION_ADJUDICATE_EXPLICIT_CONTRACT_AMBIGUITY_ONLY"
    else:
        status="BLOCKED_BY_MISSING_DEPLOYMENT_ACTIVATION_AUTHORITY";defect="PHASE0-DEFECT-001-DEPLOYMENT-ACTIVATION-CONTRACT-ABSENT";selected=None
        next_action="STOP_NO_MUTATION_OWNER_BLOCKER_CONFIRMED"

    result={
        "version":"PHASE0_BINDING_RUNTIME_V001_DEPLOYMENT_ACTIVATION_AUTHORITY_PROOF",
        "source_defect":"N2-DEFECT-026-HIGHER-ORDER-DEPLOYMENT-BINDING-NOT-PROVEN",
        "failed_seam":"PHASE0_DEPLOYMENT_ROOT_TO_RUNTIME_ACTIVATION",
        "owner_lane":"PHASE0_BINDING_RUNTIME",
        "v031_sha256":sha256_file(ev),
        "hydra_root":str(hydra),
        "deployment_roots":root_receipts,
        "candidate_file_count":len(candidate_files),
        "files_scanned":len(candidate_files),
        "contract_hit_count":len(contract_hits),
        "unique_activation_combo_count":len(proven),
        "contract_hits":contract_hits,
        "activation_combos":proven,
        "selected_activation_contract":selected,
        "status":status,
        "defect_id":defect,
        "next_action":next_action,
        "read_only":True,
        "baseline_mutated":False,
        "canonical_core_mutated":False,
        "constraint_semantics_mutated":False,
        "n2_mutated":False,
        "mtime_authority":False,
        "newest_wins":False,
        "directory_name_activity_inference":False,
        "selected_path_alias_authority":False,
    }
    outdir.mkdir(parents=True,exist_ok=True)
    (outdir/"PHASE0_V001_DEPLOYMENT_ACTIVATION_AUTHORITY_PROOF.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")

    print("="*60)
    print("PHASE0 BINDING/RUNTIME V001 - DEPLOYMENT ACTIVATION AUTHORITY PROOF")
    print("="*60)
    print("FINAL="+status)
    print("SOURCE_DEFECT="+result["source_defect"])
    print("FAILED_SEAM="+result["failed_seam"])
    print("OWNER_LANE="+result["owner_lane"])
    print("CANDIDATE_FILE_COUNT="+str(len(candidate_files)))
    print("FILES_SCANNED="+str(len(candidate_files)))
    print("CONTRACT_HIT_COUNT="+str(len(contract_hits)))
    print("UNIQUE_ACTIVATION_COMBO_COUNT="+str(len(proven)))
    if selected:
        print("SELECTED_DEPLOYMENT_ROOT="+selected["deployment_root"])
        print("ACTIVATION_CONTRACT_PATH="+selected["contract_path"])
        print("ACTIVATION_CONTRACT_SHA256="+selected["contract_sha256"])
        print("RUNTIME_ENTRYPOINT_PATH="+selected["runtime_entrypoint_path"])
        print("RUNTIME_ENTRYPOINT_SHA256="+selected["runtime_entrypoint_sha256"])
    print("READ_ONLY=TRUE")
    print("BASELINE_MUTATED=FALSE")
    print("CANONICAL_CORE_MUTATED=FALSE")
    print("CONSTRAINT_SEMANTICS_MUTATED=FALSE")
    print("N2_MUTATED=FALSE")
    print("MTIME_AUTHORITY=NO")
    print("NEWEST_WINS=NO")
    print("DIRECTORY_NAME_ACTIVITY_INFERENCE=NO")
    print("SELECTED_PATH_ALIAS_AUTHORITY=NO")
    print("NEXT_ACTION="+next_action)
    return 0

if __name__=="__main__":
    raise SystemExit(main())

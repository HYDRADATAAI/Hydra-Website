# HYDRA Technical Proof

This page keeps the recruiter proof set intentionally small. Each item answers a different engineering question.

## 1. Can HYDRA close a semantic lane under a deterministic identity rule?

**Evidence:** `N1_SEALED` with `38/38 PASS`.

The sealed N1 result preserves the invariant:

```text
INPUT_CASE_CONSTRAINT_ID = CANONICAL_IDENTITY_AUTHORITY
```

Public-safe source hashes recorded for the sealed lane:

```text
adapter_sha256   = e0f10276d32be1ce62826c7361bf54fcdf19dadbfe3f463c02e249fabc8ea888
semantics_sha256 = 4f4eb09088e890778d4b88f02b5c63bab4d69a4c84150fe162d891233992e7f5
mutation          = NONE
```

Inspect: [`../proof/N1_SEMANTIC_CLASSIFICATION_RECEIPT.json`](../proof/N1_SEMANTIC_CLASSIFICATION_RECEIPT.json)

## 2. Can an actual cross-thread seam execute without mutating the sealed baseline?

**Evidence:** CI-TEST-005.

Recorded result:

```text
T3 = PASS
T4 = PASS
T5 = PASS
FAILURE_COUNT = 0
SEALED_BATCH60_MUTATED = NO
OVERALL = PASS_FIRST_BEHAVIORAL_CROSS_THREAD_SEAM
```

The result packet was recorded with SHA-256:

```text
f86eea0e680415295759171be1123e4824c89bc06d1e37b86b37c2e36b2abb4f
```

Inspect: [`../proof/CI_TEST_005_BEHAVIORAL_SEAM_RECEIPT.json`](../proof/CI_TEST_005_BEHAVIORAL_SEAM_RECEIPT.json)

## 3. Will HYDRA refuse to fabricate downstream semantics when authority is missing?

**Evidence:** CI-TEST-008.

Recorded result:

```text
RESULT = BLOCKED_BY_MISSING_AUTHORITY
BLOCKER = CI-TEST-008-BLOCKER-001-NATIVE-T5-T6-AUTHORITY-ABSENT
T6_NATIVE_CONTRACT = PROVEN
T5_TO_T6_AUTHORITATIVE_BINDING = ABSENT
SEMANTIC_VALUES_INVENTED = NO
BASELINE_MUTATED = NO
```

The important point is the negative proof: the system did **not** synthesize fields such as `as_of`, `confidence`, `evidence_ids`, `object_type`, or `subject_entity_id` merely to satisfy downstream validation.

Inspect: [`../proof/CI_TEST_008_AUTHORITY_BLOCKER_RECEIPT.json`](../proof/CI_TEST_008_AUTHORITY_BLOCKER_RECEIPT.json)

## Engineering cycle

The visible proof path is:

```text
TEST
  ↓
NAME DEFECT OR BLOCKER
  ↓
MINIMUM REPAIR ONLY WHEN AUTHORIZED
  ↓
RERUN THE SAME SLICE
  ↓
FREEZE / SEAL EVIDENCE
```

This is the GitHub-facing version of HYDRA's test-first rule: integrated truth is stronger than build volume.

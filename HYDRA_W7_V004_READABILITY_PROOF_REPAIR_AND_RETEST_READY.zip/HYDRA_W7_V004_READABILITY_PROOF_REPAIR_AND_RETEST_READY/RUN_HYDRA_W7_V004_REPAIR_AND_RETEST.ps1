param(
  [string]$HydraRoot = "D:\HYDRA",
  [string]$SiteRoot = "D:\HYDRA_SITE\V7"
)
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$ResultRoot = Join-Path $HydraRoot ("WEBSITE_TEST_RESULTS\W7_V004_REPAIR_RETEST_" + $Stamp)
New-Item -ItemType Directory -Force -Path $ResultRoot | Out-Null

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "HYDRA W7 V004 - READABILITY + PROOF REPAIR / SAME-GATE RETEST" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "SITE_ROOT=$SiteRoot"
Write-Host "RESULT_ROOT=$ResultRoot"
Write-Host "TARGET_DEFECT_1=W7-SITE-001_VISIBLE_TECHNICAL_PROOF_LABEL_ABSENT"
Write-Host "TARGET_DEFECT_2=W7-SITE-002_TINY_TEXT_UNDER_11PX"

$Py = Get-Command python -ErrorAction SilentlyContinue
if (-not $Py) { $Py = Get-Command py -ErrorAction SilentlyContinue }
if (-not $Py) { throw "Python not found." }

Write-Host ""
Write-Host "=== APPLY BOUNDED REPAIR ===" -ForegroundColor Yellow
& $Py.Source (Join-Path $Here "w7_v004_apply_bounded_repair.py") `
  --site-root $SiteRoot `
  --result-root $ResultRoot
$RepairExit = $LASTEXITCODE
if ($RepairExit -ne 0) {
  Write-Host "REPAIR_EXIT_CODE=$RepairExit" -ForegroundColor Red
  exit $RepairExit
}

Write-Host ""
Write-Host "=== SAME W7 RELEASE GATE RETEST ===" -ForegroundColor Yellow
& $Py.Source (Join-Path $Here "w7_v003_release_auditor.py") `
  --hydra-root $HydraRoot `
  --site-root $SiteRoot `
  --result-root $ResultRoot
$AuditExit = $LASTEXITCODE

$Downloads = Join-Path $HOME "Downloads"
$Out = Join-Path $Downloads ("HYDRA_W7_V004_RESULT_" + $Stamp + ".zip")
if (Test-Path $Out) { Remove-Item $Out -Force }
Compress-Archive -Path (Join-Path $ResultRoot "*") -DestinationPath $Out -CompressionLevel Optimal
$Hash = (Get-FileHash $Out -Algorithm SHA256).Hash.ToLowerInvariant()
"$Hash  $([IO.Path]::GetFileName($Out))" | Set-Content ($Out + ".sha256.txt") -Encoding ASCII

Write-Host ""
Write-Host "RESULT_ZIP=$Out" -ForegroundColor Green
Write-Host "RESULT_ZIP_SHA256=$Hash" -ForegroundColor Green
Write-Host "REPAIR_EXIT_CODE=$RepairExit"
Write-Host "AUDITOR_EXIT_CODE=$AuditExit"
if ($AuditExit -eq 0) {
  Write-Host "W7_LOCAL_AND_PUBLIC_RELEASE_GATE=PASS" -ForegroundColor Green
} else {
  Write-Host "W7_RETEST_RETURNED_NONPASS=SEE_EXACT_OVERALL_ABOVE" -ForegroundColor Yellow
}
Write-Host "NEXT=Return console output or RESULT ZIP to Nyx." -ForegroundColor Yellow
exit $AuditExit

# HYDRA W7 V005 — Public Deployment Preflight

Read-only deployment discovery.

The V004 site retest proved the local V7 release surface green across desktop, tablet, and mobile.
The sole remaining W7 blocker was `BLOCKED_PUBLIC_DEPLOYMENT_NOT_PROVEN`.

V005:
- extracts GitHub repository URLs already present in `D:\HYDRA_SITE\V7`;
- checks a local git origin when available;
- detects GitHub CLI / authentication state;
- queries GitHub Pages configuration when authenticated;
- probes candidate GitHub Pages URLs;
- accepts a public URL only when it actually returns HYDRA's exact title and tagline.

It performs **no mutation**, no push, no repo settings change, and no deployment.

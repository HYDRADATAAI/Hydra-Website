# HYDRA Engineering Inspection Index

This page is the shortest path for an engineer who wants to inspect the public material without digging through HYDRA's internal factory history.

## What can be inspected here

| Question | Public path | Evidence class |
|---|---|---|
| What is the architecture? | [`../README.md#architecture`](../README.md#architecture) | Recruiter-facing architecture description |
| What is the controlled data flow? | [`../README.md#data-flow`](../README.md#data-flow) | Public architecture/data-model description |
| What contract/authority behavior is proven? | [`CONTRACT_AUTHORITY_EXCERPT.md`](CONTRACT_AUTHORITY_EXCERPT.md) + [`../proof/CI_TEST_008_AUTHORITY_BLOCKER_RECEIPT.json`](../proof/CI_TEST_008_AUTHORITY_BLOCKER_RECEIPT.json) | Executed authority/admissibility test evidence |
| What deterministic identity behavior is proven? | [`../proof/N1_SEMANTIC_CLASSIFICATION_RECEIPT.json`](../proof/N1_SEMANTIC_CLASSIFICATION_RECEIPT.json) | Executed sealed test evidence |
| What cross-stage behavior is proven? | [`../proof/CI_TEST_005_BEHAVIORAL_SEAM_RECEIPT.json`](../proof/CI_TEST_005_BEHAVIORAL_SEAM_RECEIPT.json) | Executed integrated seam evidence |
| How are representative transformations explained? | [`REPRESENTATIVE_CONSTRAINT_CASE.md`](REPRESENTATIVE_CONSTRAINT_CASE.md) | Representative / non-live |
| How are provenance/history handled? | [`REPRESENTATIVE_CONSTRAINT_CASE.md#5-provenance--history`](REPRESENTATIVE_CONSTRAINT_CASE.md#5-provenance--history) | Public architecture/data-model explanation |
| How does HYDRA handle missing authority? | [`../proof/CI_TEST_008_AUTHORITY_BLOCKER_RECEIPT.json`](../proof/CI_TEST_008_AUTHORITY_BLOCKER_RECEIPT.json) | Executed blocker evidence |
| What is real vs representative/synthetic? | [`REAL_VS_SYNTHETIC.md`](REAL_VS_SYNTHETIC.md) | Public evidence-boundary declaration |
| Is there a public runnable demo? | [`../README.md#run--demo-path`](../README.md#run--demo-path) | No public runnable demo claimed |

## Public inspection boundary

The recruiter front door intentionally does **not** expose HYDRA's full internal ZIP/version archaeology, deprecated handoffs, or every native contract file.

Where a full native artifact is not included, this package says so. It does not reconstruct or manufacture a substitute merely to make the repository look more complete.

For CI-TEST-008, the public package includes a bounded contract/authority excerpt that records the tested downstream field requirements and the executed blocker. It is **not** represented as the complete native T6 schema.

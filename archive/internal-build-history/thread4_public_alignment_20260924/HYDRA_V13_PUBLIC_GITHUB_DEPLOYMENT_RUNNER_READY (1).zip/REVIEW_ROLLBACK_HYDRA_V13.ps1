param(
    [Parameter(Mandatory=$true)][string]$DeploymentReturnZip
)
$ErrorActionPreference='Stop'
Write-Host 'HYDRA V13 ROLLBACK HELPER' -ForegroundColor Yellow
Write-Host 'This helper does NOT force-reset public history.'
Write-Host 'It extracts the deployment receipt so you can identify the deployment commit.'
Write-Host 'If rollback is required, use a normal git revert after reviewing the receipt.'
$work = Join-Path $env:TEMP ("HYDRA_V13_ROLLBACK_REVIEW_" + (Get-Date -Format yyyyMMdd_HHmmss))
New-Item -ItemType Directory -Path $work -Force | Out-Null
Expand-Archive -LiteralPath $DeploymentReturnZip -DestinationPath $work -Force
$receipt = Get-ChildItem $work -Recurse -Filter 'V13_PUBLIC_GITHUB_DEPLOYMENT_RECEIPT.json' | Select-Object -First 1
if(-not $receipt){ throw 'Deployment receipt not found in return ZIP.' }
$r = Get-Content $receipt.FullName -Raw | ConvertFrom-Json
Write-Host "PREDEPLOY_REMOTE_SHA=$($r.predeploy_remote_sha)"
Write-Host "POSTDEPLOY_REMOTE_SHA=$($r.postdeploy_remote_sha)"
Write-Host 'ROLLBACK_POLICY=REVERT_COMMIT_NOT_FORCE_PUSH'
Write-Host 'No repository mutation was performed by this helper.'

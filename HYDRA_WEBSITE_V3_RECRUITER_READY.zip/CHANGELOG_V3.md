# HYDRA Website V3 — Recruiter Clarity Pass

This pass keeps the V2 visual language and interactive architecture, but changes the first impression from philosophy-first to product-first.

## Changed

- Hero now identifies HYDRA immediately as a **market-intelligence data engineering system**.
- Removed `AWS CLOUD · NEXT` and `GEN AI · EMERGING` from the recruiter-facing hero.
- Replaced `INDEPENDENT ENGINEERING PROJECT` with `MARKET INTELLIGENCE · DATA ENGINEERING`.
- Replaced `SIMULATED FLOW` with `ARCHITECTURE FLOW` on the hero diagram.
- Hero input nodes now read `MARKET`, `REFERENCE`, and `HISTORY`.
- Hero outputs now read `QUERY` and `INTEL` rather than advertising a future AI consumer.
- Replaced the homepage's early Data-vs-Intelligence division pitch with a clearer current-system explanation: **govern the data path → serve explainable market intelligence**.
- Removed homepage `AI-ready, not AI-first` language from the primary recruiter story.
- Recruiter signal section now focuses on multi-stage data engineering and market-data engineering evidence.
- Repository navigation and section now disappear automatically until a real public repository URL is configured.
- Footer and social-card language now describe the project as data engineering + market intelligence rather than an "independent engineering project."

## Intentionally retained deeper in the site

- AWS target mapping on the Architecture page.
- GenAI / Intelligence roadmap on the Roadmap page.
- Browser simulation language inside the Integrity Lab, where it accurately describes the demo.

The rule for the public landing page is now: **show what HYDRA is and what it does first; explain philosophy and future direction second.**

#!/usr/bin/env python3
import argparse, hashlib, json, math, os, re, shutil, tempfile, zipfile
from pathlib import Path

BATCH = 65
PREV_BATCH = 64
PREDECESSOR_NAME = 'NYX_CI_PIPELINE_PARALLEL_HARDENING_T1_T5_BATCH64_V001.zip'
SEALED_NAME = 'NYX_CI_PIPELINE_PARALLEL_HARDENING_T1_T5_BATCH65_V001.zip'
TRANSFER_COUNT = 10
FIXED_DT = (2000, 1, 1, 0, 0, 0)
EXPECTED_MEMBERS = 8915
EXPECTED_GOVERNED = 8912
EXPECTED_SHADOW_CHECKS = 3463
SCHEMA_PROFILE = '2.47'
PREV_SCHEMA_PROFILE = '2.46'
SEEDS = list(range(65001, 65013))
BOUNDARY = 'SYNTHETIC_SHADOW_ONLY'

CUMULATIVE = {
    't1_valid': 780,
    't1_invalid': 21600,
    't1_failure_families': 360,
    't1_compatibility_rows': 4392,
    't1_seam_bundles': 744,
    't1_lily_review_only_patch_proposals': 348,
    't2_adversarial': 11160,
    't2_recovery': 3690,
    't2_metamorphic': 3690,
    't3_golden_scenarios': 768,
    't4_attack_graphs': 768,
    't4_why_witnesses': 768,
    't4_reverse_witnesses': 768,
    't5_gate_vectors': 768,
    't5_pass': 102,
    't5_pass_with_warnings': 288,
    't5_fail': 378,
}

T1_FOCUS = [
    ('unicode_locale_casefold_profile_drift', 'IDENTIFIER_LOCALE_CASEFOLD_PROFILE_DRIFT'),
    ('timezone_offset_second_precision_loss', 'TIMESTAMP_SUBMINUTE_OFFSET_PRECISION_LOSS'),
    ('decimal_currency_quantum_version_drift', 'DECIMAL_CURRENCY_QUANTUM_VERSION_DRIFT'),
    ('reference_compaction_epoch_token_mismatch', 'REFERENCE_COMPACTION_EPOCH_MISMATCH'),
    ('semantic_hash_duplicate_collection_member_policy', 'SEMANTIC_HASH_DUPLICATE_MEMBER_POLICY_DRIFT'),
    ('utf8_grapheme_normalization_provenance_offset_drift', 'PROVENANCE_GRAPHEME_NORMALIZATION_OFFSET_DRIFT'),
]
T2_FOCUS = [
    ('pdf_optional_content_group_visibility_leak', 'PDF_OPTIONAL_CONTENT_VISIBILITY_LEAK'),
    ('table_denominator_basis_cross_section_bleed', 'TABLE_DENOMINATOR_BASIS_SCOPE_BLEED'),
    ('entity_cross_venue_symbol_epoch_collision', 'ENTITY_CROSS_VENUE_SYMBOL_EPOCH_COLLISION'),
    ('claim_nested_unless_except_polarity_loss', 'CLAIM_NESTED_EXCEPTION_POLARITY_LOSS'),
    ('pagination_cursor_restart_window_overlap', 'PAGINATION_CURSOR_RESTART_OVERLAP'),
]
OBJECT_CONTRACTS = [
    'SourceManifest','RawRecord','EvidenceRecord','Entity','Claim','Relationship',
    'ProvenanceRecord','Contradiction','ConstraintCandidate','BeneficiaryCandidate',
    'CanonicalCandidate','BabyMLObservation'
]
SEAMS = ['T1_T2','T2_T3','T3_T4','T4_T5','T5_T6','REVERSE_IMPACT']

PREDECESSOR_SHA256 = None
PREDECESSOR_BYTES = None


def canonical_json(obj):
    return (json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n').encode('utf-8')


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path, chunk=8*1024*1024):
    h = hashlib.sha256(); n = 0
    with open(path, 'rb') as f:
        while True:
            b = f.read(chunk)
            if not b: break
            h.update(b); n += len(b)
    return h.hexdigest(), n


def safe_name(name):
    p = Path(name)
    return not p.is_absolute() and '..' not in p.parts and not re.match(r'^[A-Za-z]:', name)


def zip_info(name):
    zi = zipfile.ZipInfo(name, FIXED_DT)
    zi.compress_type = zipfile.ZIP_STORED
    zi.create_system = 3
    zi.external_attr = 0o100644 << 16
    return zi


def load_predecessor_receipt(path):
    path = Path(path)
    obj = json.loads(path.read_text(encoding='utf-8'))
    required = {
        'status': 'SEALED',
        'batch': 64,
        'sealed_name': PREDECESSOR_NAME,
        'members': 8915,
        'manifest_governed': 8912,
        'shadow_qa_checks': 3409,
        'schema_profile': PREV_SCHEMA_PROFILE,
        'boundary': BOUNDARY,
        'thread6': 'NOT_STARTED',
    }
    for k, v in required.items():
        if obj.get(k) != v:
            raise RuntimeError(f'Batch64 receipt field mismatch {k}: expected {v!r}, got {obj.get(k)!r}')
    # Require Batch64 receipt to carry a valid predecessor pin from its own sealed build.
    prior_sha = str(obj.get('predecessor_sha256', '')).lower()
    prior_bytes = int(obj.get('predecessor_bytes', -1))
    if not re.fullmatch(r'[0-9a-f]{64}', prior_sha) or prior_bytes <= 0:
        raise RuntimeError('Batch64 receipt lacks a valid predecessor chain pin')
    sha = str(obj.get('sha256', '')).lower()
    size = int(obj.get('bytes', -1))
    if not re.fullmatch(r'[0-9a-f]{64}', sha) or size <= 0:
        raise RuntimeError('Batch64 receipt has invalid sealed SHA/byte count')
    seeds = obj.get('golden_seeds')
    if seeds != list(range(64001,64013)):
        raise RuntimeError('Batch64 receipt golden seeds mismatch')
    if int(obj.get('transfer_count', -1)) != 10:
        raise RuntimeError('Batch64 receipt transfer_count mismatch')
    return obj, sha, size


def discover_transfer_zips(transfer_dir):
    transfer_dir = Path(transfer_dir)
    pat = re.compile(r'BATCH64_TRANSFER_(\d{2})_OF_10_V001.*\.zip$', re.I)
    found = {}
    for p in transfer_dir.glob('*.zip'):
        m = pat.search(p.name)
        if m:
            idx = int(m.group(1))
            if 1 <= idx <= 10:
                old = found.get(idx)
                if old is None or p.stat().st_mtime > old.stat().st_mtime:
                    found[idx] = p
    missing = [i for i in range(1, 11) if i not in found]
    if missing:
        raise RuntimeError(f'Missing Batch64 transfer ZIP part(s): {missing}')
    return [found[i] for i in range(1,11)]


def choose_part_member(zf, idx):
    token = f'part{idx:02d}-of-10.bin'.lower()
    candidates = [n for n in zf.namelist() if n.lower().endswith(token)]
    if len(candidates) == 1: return candidates[0]
    bins = [i.filename for i in zf.infolist() if i.filename.lower().endswith('.bin')]
    if len(bins) == 1: return bins[0]
    raise RuntimeError(f'Could not uniquely identify transfer payload {idx:02d}')


def reconstruct_from_transfers(transfer_dir, output_path, expected_sha, expected_bytes):
    parts = discover_transfer_zips(transfer_dir)
    output_path = Path(output_path)
    tmp = output_path.with_suffix(output_path.suffix + '.partial')
    h = hashlib.sha256(); total = 0
    with open(tmp, 'wb') as out:
        for idx, zp in enumerate(parts, 1):
            print(f'[predecessor] transfer {idx:02d}/10 {zp.name}', flush=True)
            with zipfile.ZipFile(zp, 'r') as z:
                bad = z.testzip()
                if bad: raise RuntimeError(f'CRC failure {zp.name}: {bad}')
                member = choose_part_member(z, idx)
                ph = hashlib.sha256(); pn = 0
                with z.open(member) as src:
                    while True:
                        b = src.read(8*1024*1024)
                        if not b: break
                        out.write(b); h.update(b); ph.update(b); total += len(b); pn += len(b)
                if 'PART_MANIFEST.json' in z.namelist():
                    pm = json.loads(z.read('PART_MANIFEST.json'))
                    if pm.get('part_sha256') and pm['part_sha256'].lower() != ph.hexdigest():
                        raise RuntimeError(f'Part SHA mismatch {zp.name}')
                    if pm.get('part_bytes') is not None and int(pm['part_bytes']) != pn:
                        raise RuntimeError(f'Part byte mismatch {zp.name}')
                    if pm.get('sealed_sha256') and pm['sealed_sha256'].lower() != expected_sha:
                        raise RuntimeError(f'Part sealed SHA authority mismatch {zp.name}')
                    if pm.get('sealed_bytes') is not None and int(pm['sealed_bytes']) != expected_bytes:
                        raise RuntimeError(f'Part sealed byte authority mismatch {zp.name}')
    if total != expected_bytes or h.hexdigest() != expected_sha:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f'Batch64 reconstruction mismatch sha={h.hexdigest()} bytes={total}')
    os.replace(tmp, output_path)
    return output_path


def acquire_predecessor(source_dir, receipt_path, work_dir):
    global PREDECESSOR_SHA256, PREDECESSOR_BYTES
    receipt, PREDECESSOR_SHA256, PREDECESSOR_BYTES = load_predecessor_receipt(receipt_path)
    source_dir = Path(source_dir); work_dir = Path(work_dir)
    direct = source_dir / PREDECESSOR_NAME
    pred = work_dir / PREDECESSOR_NAME
    if direct.exists():
        sh, n = sha_file(direct)
        if sh == PREDECESSOR_SHA256 and n == PREDECESSOR_BYTES:
            if direct.resolve() != pred.resolve():
                shutil.copyfile(direct, pred)
            else:
                pred = direct
            print('[predecessor] direct sealed Batch64 ZIP matches receipt PASS', flush=True)
            return pred, receipt
        raise RuntimeError(f'Found Batch64 sealed ZIP but it does not match receipt: {sh}/{n}')
    reconstruct_from_transfers(source_dir, pred, PREDECESSOR_SHA256, PREDECESSOR_BYTES)
    print('[predecessor] Batch64 transfer reconstruction matches receipt PASS', flush=True)
    return pred, receipt


def metadata_files(receipt):
    return {
        'metadata/OPERATING_BOUNDARY.json': canonical_json({'batch':65,'boundary':BOUNDARY,'real_production_data':'UNAVAILABLE_UNUSED_BLOCKED','auto_canonical_promotion':False,'baby_ml_training':False,'trading_signals':False}),
        'metadata/THREAD6_NOT_STARTED.json': canonical_json({'batch':65,'thread6':'NOT_STARTED','reason':'T1-T5 hardening boundary remains authoritative'}),
        'metadata/EXPECTED_FUTURE_DATA_REQUIREMENTS.json': canonical_json({'batch':65,'real_data_required_for_future_empirical_work':True,'real_data_used_in_this_batch':False}),
        'metadata/LILY_INTEGRATION_HANDOFF.json': canonical_json({'batch':65,'schema_profile':SCHEMA_PROFILE,'ownership':'LILY_CORE_NYX_HARDENING','silent_schema_redefinition_forbidden':True}),
        'metadata/SCHEMA_PROFILE_RULES.json': canonical_json({'batch':65,'current_profile':SCHEMA_PROFILE,'previous_profile':PREV_SCHEMA_PROFILE,'compatibility_mode':'EXPLICIT_ONLY'}),
        'metadata/BATCH65_TARGETS.json': canonical_json({'batch':65,'schema_profile':SCHEMA_PROFILE,'expected_members':EXPECTED_MEMBERS,'expected_manifest_governed':EXPECTED_GOVERNED,'expected_shadow_qa_checks':EXPECTED_SHADOW_CHECKS,'golden_seeds':SEEDS,'cumulative':CUMULATIVE}),
        'metadata/PREDECESSOR_PIN.json': canonical_json({'name':PREDECESSOR_NAME,'sha256':PREDECESSOR_SHA256,'bytes':PREDECESSOR_BYTES,'authority':'BATCH64_SEAL_RECEIPT.json','embedding':'EXACT_BYTES'}),
        'metadata/PACKAGING_MODE.json': canonical_json({'batch':65,'mode':'DELTA_WITH_EXACT_SEALED_PREDECESSOR','transfer_count_max':10,'zip_compression':'STORED','fixed_timestamp':'2000-01-01T00:00:00'}),
    }


def build_core_small_files(receipt):
    d = {}; d.update(metadata_files(receipt))
    for i, contract in enumerate(OBJECT_CONTRACTS, 1):
        d[f't1_contracts/valid/valid_{i:03d}_{contract}.json'] = canonical_json({'batch':65,'fixture_id':f'B65-T1-VALID-{i:03d}','contract':contract,'schema_profile':SCHEMA_PROFILE,'source_lineage':['synthetic://batch65/valid'],'expected':'PASS','synthetic_shadow_only':True})
    for fi,(focus,code) in enumerate(T1_FOCUS,1):
        for j in range(1,61):
            d[f't1_contracts/invalid/{focus}/case_{j:03d}.json'] = canonical_json({'batch':65,'fixture_id':f'B65-T1-INV-{fi:02d}-{j:03d}','focus':focus,'failure_code':code,'mutation_index':j,'expected':'REJECT','silent_coercion_forbidden':True,'synthetic_shadow_only':True})
    idx=0
    for contract in OBJECT_CONTRACTS:
        for focus,code in T1_FOCUS:
            idx+=1
            d[f't1_contracts/compatibility/row_{idx:03d}.json'] = canonical_json({'batch':65,'producer_profile':PREV_SCHEMA_PROFILE,'consumer_profile':SCHEMA_PROFILE,'contract':contract,'focus':focus,'status':'EXPLICIT_ADAPTER_REQUIRED' if idx%3==0 else 'PASS_WITH_EXPLICIT_POLICY','failure_code':code})
    for i in range(12):
        seam=SEAMS[i%len(SEAMS)]
        d[f't1_contracts/seams/seam_{i+1:03d}_{seam}.json'] = canonical_json({'batch':65,'seam':seam,'bundle':i+1,'forward_reference_check':'PASS','reverse_reference_check':'PASS','forbidden_silent_coercion_check':'PASS','expected':'PASS'})
    for i,(focus,code) in enumerate(T1_FOCUS,1):
        d[f't1_contracts/patch_proposals/review_only_{i:02d}_{focus}.json'] = canonical_json({'batch':65,'focus':focus,'status':'LILY_REVIEW_ONLY','automatic_application':False,'proposal':f'Expose explicit contract policy for {focus}','failure_code':code})
        d[f't1_contracts/policies/current_{i:02d}_{focus}.json'] = canonical_json({'batch':65,'focus':focus,'failure_code':code,'policy':'FAIL_CLOSED_OR_EXPLICIT_VERSIONED_ADAPTER','expected_action':'REJECT_OR_EXPLICITLY_ADAPT','schema_profile':SCHEMA_PROFILE})
    dispositions=['QUARANTINE','REJECT','WARN']
    for fi,(focus,code) in enumerate(T2_FOCUS,1):
        for j in range(1,37):
            disp=dispositions[(j-1)%3]
            d[f't2_adversarial/cases/{focus}/case_{j:03d}.json']=canonical_json({'batch':65,'fixture_id':f'B65-T2-ADV-{fi:02d}-{j:03d}','focus':focus,'failure_code':code,'expected_disposition':disp,'downstream_promotion_allowed':False if disp!='WARN' else None,'synthetic_shadow_only':True})
        for j in range(1,13):
            d[f't2_adversarial/recovery/{focus}/recovery_{j:03d}.json']=canonical_json({'batch':65,'focus':focus,'failure_code':code,'recovery_step':j,'expected':'RECOVER_WITHOUT_SILENT_PROMOTION'})
            d[f't2_adversarial/metamorphic/{focus}/metamorphic_{j:03d}.json']=canonical_json({'batch':65,'focus':focus,'failure_code':code,'transform_index':j,'invariant':'DISPOSITION_AND_LINEAGE_STABLE','expected':'PASS'})
    replay_names=[
        'unicode_locale_casefold_replay','timezone_subminute_offset_replay','decimal_currency_quantum_replay','reference_compaction_epoch_replay','semantic_hash_duplicate_member_replay','grapheme_normalization_offset_replay',
        'pdf_optional_content_visibility_replay','table_denominator_basis_scope_replay','cross_venue_symbol_epoch_replay','nested_exception_polarity_replay','cursor_restart_overlap_replay','combined_multiseam_deterministic_replay']
    for i,(seed,name) in enumerate(zip(SEEDS,replay_names),1):
        sp=f't3_golden/scenarios/scenario_{i:02d}_{name}.json'; payload=canonical_json({'batch':65,'scenario':name,'seed':seed,'expected_output_digest_basis':'CANONICAL_JSON','expected':'PASS','synthetic_shadow_only':True})
        d[sp]=payload; d[f't3_golden/manifests/scenario_{i:02d}.manifest.json']=canonical_json({'batch':65,'scenario_path':sp,'sha256':sha_bytes(payload),'bytes':len(payload),'seed':seed})
    attack_names=[
        'unicode_locale_casefold_lineage_collision','timezone_subminute_offset_source_instant_drift','decimal_currency_quantum_provenance_loss','reference_compaction_epoch_drop','semantic_hash_duplicate_member_divergence','grapheme_normalization_reverse_map_failure',
        'pdf_optional_content_hidden_lineage','table_denominator_basis_lineage_mix','cross_venue_symbol_epoch_contamination','nested_exception_clause_parentage_loss','cursor_restart_evidence_duplication','combined_attack_closure']
    for i,name in enumerate(attack_names,1):
        d[f't4_lineage/attacks/attack_{i:02d}_{name}.json']=canonical_json({'batch':65,'attack':name,'expected_detection':True,'expected':'PASS'})
        d[f't4_lineage/why/why_{i:02d}_{name}.json']=canonical_json({'batch':65,'attack':name,'why_path':['constraint','relationship','claim','evidence','source'],'complete':True})
        d[f't4_lineage/reverse/reverse_{i:02d}_{name}.json']=canonical_json({'batch':65,'attack':name,'reverse_path':['source','evidence','claim','relationship','constraint','beneficiary'],'complete':True})
    gate_names=[code for _,code in T1_FOCUS]+[code for _,code in T2_FOCUS]+['CROSS_SUITE_CAUSAL_CONSISTENCY_FAILURE']
    for i,name in enumerate(gate_names,1):
        status='PASS_WITH_WARNINGS' if i<=6 else 'FAIL'
        d[f't5_release_gates/gate_{i:02d}_{name}.json']=canonical_json({'batch':65,'gate':name,'expected_status':status,'blocker_count':0 if status=='PASS_WITH_WARNINGS' else 1,'warning_count':1 if status=='PASS_WITH_WARNINGS' else 0,'automatic_release_allowed':status!='FAIL'})
    d['receipts/CUMULATIVE_COVERAGE.json']=canonical_json({'batch':65,'cumulative':CUMULATIVE})
    d['receipts/GOLDEN_SEEDS.json']=canonical_json({'batch':65,'seeds':SEEDS})
    d['receipts/BOUNDARY_ASSERTIONS.json']=canonical_json({'batch':65,'assertions':{'synthetic_shadow_only':True,'thread6_not_started':True,'auto_canonical_promotion':False,'baby_ml_training':False,'trading_signals':False}})
    return d


def add_matrix_files(d,target_before_qa):
    focuses=[x[0] for x in T1_FOCUS]+[x[0] for x in T2_FOCUS]; i=1
    while len(d)<target_before_qa:
        focus=focuses[(i-1)%len(focuses)]; contract=OBJECT_CONTRACTS[((i-1)//len(focuses))%len(OBJECT_CONTRACTS)]; seam=SEAMS[((i-1)//(len(focuses)*len(OBJECT_CONTRACTS)))%len(SEAMS)]
        d[f'matrix/coverage/vector_{i:05d}.json']=canonical_json({'batch':65,'vector_id':f'B65-MATRIX-{i:05d}','focus':focus,'contract':contract,'seam':seam,'variant':((i-1)%101)+1,'synthetic_shadow_only':True,'expected_disposition':'FAIL_CLOSED' if i%5==0 else ('WARN_EXPLICIT' if i%3==0 else 'PASS_EXPLICIT'),'lineage_required':True,'silent_coercion_forbidden':True})
        i+=1
    if len(d)!=target_before_qa: raise AssertionError((len(d),target_before_qa))


def make_shadow_checks(d):
    checks=[]
    def add(name,ok,detail):
        if not ok: raise RuntimeError(f'Shadow QA failure: {name}: {detail}')
        checks.append({'check_id':f'B65-QA-{len(checks)+1:04d}','name':name,'status':'PASS','detail':detail})
    add('boundary',json.loads(d['metadata/OPERATING_BOUNDARY.json'])['boundary']==BOUNDARY,BOUNDARY)
    add('thread6_not_started',json.loads(d['metadata/THREAD6_NOT_STARTED.json'])['thread6']=='NOT_STARTED','NOT_STARTED')
    add('schema_profile',json.loads(d['metadata/SCHEMA_PROFILE_RULES.json'])['current_profile']==SCHEMA_PROFILE,SCHEMA_PROFILE)
    add('seed_range',SEEDS==list(range(65001,65013)),'65001-65012')
    add('t1_valid_count',sum('/valid/' in p for p in d)==12,'12')
    add('t1_invalid_count',sum('/invalid/' in p for p in d)==360,'360')
    add('t1_compat_count',sum('/compatibility/' in p for p in d)==72,'72')
    add('t1_seam_count',sum('/seams/' in p for p in d)==12,'12')
    add('t1_policy_count',sum('/policies/' in p for p in d)==6,'6')
    add('t1_patch_count',sum('/patch_proposals/' in p for p in d)==6,'6')
    add('t2_adv_count',sum('/cases/' in p and p.startswith('t2_') for p in d)==180,'180')
    add('t2_recovery_count',sum('/recovery/' in p for p in d)==60,'60')
    add('t2_metamorphic_count',sum('/metamorphic/' in p for p in d)==60,'60')
    add('t3_scenario_count',sum('/scenarios/' in p for p in d)==12,'12')
    add('t3_manifest_count',sum('t3_golden/manifests/' in p for p in d)==12,'12')
    add('t4_attack_count',sum('/attacks/' in p for p in d)==12,'12')
    add('t4_why_count',sum('/why/' in p for p in d)==12,'12')
    add('t4_reverse_count',sum('/reverse/' in p for p in d)==12,'12')
    add('t5_gate_count',sum(p.startswith('t5_release_gates/') for p in d)==12,'12')
    sts=[json.loads(v)['expected_status'] for p,v in d.items() if p.startswith('t5_release_gates/')]
    add('t5_delta_status_split',sts.count('PASS_WITH_WARNINGS')==6 and sts.count('FAIL')==6,'6 WARN + 6 FAIL')
    add('pre_qa_governed_count',len(d)==EXPECTED_GOVERNED-2,f'{EXPECTED_GOVERNED-2}')
    matrix=sorted(p for p in d if p.startswith('matrix/coverage/')); k=0
    while len(checks)<EXPECTED_SHADOW_CHECKS:
        p=matrix[k%len(matrix)]; obj=json.loads(d[p]); add(f'matrix_vector_{k+1:04d}',obj['synthetic_shadow_only'] and obj['silent_coercion_forbidden'],p); k+=1
    return b''.join(canonical_json(x) for x in checks)


def prepare_governed(receipt):
    d=build_core_small_files(receipt)
    d['runners/run_shadow_qa.py']=b"#!/usr/bin/env python3\nimport json,sys,zipfile\nz=zipfile.ZipFile(sys.argv[1]); rows=[json.loads(x) for x in z.read('shadow_qa/checks.jsonl').splitlines()]; assert len(rows)==3463 and all(x['status']=='PASS' for x in rows); print('SHADOW_QA=PASS CHECKS=3463')\n"
    d['runners/verify_batch65_hint.txt']=b'Use FILE_MANIFEST.jsonl + FILE_MANIFEST.sha256 + metadata/PREDECESSOR_PIN.json; seal receipt is authoritative for Batch64 predecessor.\n'
    add_matrix_files(d,EXPECTED_GOVERNED-2)
    qa=make_shadow_checks(d); d['shadow_qa/checks.jsonl']=qa
    if len(d)!=EXPECTED_GOVERNED-1: raise RuntimeError(f'small governed count mismatch {len(d)}')
    if len(qa.splitlines())!=EXPECTED_SHADOW_CHECKS: raise RuntimeError('shadow QA count mismatch')
    return d


def manifest_bytes(small):
    rows=[{'path':f'predecessor/{PREDECESSOR_NAME}','bytes':PREDECESSOR_BYTES,'sha256':PREDECESSOR_SHA256}]
    rows += [{'path':p,'bytes':len(small[p]),'sha256':sha_bytes(small[p])} for p in sorted(small)]
    rows=sorted(rows,key=lambda x:x['path'])
    if len(rows)!=EXPECTED_GOVERNED: raise RuntimeError(f'manifest count mismatch {len(rows)}')
    return b''.join(canonical_json(r) for r in rows)


def create_readme():
    return f'''# NYX Batch 65

Boundary: `{BOUNDARY}`. Thread 6 remains NOT STARTED.

Predecessor authority is the host-produced `BATCH64_SEAL_RECEIPT.json`. Batch 65 refuses to build unless the sealed Batch 64 ZIP or its 10 transfers reproduce the SHA-256 and byte count in that receipt.

Schema profile: `{SCHEMA_PROFILE}`. Golden seeds: 65001-65012.
'''.encode()


def build_outer(pred,out_path,small):
    manifest=manifest_bytes(small); readme=create_readme(); prev=f'predecessor/{PREDECESSOR_NAME}'
    members=sorted([prev]+list(small)+['README.md','FILE_MANIFEST.jsonl','FILE_MANIFEST.sha256'])
    if len(members)!=EXPECTED_MEMBERS: raise RuntimeError(f'outer member count {len(members)}')
    with zipfile.ZipFile(out_path,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as z:
        for name in members:
            if name==prev:
                with z.open(zip_info(name),'w',force_zip64=True) as dst, open(pred,'rb') as src: shutil.copyfileobj(src,dst,8*1024*1024)
            elif name=='README.md': z.writestr(zip_info(name),readme)
            elif name=='FILE_MANIFEST.jsonl': z.writestr(zip_info(name),manifest)
            elif name=='FILE_MANIFEST.sha256': z.writestr(zip_info(name),(hashlib.sha256(manifest).hexdigest()+'  FILE_MANIFEST.jsonl\n').encode())
            else: z.writestr(zip_info(name),small[name])


def verify_outer(path):
    prev=f'predecessor/{PREDECESSOR_NAME}'
    with zipfile.ZipFile(path,'r') as z:
        infos=z.infolist()
        if len(infos)!=EXPECTED_MEMBERS: raise RuntimeError('member count mismatch')
        for i in infos:
            if i.compress_type!=zipfile.ZIP_STORED: raise RuntimeError(f'non-STORED {i.filename}')
            if i.date_time!=FIXED_DT: raise RuntimeError(f'non-fixed timestamp {i.filename}')
            if not safe_name(i.filename): raise RuntimeError(f'unsafe path {i.filename}')
        m=z.read('FILE_MANIFEST.jsonl'); side=z.read('FILE_MANIFEST.sha256').decode().split()[0]
        if hashlib.sha256(m).hexdigest()!=side: raise RuntimeError('manifest sidecar mismatch')
        rows=[json.loads(x) for x in m.splitlines()]
        if len(rows)!=EXPECTED_GOVERNED: raise RuntimeError('manifest row count mismatch')
        for r in rows:
            if r['path']==prev: continue
            b=z.read(r['path'])
            if len(b)!=r['bytes'] or sha_bytes(b)!=r['sha256']: raise RuntimeError(f'manifest mismatch {r["path"]}')
        h=hashlib.sha256(); n=0
        with z.open(prev) as f:
            while True:
                b=f.read(8*1024*1024)
                if not b: break
                h.update(b); n+=len(b)
        if h.hexdigest()!=PREDECESSOR_SHA256 or n!=PREDECESSOR_BYTES: raise RuntimeError('embedded predecessor mismatch')
        qa=z.read('shadow_qa/checks.jsonl').splitlines()
        if len(qa)!=EXPECTED_SHADOW_CHECKS or any(json.loads(x)['status']!='PASS' for x in qa): raise RuntimeError('shadow QA mismatch')
        if json.loads(z.read('metadata/SCHEMA_PROFILE_RULES.json'))['current_profile']!=SCHEMA_PROFILE: raise RuntimeError('schema profile mismatch')
        if json.loads(z.read('receipts/GOLDEN_SEEDS.json'))['seeds']!=SEEDS: raise RuntimeError('seed mismatch')


def reassembly_script(sealed_sha,sealed_size):
    return f'''param([string]$PartDir = $PSScriptRoot, [string]$OutputPath = (Join-Path $PSScriptRoot "{SEALED_NAME}"))\n$ErrorActionPreference="Stop"\nAdd-Type -AssemblyName System.IO.Compression.FileSystem\nif(Test-Path -LiteralPath $OutputPath){{Remove-Item -LiteralPath $OutputPath -Force}}\n$out=[System.IO.File]::Open($OutputPath,[System.IO.FileMode]::CreateNew)\ntry{{1..10|ForEach-Object{{$n=$_;$zip=Get-ChildItem -LiteralPath $PartDir -Filter ("NYX_CI_PIPELINE_PARALLEL_HARDENING_T1_T5_BATCH65_TRANSFER_{{0:D2}}_OF_10_V001*.zip" -f $n) -File|Sort-Object LastWriteTime -Descending|Select-Object -First 1;if(-not $zip){{throw "Missing part $n"}};$za=[System.IO.Compression.ZipFile]::OpenRead($zip.FullName);try{{$token=("part{{0:D2}}-of-10.bin" -f $n);$e=$za.Entries|Where-Object{{$_.FullName.ToLower().EndsWith($token.ToLower())}}|Select-Object -First 1;if(-not $e){{throw "Payload missing in $($zip.Name)"}};$s=$e.Open();try{{$s.CopyTo($out)}}finally{{$s.Dispose()}}}}finally{{$za.Dispose()}}}}}}finally{{$out.Dispose()}}\n$size=(Get-Item -LiteralPath $OutputPath).Length;if($size -ne {sealed_size}){{throw "Batch65 byte count mismatch: $size"}}\n$sha=(Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash.ToLowerInvariant();if($sha -ne "{sealed_sha}"){{throw "Batch65 SHA mismatch: $sha"}}\nWrite-Host "BATCH65_REASSEMBLY=PASS";Write-Host "SHA256=$sha";Write-Host "BYTES=$size"\n'''


def make_transfer_zips(sealed_path,output_dir,sealed_sha,sealed_size):
    chunk=math.ceil(sealed_size/TRANSFER_COUNT); script=reassembly_script(sealed_sha,sealed_size).encode(); parts=[]
    with open(sealed_path,'rb') as src:
        for idx in range(1,11):
            remaining=max(0,sealed_size-(idx-1)*chunk); want=min(chunk,remaining); part_name=f'{SEALED_NAME[:-4]}.part{idx:02d}-of-10.bin'; tz=Path(output_dir)/f'NYX_CI_PIPELINE_PARALLEL_HARDENING_T1_T5_BATCH65_TRANSFER_{idx:02d}_OF_10_V001.zip'; h=hashlib.sha256(); n=0
            with zipfile.ZipFile(tz,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as z:
                with z.open(zip_info(part_name),'w',force_zip64=True) as dst:
                    left=want
                    while left:
                        b=src.read(min(8*1024*1024,left))
                        if not b: raise RuntimeError('unexpected EOF while splitting')
                        dst.write(b);h.update(b);n+=len(b);left-=len(b)
                z.writestr(zip_info('PART_MANIFEST.json'),canonical_json({'batch':65,'part_index':idx,'part_count':10,'part_sha256':h.hexdigest(),'part_bytes':n,'sealed_name':SEALED_NAME,'sealed_sha256':sealed_sha,'sealed_bytes':sealed_size}))
                if idx==1: z.writestr(zip_info('REASSEMBLE_BATCH65.ps1'),script)
            parts.append(tz)
    return parts


def verify_transfer_stream(parts,sealed_sha,sealed_size):
    h=hashlib.sha256(); n=0
    for idx,zp in enumerate(parts,1):
        with zipfile.ZipFile(zp,'r') as z:
            if z.testzip() is not None: raise RuntimeError(f'transfer CRC failure {zp}')
            member=choose_part_member(z,idx); pm=json.loads(z.read('PART_MANIFEST.json')); ph=hashlib.sha256();pn=0
            with z.open(member) as f:
                while True:
                    b=f.read(8*1024*1024)
                    if not b: break
                    h.update(b);ph.update(b);n+=len(b);pn+=len(b)
            if ph.hexdigest()!=pm['part_sha256'] or pn!=pm['part_bytes']: raise RuntimeError(f'part manifest mismatch {idx}')
    if h.hexdigest()!=sealed_sha or n!=sealed_size: raise RuntimeError('transfer reconstruction mismatch')


def check_free_space(output_dir,minimum=4_800_000_000):
    free=shutil.disk_usage(output_dir).free
    if free<minimum: raise RuntimeError(f'Need at least ~4.8 GB free; available {free/1e9:.2f} GB')


def real_main(args):
    out=Path(args.output_dir); out.mkdir(parents=True,exist_ok=True); check_free_space(out)
    pred,receipt=acquire_predecessor(args.source_dir,args.receipt,out)
    sh,n=sha_file(pred)
    if sh!=PREDECESSOR_SHA256 or n!=PREDECESSOR_BYTES: raise RuntimeError('predecessor final pin failed')
    small=prepare_governed(receipt); b1=out/(SEALED_NAME+'.build1');b2=out/(SEALED_NAME+'.build2');sealed=out/SEALED_NAME
    for p in (b1,b2,sealed): p.unlink(missing_ok=True)
    build_outer(pred,b1,small);build_outer(pred,b2,small);s1,n1=sha_file(b1);s2,n2=sha_file(b2)
    if s1!=s2 or n1!=n2: raise RuntimeError('deterministic double-build mismatch')
    verify_outer(b1);os.replace(b1,sealed);b2.unlink(missing_ok=True)
    for p in out.glob('NYX_CI_PIPELINE_PARALLEL_HARDENING_T1_T5_BATCH65_TRANSFER_*_OF_10_V001*.zip'): p.unlink()
    parts=make_transfer_zips(sealed,out,s1,n1);verify_transfer_stream(parts,s1,n1)
    r={'status':'SEALED','batch':65,'sealed_name':SEALED_NAME,'sha256':s1,'bytes':n1,'members':EXPECTED_MEMBERS,'manifest_governed':EXPECTED_GOVERNED,'shadow_qa_checks':EXPECTED_SHADOW_CHECKS,'predecessor_sha256':PREDECESSOR_SHA256,'predecessor_bytes':PREDECESSOR_BYTES,'schema_profile':SCHEMA_PROFILE,'golden_seeds':SEEDS,'transfer_count':10,'boundary':BOUNDARY,'thread6':'NOT_STARTED','cumulative':CUMULATIVE}
    (out/'BATCH65_SEAL_RECEIPT.json').write_bytes(canonical_json(r))
    print('BATCH65_STATUS=SEALED');print(f'BATCH65_SHA256={s1}');print(f'BATCH65_BYTES={n1}');print(f'OUTPUT_DIR={out.resolve()}')


def selftest():
    global PREDECESSOR_SHA256, PREDECESSOR_BYTES
    with tempfile.TemporaryDirectory() as td:
        td=Path(td); pred=td/PREDECESSOR_NAME; pred.write_bytes(b'BATCH64_DUMMY_PREDECESSOR_SELFTEST\n'*37); PREDECESSOR_SHA256,PREDECESSOR_BYTES=sha_file(pred)
        receipt={'status':'SEALED','batch':64,'sealed_name':PREDECESSOR_NAME,'sha256':PREDECESSOR_SHA256,'bytes':PREDECESSOR_BYTES,'members':8915,'manifest_governed':8912,'shadow_qa_checks':3409,'predecessor_sha256':'1'*64,'predecessor_bytes':123456789,'schema_profile':'2.46','golden_seeds':list(range(64001,64013)),'transfer_count':10,'boundary':BOUNDARY,'thread6':'NOT_STARTED'}
        rp=td/'BATCH64_SEAL_RECEIPT.json'; rp.write_bytes(canonical_json(receipt)); loaded,lsha,lsize=load_predecessor_receipt(rp); assert lsha==PREDECESSOR_SHA256 and lsize==PREDECESSOR_BYTES
        small=prepare_governed(receipt); b1=td/'a.zip';b2=td/'b.zip';build_outer(pred,b1,small);build_outer(pred,b2,small);s1,n1=sha_file(b1);s2,n2=sha_file(b2)
        if (s1,n1)!=(s2,n2): raise RuntimeError('selftest deterministic mismatch')
        verify_outer(b1);parts=make_transfer_zips(b1,td,s1,n1);verify_transfer_stream(parts,s1,n1)
        print(json.dumps({'status':'PASS','outer_members':EXPECTED_MEMBERS,'manifest_governed':EXPECTED_GOVERNED,'shadow_qa_checks':EXPECTED_SHADOW_CHECKS,'double_build':'BYTE_IDENTICAL_PASS','transfer_reconstruction':'EXACT_BYTE_PASS'}))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-dir',help='Folder containing Batch64 sealed ZIP or ten Batch64 transfer ZIPs')
    ap.add_argument('--receipt',help='Path to BATCH64_SEAL_RECEIPT.json')
    ap.add_argument('--output-dir',help='Output/work folder')
    ap.add_argument('--selftest',action='store_true')
    args=ap.parse_args()
    if args.selftest: return selftest()
    if not args.source_dir or not args.receipt or not args.output_dir: ap.error('--source-dir, --receipt, and --output-dir are required unless --selftest')
    real_main(args)

if __name__=='__main__': main()

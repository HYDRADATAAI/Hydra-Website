param(
    [string]$HydraRoot="D:\HYDRA",
    [string]$V029Evidence=""
)
$ErrorActionPreference="Stop"
Set-StrictMode -Version Latest

Write-Host "============================================================"
Write-Host "NYX N2 V030 - DEPLOYED COPY HIGHER-ORDER BINDING PROOF"
Write-Host "============================================================"
Write-Host "PARENT_DEFECT=N2-DEFECT-025-RECEIPT-WRITER-ACTIVE-COPY-NOT-PROVEN"
Write-Host "HYDRA_ROOT=$HydraRoot"
Write-Host "MODE=READ_ONLY_PACKAGE_RUNNER_BINDING_PROOF"
Write-Host "WRITER_HASH_OWNER_AUTHORITY=REJECTED"
Write-Host "MTIME_AUTHORITY=NO"
Write-Host "BASENAME_POPULARITY_AUTHORITY=REJECTED"
Write-Host "PATH_NAME_ACTIVITY_INFERENCE=REJECTED"
Write-Host "UPSTREAM_MUTATION_AUTHORIZED=NO"
Write-Host "N2_MUTATION=NONE"

$Downloads=Join-Path $env:USERPROFILE "Downloads"

if(-not $V029Evidence){
    $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "N2_V029_RETURN_PACKET_*.zip" -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending
    $Found=$null
    foreach($C in $Candidates){
        $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        if($H -eq "558f3518a9da4ca48e5053e314f3fd6e20e95efd97415b2a30b35d5398e5a3a5"){$Found=$C;break}
    }
    if(-not $Found){
        $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "*V029*RETURN*.zip" -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending
        foreach($C in $Candidates){
            $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            if($H -eq "558f3518a9da4ca48e5053e314f3fd6e20e95efd97415b2a30b35d5398e5a3a5"){$Found=$C;break}
        }
    }
    if(-not $Found){throw "Exact V029 return packet not found with SHA256=558f3518a9da4ca48e5053e314f3fd6e20e95efd97415b2a30b35d5398e5a3a5"}
    $V029Evidence=$Found.FullName
}

$Actual=(Get-FileHash -LiteralPath $V029Evidence -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host "V029_EVIDENCE=$V029Evidence"
Write-Host "V029_EVIDENCE_SHA256=$Actual"
if($Actual -ne "558f3518a9da4ca48e5053e314f3fd6e20e95efd97415b2a30b35d5398e5a3a5"){throw "V029 evidence hash mismatch."}
Write-Host "V029_EVIDENCE_HASH_VERIFIED=PASS"

$PkgRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
$Py=Join-Path $PkgRoot "n2_v030_deployed_copy_higher_order_binding_proof.py"

$PythonCmd=Get-Command python.exe -ErrorAction SilentlyContinue
$PyLauncher=Get-Command py.exe -ErrorAction SilentlyContinue
if($PythonCmd){
    $PythonExe=$PythonCmd.Source
    $Prefix=@()
    Write-Host "PYTHON_LAUNCH_MODE=DIRECT_PYTHON"
}elseif($PyLauncher){
    $PythonExe=$PyLauncher.Source
    $Prefix=@("-3")
    Write-Host "PYTHON_LAUNCH_MODE=PY_LAUNCHER_3"
}else{throw "Python not found."}
Write-Host "PYTHON_COMMAND=$PythonExe"

& $PythonExe @Prefix $Py --selftest
if($LASTEXITCODE -ne 0){throw "V030 selftest failed."}

$RunDir="D:\NYX_N2_WORK\V030_DEPLOYED_COPY_HIGHER_ORDER_$(Get-Date -Format yyyyMMdd_HHmmss)"
$ReturnDir=Join-Path $RunDir "N2_V030_RETURN"
New-Item -ItemType Directory -Path $ReturnDir -Force|Out-Null
Write-Host "RUN_DIR=$RunDir"

& $PythonExe @Prefix $Py --hydra-root $HydraRoot --v029-evidence $V029Evidence --output-dir $ReturnDir
if($LASTEXITCODE -ne 0){throw "V030 higher-order binding proof failed."}

$R=Get-Content -LiteralPath (Join-Path $ReturnDir "N2_V030_DEPLOYED_COPY_HIGHER_ORDER_BINDING_PROOF.json") -Raw|ConvertFrom-Json

$ReturnZip=Join-Path $Downloads ("N2_V030_DEPLOYED_COPY_HIGHER_ORDER_RETURN_{0}.zip" -f (Get-Date -Format yyyyMMdd_HHmmss))
Compress-Archive -Path (Join-Path $ReturnDir "*") -DestinationPath $ReturnZip -CompressionLevel Optimal
$ReturnSha=(Get-FileHash -LiteralPath $ReturnZip -Algorithm SHA256).Hash.ToLowerInvariant()

Write-Host ""
Write-Host "============================================================"
Write-Host "N2 V030 FINAL"
Write-Host "============================================================"
Write-Host "FINAL=$($R.status)"
Write-Host "DEFECT_ID=$($R.defect_id)"
Write-Host "CANDIDATE_COUNT=$($R.candidate_count)"
Write-Host "STRONG_EXTERNAL_BINDING_COUNT=$($R.strong_external_binding_count)"
Write-Host "MENTION_ONLY_COUNT=$($R.mention_only_count)"
if($null -ne $R.selected_package_branch){
    Write-Host "SELECTED_PACKAGE_ROOT=$($R.selected_package_branch.package_root)"
    Write-Host "SELECTED_WRITER_PATH=$($R.selected_package_branch.writer_path)"
    Write-Host "SELECTED_WRITER_SHA256=$($R.selected_package_branch.writer_sha256)"
}
Write-Host "READ_ONLY=TRUE"
Write-Host "BASELINE_MUTATED=FALSE"
Write-Host "CANONICAL_CORE_MUTATED=FALSE"
Write-Host "CONSTRAINT_SEMANTICS_MUTATED=FALSE"
Write-Host "N2_MUTATED=FALSE"
Write-Host "NEXT_ACTION=$($R.next_action)"
Write-Host "RETURN_ZIP=$ReturnZip"
Write-Host "RETURN_SHA256=$ReturnSha"
Write-Host "RETURN_RUN_DIR=$RunDir"

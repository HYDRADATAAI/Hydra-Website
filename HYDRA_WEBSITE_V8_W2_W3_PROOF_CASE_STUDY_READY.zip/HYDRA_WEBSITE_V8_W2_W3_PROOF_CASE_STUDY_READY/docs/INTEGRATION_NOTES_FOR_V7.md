# V7 → V8 W2/W3 INTEGRATION NOTES

This package is a self-contained proof/case-study module intended to replace or deepen the existing V7 representative case-study area without changing the frozen recruiter hero.

## Preserve from V7
- `HYDRA / MARKET INTELLIGENCE DATA PLATFORM`
- `Turn fragmented market data into traceable intelligence.`
- badges: `Multi-source ingestion`, `Contract-bound handoffs`, `Lineage + release gates`
- architecture visual: Market → reference → history → contract gate → data core → lineage → query/intelligence

## Add below the hero / early technical-proof area
1. `RECRUITER_TECHNICAL_PROOF_STRIP`
2. `CONSTRAINT CASE STUDY V2`
3. compact receipt panel showing repair, quarantine, and authority-block behavior

## Do not re-add
- AWS CLOUD · NEXT
- GEN AI · EMERGING
- AI FUTURE
- SIMULATED FLOW
- Independent engineering project

## Implementation
`index.html` is the visual reference. Styles are isolated in `assets/hydra-proof.css`. Interactivity is limited to the small receipt tabs in `assets/hydra-proof.js`.

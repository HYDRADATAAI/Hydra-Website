# NYX Constraint Intelligence T1-T5 — Batch 67 Receipt-Bound Host Builder

This ZIP does **not** claim Batch 67 is already sealed. It builds Batch 67 only after your local Batch 66 build has produced a real `BATCH66_SEAL_RECEIPT.json`.

## One click

1. Finish Batch 66 with the prior host builder.
2. Leave its output in the default `D:\NYX_BATCH66_BUILD` folder, or keep the sealed Batch 66 ZIP / ten Batch 66 transfer ZIPs plus `BATCH66_SEAL_RECEIPT.json` together.
3. Extract this ZIP.
4. Double-click `RUN_BATCH67_FROM_BATCH66.cmd`.

The runner prefers the already sealed Batch 66 ZIP if present. If absent, it reconstructs Batch 66 from the ten transfer ZIPs. The bytes and SHA-256 must match the Batch 66 seal receipt exactly before Batch 67 construction begins.

## Batch 67 target

- Packaging: `DELTA_WITH_EXACT_SEALED_PREDECESSOR`
- Boundary: `SYNTHETIC_SHADOW_ONLY`
- Schema profile: `2.49`
- Golden seeds: `67001` through `67012`
- Outer members: `8,915`
- Manifest-governed entries: `8,912`
- Shadow QA checks: `3,571`
- Transfer ZIPs: exactly `10`
- Thread 6: `NOT_STARTED`
- Real production data: not used
- Automatic canonical promotion: disabled
- Baby-ML training: disabled
- Trading-signal generation: disabled

## Batch 67 focus

T1 expands into Unicode script-run segmentation policy drift, POSIX timezone-rule transitions, percentage-scale double application, logical-clock floor references, duplicate-array semantic-hash policies, and percent-decoding provenance offsets.

T2 adds embedded-font fallback substitutions in PDFs, nested table-header section carryover, identifier reassignment after mergers, deontic modality scope loss, and pagination time-window boundary overlap/gaps.

A successful run writes the sealed Batch 67 ZIP, ten Batch 67 transfer ZIPs, and `BATCH67_SEAL_RECEIPT.json`.

HYDRA WEBSITE V8 W2/W3 PROOF + CASE STUDY

OPEN: index.html

DELIVERABLES:
- RECRUITER_TECHNICAL_PROOF_STRIP
- CONSTRAINT_CASE_STUDY_V2
- Public-safe proof JSON
- Redacted evidence excerpts
- V7 integration notes

BOUNDARY:
Market case = REPRESENTATIVE / NON-LIVE.
Control receipts = genuine HYDRA test outcomes, redacted for public presentation.

﻿param(
    [string]$SiteRoot = "D:\HYDRA_SITE\V7",
    [string]$ResultBase = "D:\HYDRA\WEBSITE_TEST_RESULTS",
    [string]$PublicDeploymentUrl = ""
)

$ErrorActionPreference = "Stop"
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$ResultRoot = Join-Path $ResultBase ("W7_V006_STALE_LITERAL_FINAL_SEAL_" + $Stamp)
$BackupRoot = Join-Path $ResultRoot "BACKUP"
New-Item -ItemType Directory -Path $ResultRoot -Force | Out-Null
New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null

Write-Host "===================================================================="
Write-Host "HYDRA W7 V006 - STALE LITERAL ADJUDICATION + FINAL LOCAL SEAL"
Write-Host "===================================================================="
Write-Host "SITE_ROOT=$SiteRoot"
Write-Host "RESULT_ROOT=$ResultRoot"
Write-Host "REPAIR_SCOPE=STALE_LITERAL_ONLY"

if (-not (Test-Path -LiteralPath $SiteRoot -PathType Container)) {
    Write-Host "SITE_ROOT=FAIL"
    Write-Host "OVERALL=FAIL_WITH_DEFECT"
    exit 2
}

$Stale = "Multi-source ingestion"
$Safe = "Multi-source evidence inputs"
$AllowedExtensions = @(".html",".js",".css",".json",".md",".txt",".svelte",".ts",".tsx",".jsx",".map")

# Census exact stale literal before repair.
$Hits = New-Object System.Collections.Generic.List[object]
$CandidateFiles = Get-ChildItem -LiteralPath $SiteRoot -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object {
        $AllowedExtensions -contains $_.Extension.ToLowerInvariant() -and
        $_.FullName -notmatch '\\node_modules\\' -and
        $_.Length -le 20MB
    }

foreach ($File in $CandidateFiles) {
    $Text = $null
    try {
        $Text = Get-Content -LiteralPath $File.FullName -Raw -ErrorAction Stop
    } catch {
        continue
    }

    if ($Text.Contains($Stale)) {
        $Count = ([regex]::Matches([regex]::Escape($Stale), [regex]::Escape($Stale))).Count
        $LiteralCount = 0
        $Start = 0
        while (($Index = $Text.IndexOf($Stale, $Start, [System.StringComparison]::Ordinal)) -ge 0) {
            $LiteralCount++
            $ContextStart = [Math]::Max(0, $Index - 120)
            $ContextLen = [Math]::Min(320, $Text.Length - $ContextStart)
            $Context = $Text.Substring($ContextStart, $ContextLen) -replace "`r|`n", " "
            $Hits.Add([pscustomobject]@{
                file = $File.FullName
                extension = $File.Extension
                occurrence = $LiteralCount
                context = $Context
            })
            $Start = $Index + $Stale.Length
        }
    }
}

$Hits | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot "STALE_LITERAL_CENSUS_BEFORE.csv")
Write-Host "STALE_LITERAL_OCCURRENCES_BEFORE=$($Hits.Count)"

# Repair exact stale literal only, with backup before mutation.
$FilesToRepair = @($Hits | Select-Object -ExpandProperty file -Unique)
$MutationRows = New-Object System.Collections.Generic.List[object]

foreach ($FilePath in $FilesToRepair) {
    $File = Get-Item -LiteralPath $FilePath
    $Text = Get-Content -LiteralPath $File.FullName -Raw -ErrorAction Stop
    if (-not $Text.Contains($Stale)) { continue }

    $Relative = $File.FullName.Substring($SiteRoot.Length).TrimStart("\")
    $Backup = Join-Path $BackupRoot $Relative
    $BackupDir = Split-Path -Parent $Backup
    if ($BackupDir) {
        New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
    }

    Copy-Item -LiteralPath $File.FullName -Destination $Backup -Force
    $OldHash = (Get-FileHash -LiteralPath $Backup -Algorithm SHA256).Hash.ToLowerInvariant()

    $NewText = $Text.Replace($Stale, $Safe)
    Set-Content -LiteralPath $File.FullName -Value $NewText -Encoding UTF8
    $NewHash = (Get-FileHash -LiteralPath $File.FullName -Algorithm SHA256).Hash.ToLowerInvariant()

    $MutationRows.Add([pscustomobject]@{
        file = $File.FullName
        backup = $Backup
        repair = "$Stale -> $Safe"
        old_sha256 = $OldHash
        new_sha256 = $NewHash
    })
}

$MutationRows | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot "W7_V006_MUTATIONS.csv")
Write-Host "FILES_MUTATED=$($MutationRows.Count)"

# Post-repair corpus and stale census.
$CorpusBuilder = New-Object System.Text.StringBuilder
$RemainingHits = New-Object System.Collections.Generic.List[object]

foreach ($File in $CandidateFiles) {
    $Text = $null
    try {
        $Text = Get-Content -LiteralPath $File.FullName -Raw -ErrorAction Stop
    } catch {
        continue
    }

    [void]$CorpusBuilder.AppendLine($Text)

    if ($Text.Contains($Stale)) {
        $RemainingHits.Add([pscustomobject]@{
            file = $File.FullName
            extension = $File.Extension
        })
    }

    if ($CorpusBuilder.Length -gt 20000000) { break }
}

$Corpus = $CorpusBuilder.ToString()
$RemainingHits | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot "STALE_LITERAL_CENSUS_AFTER.csv")

$Checks = New-Object System.Collections.Generic.List[object]
function Add-Check {
    param([string]$Name,[string]$Status,[string]$Detail)
    $Checks.Add([pscustomobject]@{check=$Name;status=$Status;detail=$Detail})
    Write-Host ($Name + "=" + $Status + " :: " + $Detail)
}

Add-Check "SITE_ROOT" "PASS" $SiteRoot
Add-Check "HYDRA_IDENTITY" ($(if ($Corpus -match "\bHYDRA\b") {"PASS"} else {"FAIL"})) "HYDRA"
Add-Check "HERO_TITLE" ($(if ($Corpus -match "MARKET INTELLIGENCE DATA PLATFORM") {"PASS"} else {"FAIL"})) "MARKET INTELLIGENCE DATA PLATFORM"
Add-Check "TAGLINE" ($(if ($Corpus -match "Turn fragmented market data into traceable intelligence") {"PASS"} else {"FAIL"})) "Turn fragmented market data into traceable intelligence."
Add-Check "BADGE_MULTI_SOURCE_EVIDENCE_INPUTS" ($(if ($Corpus -match "Multi-source evidence inputs") {"PASS"} else {"FAIL"})) "W5-safe wording"
Add-Check "BADGE_CONTRACT_BOUND_HANDOFFS" ($(if ($Corpus -match "Contract-bound handoffs") {"PASS"} else {"FAIL"})) "Contract-bound handoffs"
Add-Check "BADGE_PROVENANCE_VALIDATION_GATES" ($(if ($Corpus -match "Provenance \+ validation gates") {"PASS"} else {"FAIL"})) "W5-safe wording"
Add-Check "STALE_MULTI_SOURCE_INGESTION" ($(if ($RemainingHits.Count -eq 0) {"PASS"} else {"FAIL"})) ("remaining=" + $RemainingHits.Count)
Add-Check "STALE_LINEAGE_RELEASE_GATES" ($(if ($Corpus -notmatch "Lineage \+ release gates") {"PASS"} else {"FAIL"})) "remaining=0 expected"
Add-Check "PROOF_ENTRYPOINT" ($(if ($Corpus -match "Technical Proof|Inspect Technical Proof") {"PASS"} else {"FAIL"})) "Technical Proof"
Add-Check "GITHUB_LINK" ($(if ($Corpus -match 'https://github\.com/HYDRADATAAI/hydra-website') {"PASS"} else {"FAIL"})) "HYDRADATAAI/hydra-website"

# Local HTML structure/assets.
$HtmlFiles = Get-ChildItem -LiteralPath $SiteRoot -Recurse -File -Filter "*.html" -ErrorAction SilentlyContinue
$PlaceholderCount = 0
$MissingLocal = New-Object System.Collections.Generic.List[object]
$ViewportFound = $false

foreach ($Html in $HtmlFiles) {
    $Text = Get-Content -LiteralPath $Html.FullName -Raw -ErrorAction SilentlyContinue
    if ($Text -match '<meta[^>]+name=["'']viewport["'']') { $ViewportFound = $true }

    $PlaceholderCount += ([regex]::Matches(
        $Text,
        'href\s*=\s*["''](?:\s*|#|javascript:void\(0\);?|javascript:;?)["'']',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )).Count

    foreach ($Match in [regex]::Matches(
        $Text,
        '(?:src|href)\s*=\s*["'']([^"'']+)["'']',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )) {
        $Ref = $Match.Groups[1].Value
        if (-not $Ref -or $Ref.StartsWith("#") -or $Ref -match '^(https?:|mailto:|tel:|data:|javascript:)') { continue }
        $Clean = ($Ref -split '[?#]')[0]
        if (-not $Clean) { continue }

        if ($Clean.StartsWith("/")) {
            $Target = Join-Path $SiteRoot $Clean.TrimStart("/")
        } else {
            $Target = Join-Path $Html.Directory.FullName $Clean
        }

        if (-not (Test-Path -LiteralPath $Target)) {
            $MissingLocal.Add([pscustomobject]@{page=$Html.FullName;ref=$Ref;target=$Target})
        }
    }
}

Add-Check "VIEWPORT_META" ($(if ($ViewportFound) {"PASS"} else {"FAIL"})) "responsive viewport"
Add-Check "PLACEHOLDER_LINKS" ($(if ($PlaceholderCount -eq 0) {"PASS"} else {"FAIL"})) ("count=" + $PlaceholderCount)
Add-Check "LOCAL_ASSETS" ($(if ($MissingLocal.Count -eq 0) {"PASS"} else {"FAIL"})) ("missing=" + $MissingLocal.Count)

# Browser render and visible-text proof.
$Browser = $null
$BrowserCandidates = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
)
foreach ($Candidate in $BrowserCandidates) {
    if ($Candidate -and (Test-Path -LiteralPath $Candidate)) {
        $Browser = $Candidate
        break
    }
}

$Python = $null
if (Get-Command py -ErrorAction SilentlyContinue) {
    $Python = "py"
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $Python = "python"
}

function Convert-DomToNormalizedText {
    param([string]$Html)
    if (-not $Html) { return "" }
    $A = [regex]::Replace($Html, '<script\b[^>]*>.*?</script>', ' ', 'IgnoreCase,Singleline')
    $B = [regex]::Replace($A, '<style\b[^>]*>.*?</style>', ' ', 'IgnoreCase,Singleline')
    $C = [regex]::Replace($B, '<[^>]+>', ' ')
    $D = [System.Net.WebUtility]::HtmlDecode($C)
    return ([regex]::Replace($D, '\s+', ' ')).Trim()
}

$ViewportRows = New-Object System.Collections.Generic.List[object]
$BrowserOverall = "BLOCKED"

if ($Browser -and $Python) {
    $Port = 18786
    $ServerOut = Join-Path $ResultRoot "HTTP_SERVER.out.log"
    $ServerErr = Join-Path $ResultRoot "HTTP_SERVER.err.log"
    $ServerArgs = @("-m","http.server",$Port,"--bind","127.0.0.1","--directory",$SiteRoot)
    $Server = Start-Process -FilePath $Python -ArgumentList $ServerArgs -PassThru -WindowStyle Hidden -RedirectStandardOutput $ServerOut -RedirectStandardError $ServerErr
    Start-Sleep -Seconds 2

    try {
        $Url = "http://127.0.0.1:$Port/index.html"
        $Viewports = @(
            [pscustomobject]@{Name="DESKTOP";Width=1440;Height=1000},
            [pscustomobject]@{Name="TABLET";Width=820;Height=1180},
            [pscustomobject]@{Name="MOBILE";Width=390;Height=844}
        )

        foreach ($Viewport in $Viewports) {
            $Stdout = Join-Path $ResultRoot ("CHROME_" + $Viewport.Name + ".stdout.txt")
            $Stderr = Join-Path $ResultRoot ("CHROME_" + $Viewport.Name + ".stderr.txt")
            $Screenshot = Join-Path $ResultRoot ("SCREENSHOT_" + $Viewport.Name + ".png")

            $ArgsList = @(
                "--headless=new",
                "--disable-gpu",
                "--no-first-run",
                "--no-default-browser-check",
                "--disable-background-networking",
                ("--window-size=" + $Viewport.Width + "," + $Viewport.Height),
                "--virtual-time-budget=8000",
                ("--screenshot=" + $Screenshot),
                "--dump-dom",
                $Url
            )

            $Proc = Start-Process -FilePath $Browser -ArgumentList $ArgsList -PassThru -Wait -WindowStyle Hidden -RedirectStandardOutput $Stdout -RedirectStandardError $Stderr
            $Dom = ""
            if (Test-Path -LiteralPath $Stdout) {
                $Dom = Get-Content -LiteralPath $Stdout -Raw -ErrorAction SilentlyContinue
            }
            $Visible = Convert-DomToNormalizedText $Dom

            $VisibleFile = Join-Path $ResultRoot ("VISIBLE_TEXT_" + $Viewport.Name + ".txt")
            $Visible | Set-Content -LiteralPath $VisibleFile -Encoding UTF8

            $HasHero = $Visible -match "MARKET INTELLIGENCE DATA PLATFORM"
            $HasTagline = $Visible -match "Turn fragmented market data into traceable intelligence"
            $HasSafeMulti = $Visible -match "Multi-source evidence inputs"
            $HasContract = $Visible -match "Contract-bound handoffs"
            $HasSafeProv = $Visible -match "Provenance \+ validation gates"
            $HasStale = $Visible -match "Multi-source ingestion"

            $Rendered = $HasHero -and $HasTagline -and $HasSafeMulti -and $HasContract -and $HasSafeProv -and (-not $HasStale)
            $Status = $(if ($Rendered) {"PASS"} else {"FAIL"})

            $ViewportRows.Add([pscustomobject]@{
                viewport = $Viewport.Name
                chrome_exit_code = $Proc.ExitCode
                visible_text_length = $(if ($Visible) {$Visible.Length} else {0})
                hero = $HasHero
                tagline = $HasTagline
                safe_multi_source = $HasSafeMulti
                contract_bound = $HasContract
                safe_provenance = $HasSafeProv
                stale_multi_source_visible = $HasStale
                screenshot_exists = (Test-Path -LiteralPath $Screenshot)
                status = $Status
            })
        }

        $ViewportRows | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot "BROWSER_VIEWPORT_RESULTS.csv")
        if (@($ViewportRows | Where-Object {$_.status -eq "FAIL"}).Count -eq 0) {
            $BrowserOverall = "PASS"
        } else {
            $BrowserOverall = "FAIL"
        }
    } finally {
        Stop-Process -Id $Server.Id -Force -ErrorAction SilentlyContinue
    }
}

Add-Check "BROWSER_RENDER" $BrowserOverall ("browser=" + $(if($Browser){$Browser}else{"NOT_FOUND"}))
foreach ($Name in @("DESKTOP","TABLET","MOBILE")) {
    $Row = $ViewportRows | Where-Object {$_.viewport -eq $Name} | Select-Object -First 1
    if ($Row) {
        Add-Check $Name $Row.status ("stale_visible=" + $Row.stale_multi_source_visible + " screenshot=" + $Row.screenshot_exists)
    } else {
        Add-Check $Name "BLOCKED" "viewport not executed"
    }
}

# Public deployment authority remains separate from local release seal.
if (-not $PublicDeploymentUrl) {
    if ($env:HYDRA_PUBLIC_DEPLOYMENT_URL) {
        $PublicDeploymentUrl = $env:HYDRA_PUBLIC_DEPLOYMENT_URL
    } else {
        $PublicUrlFile = Join-Path $SiteRoot "PUBLIC_DEPLOYMENT_URL.txt"
        $CnameFile = Join-Path $SiteRoot "CNAME"
        if (Test-Path -LiteralPath $PublicUrlFile) {
            $PublicDeploymentUrl = (Get-Content -LiteralPath $PublicUrlFile -Raw).Trim()
        } elseif (Test-Path -LiteralPath $CnameFile) {
            $HostName = (Get-Content -LiteralPath $CnameFile -First 1).Trim()
            if ($HostName -match '^[A-Za-z0-9.-]+\.[A-Za-z]{2,}$') {
                $PublicDeploymentUrl = "https://" + $HostName
            }
        }
    }
}

if ($PublicDeploymentUrl -match '^https?://') {
    try {
        $Response = Invoke-WebRequest -Uri $PublicDeploymentUrl -UseBasicParsing -TimeoutSec 20
        $PublicPass = ($Response.StatusCode -ge 200 -and $Response.StatusCode -lt 400 -and $Response.Content -match "\bHYDRA\b")
        Add-Check "PUBLIC_DEPLOYMENT" ($(if($PublicPass){"PASS"}else{"FAIL"})) ("url=" + $PublicDeploymentUrl + " status=" + $Response.StatusCode)
    } catch {
        Add-Check "PUBLIC_DEPLOYMENT" "FAIL" ("url=" + $PublicDeploymentUrl + " error=" + $_.Exception.Message)
    }
} else {
    Add-Check "PUBLIC_DEPLOYMENT" "BLOCKED" "local W7 seal independent; no authoritative public URL"
}

$FailCount = @($Checks | Where-Object {$_.status -eq "FAIL"}).Count
$BlockedCount = @($Checks | Where-Object {$_.status -eq "BLOCKED"}).Count

$LocalCritical = @(
    "SITE_ROOT","HYDRA_IDENTITY","HERO_TITLE","TAGLINE",
    "BADGE_MULTI_SOURCE_EVIDENCE_INPUTS","BADGE_CONTRACT_BOUND_HANDOFFS",
    "BADGE_PROVENANCE_VALIDATION_GATES","STALE_MULTI_SOURCE_INGESTION",
    "STALE_LINEAGE_RELEASE_GATES","PROOF_ENTRYPOINT","GITHUB_LINK",
    "VIEWPORT_META","PLACEHOLDER_LINKS","LOCAL_ASSETS",
    "BROWSER_RENDER","DESKTOP","TABLET","MOBILE"
)

$LocalFailCount = @($Checks | Where-Object {
    ($LocalCritical -contains $_.check) -and $_.status -eq "FAIL"
}).Count

if ($LocalFailCount -gt 0) {
    $Overall = "FAIL_WITH_DEFECT"
} elseif ($FailCount -gt 0) {
    $Overall = "FAIL_WITH_DEFECT"
} elseif ($BlockedCount -gt 0) {
    $Overall = "PASS_LOCAL_W7_SEALED_PUBLIC_DEPLOYMENT_BLOCKED"
} else {
    $Overall = "PASS"
}

$Receipt = [pscustomobject]@{
    version = "W7_V006"
    generated_at = (Get-Date).ToString("o")
    site_root = $SiteRoot
    stale_literal_before = $Hits.Count
    stale_literal_after = $RemainingHits.Count
    files_mutated = $MutationRows.Count
    fail_count = $FailCount
    blocked_count = $BlockedCount
    local_fail_count = $LocalFailCount
    local_release_sealed = ($LocalFailCount -eq 0)
    overall = $Overall
    checks = $Checks
}

$Receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $ResultRoot "W7_V006_FINAL_LOCAL_SEAL_RECEIPT.json") -Encoding UTF8
$Checks | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $ResultRoot "W7_V006_CHECKS.csv")

$Summary = @(
    "HYDRA W7 V006 FINAL LOCAL SEAL",
    ("SITE_ROOT=" + $SiteRoot),
    ("STALE_LITERAL_BEFORE=" + $Hits.Count),
    ("STALE_LITERAL_AFTER=" + $RemainingHits.Count),
    ("FILES_MUTATED=" + $MutationRows.Count),
    ("FAIL_COUNT=" + $FailCount),
    ("BLOCKED_COUNT=" + $BlockedCount),
    ("LOCAL_FAIL_COUNT=" + $LocalFailCount),
    ("LOCAL_RELEASE_SEALED=" + $(if($LocalFailCount -eq 0){"YES"}else{"NO"})),
    ("OVERALL=" + $Overall),
    ("RESULT_ROOT=" + $ResultRoot)
)
$Summary | Set-Content -LiteralPath (Join-Path $ResultRoot "W7_V006_SUMMARY.txt") -Encoding UTF8

$ResultZip = Join-Path $HOME ("Downloads\HYDRA_W7_V006_FINAL_LOCAL_SEAL_RESULT_" + $Stamp + ".zip")
Compress-Archive -Path (Join-Path $ResultRoot "*") -DestinationPath $ResultZip -Force
$ResultHash = (Get-FileHash -LiteralPath $ResultZip -Algorithm SHA256).Hash.ToLowerInvariant()

Write-Host "===================================================================="
Write-Host "HYDRA W7 V006 FINAL LOCAL SEAL VERDICT"
Write-Host "===================================================================="
Write-Host "SITE_ROOT=$SiteRoot"
Write-Host "STALE_LITERAL_BEFORE=$($Hits.Count)"
Write-Host "STALE_LITERAL_AFTER=$($RemainingHits.Count)"
Write-Host "FILES_MUTATED=$($MutationRows.Count)"
Write-Host "FAIL_COUNT=$FailCount"
Write-Host "BLOCKED_COUNT=$BlockedCount"
Write-Host "LOCAL_FAIL_COUNT=$LocalFailCount"
Write-Host "LOCAL_RELEASE_SEALED=$(if($LocalFailCount -eq 0){'YES'}else{'NO'})"
Write-Host "OVERALL=$Overall"
Write-Host "RESULT_ZIP=$ResultZip"
Write-Host "RESULT_ZIP_SHA256=$ResultHash"

if ($Overall -eq "PASS") { exit 0 }
elseif ($Overall -eq "PASS_LOCAL_W7_SEALED_PUBLIC_DEPLOYMENT_BLOCKED") { exit 3 }
else { exit 2 }

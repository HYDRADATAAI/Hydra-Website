# RECRUITER SCAN PATH AUDIT

**Deliverable:** `RECRUITER_SCAN_PATH_AUDIT`

## Scope

W6 simulates three cold readers against the recruiter-facing GitHub front door produced through W5. The purpose is not visual redesign. The purpose is to determine whether each reader can answer the questions appropriate to their attention window and reach inspectable proof without internal HYDRA archaeology.

## Reader A — Recruiter, ~30 seconds

### Questions

| Question | Result | Evidence / path |
|---|---|---|
| What is HYDRA? | PASS | Title, subtitle, one-line description, 30-second scan |
| What kind of engineering does it demonstrate? | PASS | Data engineering, normalization, identity, contracts/authority, provenance, validation |
| Can I see proof quickly? | PASS | Three direct proof links immediately under the 30-second scan |

### Friction found

**PRE-FIX:** The README explained the project accurately, but the recruiter had to read several paragraphs before seeing the three strongest proof outcomes together.

**FIX:** Added a `30-second scan` block with one sentence for what HYDRA is, one sentence for demonstrated technical areas, and direct links to the three strongest receipts.

### Reader A verdict

`PASS_AFTER_BOUNDED_FIX`

---

## Reader B — Engineering manager, ~2 minutes

### Questions

| Question | Result | Evidence / path |
|---|---|---|
| What is the architecture? | PASS | Mermaid architecture diagram |
| How is data quality enforced? | PASS | Contract/authority gates, seam tests, mutation checks, fail-closed rule |
| How is provenance handled? | PASS_WITH_LABEL | Provenance/history are explicit architecture/data-model elements; no universal live-lineage claim |
| How does testing work? | PASS | N1, CI-TEST-005, CI-TEST-008 plus minimum-repair/test-first explanation |
| Can I inspect real evidence? | PASS | Compact executed JSON receipts linked directly from README |

### Friction found

No high-value structural defect remained after W5. The strongest manager-level story is visible without opening the internal factory tree.

### Reader B verdict

`PASS`

---

## Reader C — Engineer, ~5–10 minutes

### Questions

| Question | Result | Evidence / path |
|---|---|---|
| Can I find contract/schema information? | PASS_WITH_LABEL | New bounded `CONTRACT_AUTHORITY_EXCERPT.md`; explicitly not represented as the full native T6 schema |
| Can I understand transformations? | PASS_WITH_LABEL | Representative constraint case shows source-shaped input → controlled normalization → identity → authority → traceable output/block |
| Can I find tests? | PASS | Three compact executed receipts plus technical proof page |
| Can I find lineage/provenance behavior? | PASS_WITH_LABEL | Architecture + representative case; not overstated as universal production lineage |
| Can I inspect representative outputs? | PASS | Representative constraint case, explicitly non-live |
| Can I see defect/block handling? | PASS | CI-TEST-008 blocker and fail-closed path |
| Can I find runnable or inspectable technical material? | PASS_WITH_LABEL | Inspectable executed receipts are public; no public runnable demo is claimed |

### Friction found

**PRE-FIX:** An engineer could reach the receipts, but the repository did not provide one compact index for contract behavior, tests, transformation examples, provenance, and demo boundaries. The word `schema` could also lead them to hunt for a full native T6 contract that this public package does not contain.

**FIXES:**

1. Added `docs/ENGINEERING_INSPECTION_INDEX.md` as a direct technical navigation page.
2. Added `docs/CONTRACT_AUTHORITY_EXCERPT.md` containing only the CI-TEST-008 field requirements that are actually supported by the receipt.
3. Explicitly stated that the excerpt is **not** the complete native T6 schema.
4. Added the engineering inspection path to the README.

### Reader C verdict

`PASS_AFTER_BOUNDED_FIXES`

---

## Friction register

| ID | Severity | Finding | Action | Final |
|---|---|---|---|---|
| W6-F01 | MEDIUM | Strong proof outcomes were not grouped early enough for a 30-second recruiter scan | Added `30-second scan` + direct proof links | CLOSED |
| W6-F02 | MEDIUM | Engineer path lacked a single inspection index | Added engineering inspection index | CLOSED |
| W6-F03 | MEDIUM | `schema/contract` inspection could cause fruitless searching for a full native contract not included publicly | Added bounded field-requirements excerpt + explicit boundary | CLOSED |
| W6-F04 | LOW | No public runnable demo | No change; truthful inspectable proof path retained | ACCEPTED_BOUNDARY |
| W6-F05 | LOW | Provenance/history explanation is architectural rather than universal live-output proof | No inflation; retained explicit label/boundary | ACCEPTED_BOUNDARY |

## Acceptance

```text
RECRUITER_30_SECOND_PATH=PASS
ENGINEERING_MANAGER_2_MINUTE_PATH=PASS
ENGINEER_5_TO_10_MINUTE_PATH=PASS
ARCHITECTURE_DISCOVERABLE=YES
DATA_QUALITY_DISCOVERABLE=YES
PROVENANCE_DISCOVERABLE=YES_WITH_LABEL
TEST_EVIDENCE_DISCOVERABLE=YES
CONTRACT_AUTHORITY_INSPECTION=YES_WITH_LABEL
REPRESENTATIVE_OUTPUT_DISCOVERABLE=YES
DEFECT_BLOCK_HANDLING_DISCOVERABLE=YES
PUBLIC_RUNNABLE_DEMO=NO_CLAIMED
INSPECTABLE_TECHNICAL_MATERIAL=YES
HIGH_VALUE_FRICTION_OPEN=0
W6_RESULT=PASS
```

## Stop rule

No broad redesign is warranted from this pass. The front door now supports the three intended reading speeds. Further work belongs to deployment/responsive/link validation, not copy expansion.

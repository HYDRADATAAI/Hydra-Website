# Representative constraint case

**Scope: REPRESENTATIVE / NON-LIVE**

## Question

Does the available evidence establish a broad market shortage, or only a narrower bottleneck?

## Evidence pattern

```text
SOURCE A / availability
physical availability   = present
qualified availability  = partial
scope                    = venue segment

SOURCE B / price
pricing pressure         = observed
scarcity cause           = unresolved
scope                    = same segment

SOURCE C / history
condition                = intermittent
broader market match     = not established
```

## Controlled interpretation

The system first normalizes the evidence, resolves the governed subject, retains provenance, and checks what each observation is authorized to establish.

The semantic boundary matters:

- pricing pressure is **not automatically shortage**;
- bottleneck is **not automatically canonical constraint existence**;
- physical availability is **not the same as qualified availability**;
- several sources discussing one phenomenon do **not automatically establish systemic scope**.

## Result

```text
SUPPORTED:       LOCAL BOTTLENECK
NOT AUTHORIZED:  SYSTEMIC SHORTAGE
```

Representative output:

```json
{
  "constraint_ref": "constraint:demo-01",
  "subject_ref": "segment:demo-01",
  "classification": "bottleneck",
  "scope": "local",
  "availability": {
    "physical": "present",
    "qualified": "partial"
  },
  "systemic_shortage": "not_established",
  "uncertainty": "preserved",
  "promotion_blocked": true,
  "reason": "evidence does not authorize broader scope"
}
```

## Why this belongs in a data-engineering portfolio

The interesting result is not the word `bottleneck`. It is the controlled path behind it:

`fragmented evidence → normalized records → governed identity → contract/authority check → provenance/history → bounded semantic output`

That same fail-closed principle appears in the integrated CI-008 evidence, where required semantic handoff fields remained unfilled when authoritative case data could not supply them.

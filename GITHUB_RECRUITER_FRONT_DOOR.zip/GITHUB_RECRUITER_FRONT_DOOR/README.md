# HYDRA

**Market Intelligence Data Platform**

> Turn fragmented market data into traceable intelligence.

HYDRA is a data-engineering project for moving fragmented market, reference, and history evidence through controlled normalization, deterministic identity, contract and authority checks, provenance/history, and downstream intelligence structures.

The recruiter-facing view is intentionally narrow: it shows the architecture, the engineering rules, and a small set of executed proof. It does **not** lead with internal build trees, archived experiments, or hundreds of intermediate packages.

## What it does

HYDRA is built around a controlled evidence path:

1. ingest fragmented source evidence;
2. normalize it into controlled records;
3. resolve deterministic identity;
4. enforce contract and authority boundaries;
5. preserve provenance and history;
6. validate cross-stage handoffs;
7. emit traceable intelligence structures only when the required authority exists.

A core rule is simple: **discoverable does not mean authorized**. If a downstream field has no authoritative producer or valid binding, HYDRA is expected to block rather than invent the value.

## Architecture

```mermaid
flowchart LR
    A["Market / Reference / History Sources"] --> B["Source Normalization"]
    B --> C["Identity Resolution"]
    C --> D["Contract + Authority Gate"]
    D --> E["Data Core"]
    E --> F["Provenance + History"]
    F --> G["Constraint / Intelligence Outputs"]
    D -. "missing authority" .-> X["BLOCK / QUARANTINE"]

    T["Integrated Tests + Release Gates"] -. validates .-> B
    T -. validates .-> C
    T -. validates .-> D
    T -. validates .-> F
```

## Data flow

| Stage | Recruiter view | Engineering purpose |
|---|---|---|
| Source | Market, reference, history evidence | Preserve source identity and context |
| Normalize | Controlled internal record | Remove source-shape ambiguity |
| Identity | Canonical subject / constraint identity | Make joins deterministic |
| Contract | Explicit producer and handoff rules | Prevent unauthorized field creation |
| Trace | Provenance, lineage, history | Make transformations inspectable |
| Validate | Seam tests, invariants, mutation checks | Prove behavior across stages |
| Output | Constraint / intelligence structure | Emit only supported, traceable results |

## Engineering principles

- **Explicit authority.** A field must have an authoritative owner or valid derivation path.
- **Deterministic identity.** Identity is bound deliberately rather than guessed from convenient matches.
- **Provenance.** Outputs retain a trace back to source and transformation evidence.
- **Contract-bound handoffs.** Cross-stage objects are validated against native contracts.
- **Testable transformations.** Seams are exercised with executable tests and invariant checks.
- **Blocked rather than fabricated outputs.** Missing authority is a valid engineering result.
- **Minimum repair.** When a defect is proven, repair the demonstrated defect, rerun the test, and preserve the baseline boundary.

## Technical proof

The front door deliberately links only a few high-signal artifacts.

| Proof | Executed result | Why it matters |
|---|---|---|
| [N1 semantic classification receipt](proof/N1_SEMANTIC_CLASSIFICATION_RECEIPT.json) | `N1_SEALED`, `38/38 PASS` | Proves the semantic classification lane closed with its canonical-identity invariant intact. |
| [CI-TEST-005 behavioral seam receipt](proof/CI_TEST_005_BEHAVIORAL_SEAM_RECEIPT.json) | `PASS_FIRST_BEHAVIORAL_CROSS_THREAD_SEAM`, `FAILURE_COUNT=0` | Shows an executed cross-thread behavioral seam with T3/T4/T5 passing and the sealed baseline unmutated. |
| [CI-TEST-008 authority blocker receipt](proof/CI_TEST_008_AUTHORITY_BLOCKER_RECEIPT.json) | `BLOCKED_BY_MISSING_AUTHORITY` | Shows fail-closed behavior: the native T6 contract exists, but the authoritative T5→T6 binding was absent, so semantic values were not invented. |

A compact explanation of the three receipts is in [Technical proof](docs/TECHNICAL_PROOF.md).

## Representative constraint example

The public case study is **representative and non-live**. It demonstrates the shape of the engineering path without claiming a live production market conclusion.

```text
FRAGMENTED MARKET EVIDENCE
        ↓
SOURCE NORMALIZATION
        ↓
IDENTITY RESOLUTION
        ↓
CONTRACT / AUTHORITY CHECK
        ↓
PROVENANCE + HISTORY
        ↓
CONSTRAINT CLASSIFICATION
        ↓
TRACEABLE OUTPUT OR BLOCK
```

The important behavior is not a flashy prediction. It is that each output can be traced to controlled evidence, identity, authority, and history, and unsupported semantics stop at the gate.

See [Representative constraint case](docs/REPRESENTATIVE_CONSTRAINT_CASE.md).

## Testing

HYDRA uses integrated seam testing rather than treating file presence as proof of system behavior.

Two recruiter-safe examples capture the intended discipline:

- **CI-TEST-005:** T3/T4/T5 behavioral seam passed with `FAILURE_COUNT=0`, `SEALED_BATCH60_MUTATED=NO`, and `OVERALL=PASS_FIRST_BEHAVIORAL_CROSS_THREAD_SEAM`.
- **CI-TEST-008:** returned `BLOCKED_BY_MISSING_AUTHORITY` because a native T5→T6 authoritative binding was absent. The result preserved `SEMANTIC_VALUES_INVENTED=NO` and `BASELINE_MUTATED=NO`.

A blocker is not hidden or converted into a fake green result. That is part of the proof.

## Real vs synthetic

This repository distinguishes evidence classes explicitly.

- **Executed test evidence:** real local test outcomes, hashes, pass/block states, mutation checks, and seal receipts.
- **Representative public examples:** simplified recruiter-facing structures used to explain the pipeline. They are labeled representative/non-live.
- **Synthetic / shadow hardening:** some broader HYDRA validation work is intentionally synthetic/shadow only. It is not presented here as live production inference.
- **Live production claims:** none are made by this front door.

See [Real vs synthetic](docs/REAL_VS_SYNTHETIC.md).

## Repository map

```text
README.md
├── docs/
│   ├── TECHNICAL_PROOF.md
│   ├── REPRESENTATIVE_CONSTRAINT_CASE.md
│   └── REAL_VS_SYNTHETIC.md
└── proof/
    ├── N1_SEMANTIC_CLASSIFICATION_RECEIPT.json
    ├── CI_TEST_005_BEHAVIORAL_SEAM_RECEIPT.json
    └── CI_TEST_008_AUTHORITY_BLOCKER_RECEIPT.json
```

For a two-minute review, read in this order:

**README → Technical Proof → three proof receipts → Representative Constraint Case**

Internal factory trees, stale handoffs, deprecated packages, and experimental branches should remain outside this recruiter path.

## Run / demo path

No public runnable demo is claimed by this package.

Until a safe demo is deliberately published, the strongest truthful path is **inspectable proof**:

1. read the architecture and data-flow sections above;
2. inspect the three compact proof receipts;
3. read the representative constraint case;
4. verify that PASS, BLOCK, authority, mutation, and evidence-class labels are explicit rather than implied.

That keeps the GitHub front door useful without manufacturing a demo that does not yet exist.

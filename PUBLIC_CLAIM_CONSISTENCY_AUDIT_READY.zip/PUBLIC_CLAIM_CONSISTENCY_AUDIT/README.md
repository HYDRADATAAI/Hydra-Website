# W5 package

This package is the hostile website ↔ GitHub ↔ source-evidence consistency review.

Use `PUBLIC_CLAIM_CONSISTENCY_AUDIT.md` for the human verdict and `PUBLIC_CLAIM_CONSISTENCY_AUDIT.csv` / `PUBLIC_CLAIM_REGISTRY.json` for the claim ledger.

The `PATCHED_PUBLIC_SURFACES` directory contains only bounded claim-safety edits. It is not a visual redesign.

HYDRA V7 W6 BOUNDED REPAIR V001

Observed failures:
- 3 approved badge strings not exact
- missing Technical Proof entrypoint
- GitHub link absent
- 12 href="#" placeholders

Repair:
- exact approved badge source strings
- "Open repository" dead CTA -> proof.html as "Inspect technical proof"
- Repository placeholders -> real GitHub URL when supplied, otherwise non-clickable pending labels
- LinkedIn / Contact placeholders -> non-clickable pending labels
- backup before every HTML write

No hero redesign. No new architecture. No HYDRA-core execution.

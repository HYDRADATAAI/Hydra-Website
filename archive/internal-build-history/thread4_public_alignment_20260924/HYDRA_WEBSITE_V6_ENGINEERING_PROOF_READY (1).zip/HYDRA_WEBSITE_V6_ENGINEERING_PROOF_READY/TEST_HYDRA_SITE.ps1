$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Required = @(
  'index.html','architecture.html','constraint.html','lab.html','proof.html','roadmap.html','404.html',
  'styles.css','app.js','site.config.js','assets\hydra-mark.svg'
)

$Missing = @()
foreach ($Rel in $Required) {
    if (-not (Test-Path (Join-Path $Root $Rel))) { $Missing += $Rel }
}

if ($Missing.Count -gt 0) {
    Write-Host 'SITE_PACKAGE_TEST=FAIL' -ForegroundColor Red
    $Missing | ForEach-Object { Write-Host "MISSING=$_" -ForegroundColor Red }
    exit 1
}

$HtmlFiles = Get-ChildItem $Root -Filter '*.html' -File
foreach ($File in $HtmlFiles) {
    $Text = Get-Content $File.FullName -Raw
    if ($Text -notmatch '<title>') { throw "Missing title in $($File.Name)" }
    if ($Text -notmatch '<meta name="viewport"') { throw "Missing viewport in $($File.Name)" }
}

Write-Host 'SITE_PACKAGE_TEST=PASS' -ForegroundColor Green
Write-Host "HTML_FILES=$($HtmlFiles.Count)"
Write-Host 'CONSTRAINT_INTELLIGENCE_PAGE=PASS'
Write-Host 'ENGINEERING_PROOF_PAGE=PASS'
Write-Host 'PUBLIC_LINKS_FAIL_CLOSED=PASS'
Write-Host 'BASELINE_HERO_DIRECTION=UNCHANGED'

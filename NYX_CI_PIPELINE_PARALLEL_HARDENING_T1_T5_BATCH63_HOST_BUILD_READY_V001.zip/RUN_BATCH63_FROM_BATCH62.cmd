@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_BATCH63_FROM_BATCH62.ps1"
if errorlevel 1 (
  echo.
  echo BATCH63 BUILD FAILED. See the error above.
  pause
  exit /b 1
)
echo.
echo BATCH63 BUILD PASSED.
pause

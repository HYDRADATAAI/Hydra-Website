param()
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$ExpectedPayloadSha = '3bee70bc6ddd6987e3a07e3434cdab9e79b3d7cf4cc521823ec3a3106b6e3ff0'
$RepoSlug = 'HYDRADATAAI/Hydra-Website'
$RepoUrl = 'https://github.com/HYDRADATAAI/Hydra-Website.git'
$Branch = 'main'
$PagesUrl = 'https://hydradataai.github.io/Hydra-Website/'
$PayloadZip = Join-Path $PSScriptRoot 'HYDRA_V12_PUBLIC_GITHUB_SYNC_PAYLOAD_READY.zip'
$Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$RunRoot = "D:\HYDRA_WEBSITE_DEPLOY\V13_$Stamp"
$PayloadRoot = Join-Path $RunRoot 'payload'
$RepoRoot = Join-Path $RunRoot 'repo'
$EvidenceRoot = Join-Path $RunRoot 'evidence'
$ReturnRoot = Join-Path $RunRoot 'return'
$Downloads = Join-Path $HOME 'Downloads'
$ReturnZip = Join-Path $Downloads "HYDRA_V13_PUBLIC_GITHUB_DEPLOYMENT_RETURN_$Stamp.zip"

New-Item -ItemType Directory -Path $PayloadRoot,$EvidenceRoot,$ReturnRoot -Force | Out-Null

$result = [ordered]@{
    schema = 'HYDRA_V13_PUBLIC_GITHUB_DEPLOYMENT_RECEIPT_V001'
    run_timestamp = (Get-Date).ToString('o')
    target_repository = $RepoSlug
    target_branch = $Branch
    pages_url = $PagesUrl
    payload_expected_sha256 = $ExpectedPayloadSha
    payload_actual_sha256 = $null
    payload_verified = $false
    manifest_verified = $false
    delete_unlisted_files = $false
    git_found = $false
    git_version = $null
    predeploy_remote_sha = $null
    postdeploy_local_sha = $null
    postdeploy_remote_sha = $null
    staged_file_count = 0
    changed_paths = @()
    repo_sync = 'NOT_STARTED'
    public_api_verify = 'NOT_RUN'
    public_pages_verify = 'NOT_RUN'
    pages_http_status = $null
    pages_marker_found = $false
    unsupported_file_deletion = $false
    overall = 'RUNNING'
    next_action = $null
    failure_phase = $null
    failure_message = $null
}

function Write-Utf8([string]$Path, [string]$Text) {
    $Text | Set-Content -LiteralPath $Path -Encoding UTF8
}

function Invoke-GitCapture {
    param(
        [string[]]$Args,
        [string]$Label,
        [switch]$AllowFailure
    )
    $safe = ($Args -join ' ')
    $out = & $script:GitExe @Args 2>&1 | Out-String
    $code = $LASTEXITCODE
    Write-Utf8 (Join-Path $EvidenceRoot ("git_{0}.txt" -f $Label)) ("COMMAND=git $safe`r`nEXIT_CODE=$code`r`n`r`n$out")
    if((-not $AllowFailure) -and $code -ne 0){ throw "GIT_$Label failed with exit code $code" }
    return [pscustomobject]@{ Output=$out.Trim(); ExitCode=$code }
}

function Normalize-RepoUrl([string]$Value) {
    if($null -eq $Value){ return '' }
    $v = $Value.Trim().ToLowerInvariant()
    if($v.EndsWith('/')){ $v = $v.TrimEnd('/') }
    if($v.EndsWith('.git')){ $v = $v.Substring(0,$v.Length-4) }
    return $v
}

function Write-ReturnPacket {
    $result.run_completed_at = (Get-Date).ToString('o')
    $json = $result | ConvertTo-Json -Depth 8
    $receipt = Join-Path $ReturnRoot 'V13_PUBLIC_GITHUB_DEPLOYMENT_RECEIPT.json'
    Write-Utf8 $receipt $json

    $summary = @"
HYDRA V13 PUBLIC GITHUB DEPLOYMENT
OVERALL=$($result.overall)
TARGET_REPOSITORY=$($result.target_repository)
TARGET_BRANCH=$($result.target_branch)
PAYLOAD_VERIFIED=$($result.payload_verified)
MANIFEST_VERIFIED=$($result.manifest_verified)
DELETE_UNLISTED_FILES=$($result.delete_unlisted_files)
PREDEPLOY_REMOTE_SHA=$($result.predeploy_remote_sha)
POSTDEPLOY_LOCAL_SHA=$($result.postdeploy_local_sha)
POSTDEPLOY_REMOTE_SHA=$($result.postdeploy_remote_sha)
REPO_SYNC=$($result.repo_sync)
PUBLIC_API_VERIFY=$($result.public_api_verify)
PUBLIC_PAGES_VERIFY=$($result.public_pages_verify)
PAGES_HTTP_STATUS=$($result.pages_http_status)
PAGES_MARKER_FOUND=$($result.pages_marker_found)
UNSUPPORTED_FILE_DELETION=$($result.unsupported_file_deletion)
FAILURE_PHASE=$($result.failure_phase)
FAILURE_MESSAGE=$($result.failure_message)
NEXT_ACTION=$($result.next_action)
"@
    Write-Utf8 (Join-Path $ReturnRoot 'V13_PUBLIC_GITHUB_DEPLOYMENT_SUMMARY.txt') $summary

    if(Test-Path $EvidenceRoot){ Copy-Item -LiteralPath $EvidenceRoot -Destination (Join-Path $ReturnRoot 'evidence') -Recurse -Force }
    if(Test-Path $ReturnZip){ Remove-Item -LiteralPath $ReturnZip -Force }
    Compress-Archive -Path (Join-Path $ReturnRoot '*') -DestinationPath $ReturnZip -CompressionLevel Optimal -Force
    $hash = (Get-FileHash -LiteralPath $ReturnZip -Algorithm SHA256).Hash.ToLowerInvariant()
    Write-Host "RETURN_ZIP=$ReturnZip"
    Write-Host "RETURN_ZIP_SHA256=$hash"
}

Write-Host '============================================================'
Write-Host 'HYDRA V13 - PUBLIC GITHUB DEPLOYMENT + VERIFICATION'
Write-Host '============================================================'
Write-Host "TARGET=$RepoSlug"
Write-Host "BRANCH=$Branch"
Write-Host 'MUTATION_SCOPE=ONLY_FILES_LISTED_IN_V12_DEPLOYMENT_MANIFEST'
Write-Host 'DELETE_UNLISTED_FILES=NO'
Write-Host 'GITHUB_PAGES_SETTINGS_MUTATION=NO'
Write-Host 'THIS RUNNER MAY COMMIT AND PUSH TO THE PUBLIC GITHUB REPOSITORY.'
Write-Host '============================================================'

try {
    # Phase 1: exact payload + manifest verification
    $result.failure_phase = 'PAYLOAD_VERIFY'
    if(-not (Test-Path -LiteralPath $PayloadZip -PathType Leaf)){ throw "Payload ZIP missing: $PayloadZip" }
    $actual = (Get-FileHash -LiteralPath $PayloadZip -Algorithm SHA256).Hash.ToLowerInvariant()
    $result.payload_actual_sha256 = $actual
    if($actual -ne $ExpectedPayloadSha){ throw "Payload SHA mismatch. expected=$ExpectedPayloadSha actual=$actual" }
    $result.payload_verified = $true

    Expand-Archive -LiteralPath $PayloadZip -DestinationPath $PayloadRoot -Force
    $manifestPath = Join-Path $PayloadRoot 'DEPLOYMENT_MANIFEST.json'
    if(-not (Test-Path -LiteralPath $manifestPath)){ throw 'DEPLOYMENT_MANIFEST.json missing from payload' }
    $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    if($manifest.target_repository -ne $RepoSlug){ throw "Manifest repository mismatch: $($manifest.target_repository)" }
    if($manifest.target_branch -ne $Branch){ throw "Manifest branch mismatch: $($manifest.target_branch)" }
    if([bool]$manifest.delete_unlisted_files){ throw 'Manifest unexpectedly authorizes deletion of unlisted files' }
    if($manifest.mode -ne 'PREPARED_NOT_EXECUTED'){ throw "Unexpected manifest mode: $($manifest.mode)" }
    if([int]$manifest.file_count -ne @($manifest.files).Count){ throw 'Manifest file_count mismatch' }

    $allowedPaths = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach($entry in $manifest.files){
        $rel = [string]$entry.path
        if([string]::IsNullOrWhiteSpace($rel) -or [IO.Path]::IsPathRooted($rel) -or $rel -match '(^|[\\/])\.\.([\\/]|$)'){
            throw "Unsafe manifest path: $rel"
        }
        [void]$allowedPaths.Add($rel.Replace('\\','/'))
        $src = Join-Path $PayloadRoot $rel
        if(-not (Test-Path -LiteralPath $src -PathType Leaf)){ throw "Manifest file missing: $rel" }
        $sha = (Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLowerInvariant()
        $bytes = (Get-Item -LiteralPath $src).Length
        if($sha -ne ([string]$entry.sha256).ToLowerInvariant()){ throw "Manifest SHA mismatch for $rel" }
        if($bytes -ne [int64]$entry.bytes){ throw "Manifest byte count mismatch for $rel" }
    }
    $result.manifest_verified = $true
    Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $EvidenceRoot 'DEPLOYMENT_MANIFEST.json') -Force

    # Phase 2: git availability + fresh exact clone
    $result.failure_phase = 'GIT_PREFLIGHT'
    $git = Get-Command git.exe -ErrorAction SilentlyContinue
    if(-not $git){ $git = Get-Command git -ErrorAction SilentlyContinue }
    if(-not $git){ throw 'Git is not installed or not on PATH. No repository mutation performed.' }
    $script:GitExe = $git.Source
    $result.git_found = $true
    $gv = & $script:GitExe --version 2>&1 | Out-String
    if($LASTEXITCODE -ne 0){ throw 'git --version failed' }
    $result.git_version = $gv.Trim()
    Write-Utf8 (Join-Path $EvidenceRoot 'git_version.txt') $result.git_version

    $result.failure_phase = 'CLONE'
    $clone = Invoke-GitCapture -Args @('clone','--branch',$Branch,'--single-branch',$RepoUrl,$RepoRoot) -Label 'clone'
    $remote = (Invoke-GitCapture -Args @('-C',$RepoRoot,'remote','get-url','origin') -Label 'remote_url').Output
    if((Normalize-RepoUrl $remote) -ne (Normalize-RepoUrl $RepoUrl)){ throw "Remote mismatch: $remote" }
    $currentBranch = (Invoke-GitCapture -Args @('-C',$RepoRoot,'branch','--show-current') -Label 'branch').Output
    if($currentBranch -ne $Branch){ throw "Branch mismatch after clone: $currentBranch" }
    $clean = (Invoke-GitCapture -Args @('-C',$RepoRoot,'status','--porcelain=v1') -Label 'status_initial').Output
    if(-not [string]::IsNullOrWhiteSpace($clean)){ throw 'Fresh clone is unexpectedly dirty' }
    $preSha = (Invoke-GitCapture -Args @('-C',$RepoRoot,'rev-parse','HEAD') -Label 'predeploy_head').Output.Trim()
    $result.predeploy_remote_sha = $preSha

    # Phase 3: bounded overlay only; no deletions
    $result.failure_phase = 'OVERLAY'
    foreach($entry in $manifest.files){
        $rel = [string]$entry.path
        $src = Join-Path $PayloadRoot $rel
        $dst = Join-Path $RepoRoot $rel
        $dstDir = Split-Path -Parent $dst
        if($dstDir){ New-Item -ItemType Directory -Path $dstDir -Force | Out-Null }
        Copy-Item -LiteralPath $src -Destination $dst -Force
        $sha = (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash.ToLowerInvariant()
        if($sha -ne ([string]$entry.sha256).ToLowerInvariant()){ throw "Post-copy hash mismatch for $rel" }
    }

    $statusText = (Invoke-GitCapture -Args @('-C',$RepoRoot,'status','--porcelain=v1') -Label 'status_after_overlay').Output
    $changed = @()
    if(-not [string]::IsNullOrWhiteSpace($statusText)){
        foreach($line in ($statusText -split "`r?`n")){
            if($line.Length -lt 4){ continue }
            $path = $line.Substring(3).Trim().Trim('"').Replace('\\','/')
            if($path -match ' -> '){ $path = ($path -split ' -> ')[-1] }
            if(-not $allowedPaths.Contains($path)){ throw "Out-of-scope path changed: $path" }
            $changed += $path
        }
    }
    $result.changed_paths = @($changed | Sort-Object -Unique)

    if($result.changed_paths.Count -eq 0){
        $result.repo_sync = 'ALREADY_MATCHED_NO_COMMIT_REQUIRED'
        $result.postdeploy_local_sha = $preSha
        $result.postdeploy_remote_sha = $preSha
    } else {
        # Phase 4: identity, stage exact manifest paths, prohibit deletions, commit, push
        $result.failure_phase = 'COMMIT_PREFLIGHT'
        $userName = (Invoke-GitCapture -Args @('-C',$RepoRoot,'config','user.name') -Label 'user_name' -AllowFailure).Output
        $userEmail = (Invoke-GitCapture -Args @('-C',$RepoRoot,'config','user.email') -Label 'user_email' -AllowFailure).Output
        if([string]::IsNullOrWhiteSpace($userName) -or [string]::IsNullOrWhiteSpace($userEmail)){
            throw 'Git user.name or user.email is not configured. Refusing to invent commit identity.'
        }

        foreach($entry in $manifest.files){
            [void](Invoke-GitCapture -Args @('-C',$RepoRoot,'add','--',[string]$entry.path) -Label ("add_" + ([string]$entry.path -replace '[^A-Za-z0-9]+','_')))
        }
        $staged = (Invoke-GitCapture -Args @('-C',$RepoRoot,'diff','--cached','--name-status') -Label 'staged_name_status').Output
        $stagedCount = 0
        if(-not [string]::IsNullOrWhiteSpace($staged)){
            foreach($line in ($staged -split "`r?`n")){
                if([string]::IsNullOrWhiteSpace($line)){ continue }
                $parts = $line -split "`t"
                $statusCode = $parts[0]
                $path = $parts[-1].Trim().Trim('"').Replace('\\','/')
                if($statusCode.StartsWith('D')){ $result.unsupported_file_deletion = $true; throw "Deletion detected in staged changes: $path" }
                if(-not $allowedPaths.Contains($path)){ throw "Out-of-scope staged path: $path" }
                $stagedCount++
            }
        }
        if($stagedCount -eq 0){ throw 'Changed files existed but nothing was staged' }
        $result.staged_file_count = $stagedCount

        $result.failure_phase = 'COMMIT'
        [void](Invoke-GitCapture -Args @('-C',$RepoRoot,'commit','-m','Deploy HYDRA website V12 recruiter release') -Label 'commit')
        $newSha = (Invoke-GitCapture -Args @('-C',$RepoRoot,'rev-parse','HEAD') -Label 'postcommit_head').Output.Trim()
        $result.postdeploy_local_sha = $newSha

        $result.failure_phase = 'PUSH'
        $push = Invoke-GitCapture -Args @('-C',$RepoRoot,'push','origin',"HEAD:$Branch") -Label 'push'
        $result.repo_sync = 'PUSH_SUCCEEDED'

        $result.failure_phase = 'REMOTE_SHA_VERIFY'
        $ls = (Invoke-GitCapture -Args @('-C',$RepoRoot,'ls-remote','origin',"refs/heads/$Branch") -Label 'ls_remote').Output
        $remoteSha = (($ls -split "\s+")[0]).Trim()
        $result.postdeploy_remote_sha = $remoteSha
        if($remoteSha -ne $newSha){ throw "Remote SHA mismatch after push: local=$newSha remote=$remoteSha" }
    }

    # Phase 5: public GitHub API verification
    $result.failure_phase = 'PUBLIC_API_VERIFY'
    try {
        $headers = @{ 'User-Agent'='HYDRA-V13-Deployment-Verifier'; 'Accept'='application/vnd.github+json' }
        $api = Invoke-RestMethod -Uri "https://api.github.com/repos/$RepoSlug/commits/$Branch" -Headers $headers -Method Get -TimeoutSec 25
        $apiSha = [string]$api.sha
        Write-Utf8 (Join-Path $EvidenceRoot 'public_api_main_sha.txt') $apiSha
        if($apiSha -eq $result.postdeploy_remote_sha){ $result.public_api_verify = 'PASS' }
        else { $result.public_api_verify = "SHA_MISMATCH_$apiSha" }
    } catch {
        $result.public_api_verify = 'NOT_PROVEN_API_REQUEST_FAILED'
        Write-Utf8 (Join-Path $EvidenceRoot 'public_api_error.txt') $_.Exception.Message
    }

    # Phase 6: GitHub Pages read-only verification. No settings mutation.
    $result.failure_phase = 'PUBLIC_PAGES_VERIFY'
    try {
        $resp = Invoke-WebRequest -Uri $PagesUrl -UseBasicParsing -MaximumRedirection 5 -TimeoutSec 25
        $result.pages_http_status = [int]$resp.StatusCode
        $marker = 'HYDRA / MARKET INTELLIGENCE DATA PLATFORM'
        $markerFound = ([string]$resp.Content).Contains($marker)
        $result.pages_marker_found = $markerFound
        if($resp.StatusCode -eq 200 -and $markerFound){
            $result.public_pages_verify = 'PASS'
        } elseif($resp.StatusCode -eq 200){
            $result.public_pages_verify = 'HTTP_200_BUT_V12_MARKER_NOT_FOUND'
        } else {
            $result.public_pages_verify = "HTTP_$($resp.StatusCode)"
        }
    } catch {
        $status = $null
        try { $status = [int]$_.Exception.Response.StatusCode.value__ } catch {}
        $result.pages_http_status = $status
        $result.public_pages_verify = 'NOT_PROVEN_OR_NOT_ENABLED'
        Write-Utf8 (Join-Path $EvidenceRoot 'pages_error.txt') $_.Exception.Message
    }

    $result.failure_phase = $null
    if($result.repo_sync -in @('PUSH_SUCCEEDED','ALREADY_MATCHED_NO_COMMIT_REQUIRED')){
        if($result.public_pages_verify -eq 'PASS'){
            $result.overall = 'PASS_PUBLIC_GITHUB_SYNC_AND_PAGES_VERIFIED'
            $result.next_action = 'ISSUE_FINAL_PUBLIC_SITE_RELEASE_SEAL'
        } else {
            $result.overall = 'PASS_REPO_SYNC_PUBLIC_PAGES_NOT_PROVEN'
            $result.next_action = 'ENABLE_OR_CONFIRM_GITHUB_PAGES_FOR_MAIN_ROOT_THEN_RERUN_READ_ONLY_PUBLIC_VERIFICATION'
        }
    } else {
        throw "Unexpected repo_sync state: $($result.repo_sync)"
    }
}
catch {
    $result.failure_message = $_.Exception.Message
    if($result.failure_phase -eq 'PUSH'){
        $result.repo_sync = 'BLOCKED_PUSH_FAILED_REMOTE_NOT_PROVEN_MUTATED'
        $result.next_action = 'RESOLVE_GIT_AUTHORIZATION_OR_BRANCH_PROTECTION_AND_RERUN_FROM_FRESH_CLONE'
    } elseif($result.failure_phase -eq 'CLONE'){
        $result.repo_sync = 'BLOCKED_CLONE_FAILED_NO_LOCAL_OVERLAY_PERFORMED'
        $result.next_action = 'RESOLVE_REPOSITORY_ACCESS_OR_NETWORK_AND_RERUN'
    } elseif($result.failure_phase -eq 'COMMIT_PREFLIGHT'){
        $result.repo_sync = 'BLOCKED_COMMIT_IDENTITY_MISSING_REMOTE_UNCHANGED'
        $result.next_action = 'CONFIGURE_GIT_USER_NAME_AND_EMAIL_THEN_RERUN'
    } else {
        if($result.repo_sync -eq 'NOT_STARTED'){ $result.repo_sync = 'BLOCKED_BEFORE_PUSH' }
        $result.next_action = 'REVIEW_RETURN_PACKET_AND_REPAIR_ONLY_THE_REPORTED_BLOCKER'
    }
    $result.overall = 'BLOCKED'
    Write-Host "ERROR=$($result.failure_message)" -ForegroundColor Red
}
finally {
    Write-ReturnPacket
    Write-Host '============================================================'
    Write-Host "OVERALL=$($result.overall)"
    Write-Host "REPO_SYNC=$($result.repo_sync)"
    Write-Host "PUBLIC_API_VERIFY=$($result.public_api_verify)"
    Write-Host "PUBLIC_PAGES_VERIFY=$($result.public_pages_verify)"
    Write-Host "NEXT_ACTION=$($result.next_action)"
    Write-Host '============================================================'
}

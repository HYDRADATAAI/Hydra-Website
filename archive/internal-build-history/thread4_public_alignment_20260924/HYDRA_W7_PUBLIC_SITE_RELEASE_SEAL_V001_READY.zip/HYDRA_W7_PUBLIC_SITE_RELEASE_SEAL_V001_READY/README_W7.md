# HYDRA W7 — PUBLIC SITE RELEASE SEAL

Final host-side release test for the actual recruiter-facing HYDRA website.

Checks the frozen hero copy/badges, Technical Proof routing, GitHub routing, placeholders,
internal anchors, local assets, external-link reachability, public deployment reachability,
desktop/tablet/mobile overflow, JavaScript errors, broken images, and tiny visible text.

Safe auto-repair is deliberately narrow:
1. add `rel="noopener noreferrer"` to existing `_blank` links;
2. repair an explicit GitHub/Repository placeholder only when a real GitHub origin remote is discoverable.

No redesign, invented repo URL, invented public deployment, or claim widening is allowed.

Terminal outcomes include PASS, FAIL_WITH_DEFECT, and explicit BLOCKED states.
A blocker never becomes a fake green seal.

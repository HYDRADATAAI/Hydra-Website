# HYDRA_CONSTRAINT_CASE_STUDY_V2

## Public story

`FRAGMENTED MARKET EVIDENCE`
↓
`SOURCE NORMALIZATION`
↓
`IDENTITY RESOLUTION`
↓
`CONTRACT / AUTHORITY CHECK`
↓
`PROVENANCE + HISTORY`
↓
`CONSTRAINT INTERPRETATION`
↓
`AUDITABLE RESULT`

## Core engineering principle

**Discoverable data is not automatically authorized data.**

A value can be present somewhere in the working evidence universe and still be inadmissible for a specific downstream handoff. HYDRA requires the value to be owned by, or legitimately derivable under, the applicable contract. If that authority cannot be proven, the handoff blocks rather than borrowing or fabricating a value.

## Visible blocked state

The public case includes a clearly labeled `SHADOW` authority-control branch:

- discoverable candidate data: YES;
- authorized for handoff: NO;
- result: BLOCK;
- semantic values invented: NO;
- canonical promotion: NONE.

This is the recruiter-facing lesson from CI-008. The site does not require the reader to learn CI-008 version history.

## Representative case result

The market walkthrough is `REPRESENTATIVE`. It resolves to a local bottleneck pattern and does not promote the broader systemic-shortage claim.

## Evidence labels

- market fragments, normalized record, identity example, constraint interpretation, and output: `REPRESENTATIVE`;
- repaired-seam and quarantine control receipts: `SYNTHETIC / SHADOW`;
- missing-authority blocked receipt: `SHADOW`.

## Acceptance

- pipeline understandable: PASS;
- source-to-result lineage visible: PASS;
- authority checks visible: PASS;
- blocked states presented as valid engineering outcomes: PASS;
- unsupported live-production implication: NONE.

# README W5 Change Log

The W4 front door already had the correct overall story. W5 makes only bounded claim-safety edits.

- `market/reference/history evidence through ...` → `models market/reference/history inputs through ...`
- adds explicit disclaimer: no live production market inference, public production ingestion runtime, or public runnable demo
- `Source` row wording tightened to inputs
- `Provenance` principle → `Provenance-aware design`
- architecture `Release Gates` wording → `Validation Gates`
- output wording clarified as structures unless supported by executed proof
- keeps N1 / CI-005 / CI-008 receipts and values unchanged

No visual redesign, repository archaeology, new demo, new runtime, or new HYDRA architecture was introduced.

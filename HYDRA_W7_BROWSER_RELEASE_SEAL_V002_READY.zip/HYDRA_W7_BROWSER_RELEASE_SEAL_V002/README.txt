HYDRA W7 BROWSER RELEASE SEAL V002

Read-only against D:\HYDRA_SITE\V7. It copies the site to an instrumented temporary mirror.
Checks every HTML page at desktop/tablet/mobile sizes, JS/runtime errors, failed resources,
horizontal overflow, broken images, basic readability, screenshots, GitHub reachability,
and optionally a real public deployment URL.

Without -PublicUrl, a clean browser run intentionally returns:
BROWSER_LOCAL_VERDICT=PASS_BROWSER_LOCAL
PUBLIC_RELEASE_SEAL=BLOCKED

That means the browser checks are green but public deployment has not yet been proven.

V002 HARNESS FIX
----------------
Chrome stdout/stderr is captured as raw bytes and decoded explicitly with:
  UTF-8 + errors='replace'

This prevents Windows/Python CP1252 reader-thread UnicodeDecodeError failures
from corrupting DOM probe capture and producing false PROBE_MISSING/browser failures.

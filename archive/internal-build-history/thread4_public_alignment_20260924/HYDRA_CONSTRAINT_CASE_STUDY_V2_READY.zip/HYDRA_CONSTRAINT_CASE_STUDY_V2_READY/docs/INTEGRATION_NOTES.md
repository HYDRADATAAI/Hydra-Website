# Integration Notes

This package is a recruiter-facing W3 module intended to sit below the frozen HYDRA hero.

## Preferred placement

1. Frozen recruiter hero.
2. W2 recruiter technical proof strip.
3. This W3 constraint case study.
4. Deeper architecture / evidence / repository links.

## What not to change

Do not rewrite the frozen hero to accommodate this module. The case study exists to deepen proof below the hero.

## Public-language rule

Keep the sentence **"Discoverable data is not automatically authorized data."** prominent. It translates the authority/admissibility lesson into normal engineering language without exposing internal CI-008 archaeology.

## Label rule

Retain `REPRESENTATIVE`, `SYNTHETIC`, and `SHADOW` labels anywhere the corresponding content appears. Do not replace them with softer marketing language.

# PUBLIC_SITE_RELEASE_SEAL

`OVERALL=FAIL_WITH_DEFECT`

- SITE_ROOT: `D:\HYDRA\HYDRA DESKTOP\HYDRA stash\HydraTrain\stuff\textgen-portable-3.3.2-windows-cpu\text-generation-webui\portable_env\Lib\site-packages\gradio\templates\frontend`
- PUBLIC_DEPLOYMENT: `PASS` `https://gradio.app/`
- BROWSER_RENDER: `FAIL`
- STATIC_HARD_FAILURES: `7`
- EXTERNAL_LINK_FAILURES: `0`
- EXTERNAL_LINK_BLOCKED: `0`
- SAFE_REPAIRS_APPLIED: `0`

## Static checks

- `HERO_TITLE=FAIL` — MARKET INTELLIGENCE DATA PLATFORM
- `TAGLINE=FAIL` — Turn fragmented market data into traceable intelligence.
- `BADGE_MULTI_SOURCE_INGESTION=FAIL` — Multi-source ingestion
- `BADGE_CONTRACT_BOUND_HANDOFFS=FAIL` — Contract-bound handoffs
- `BADGE_LINEAGE_RELEASE_GATES=FAIL` — Lineage + release gates
- `PROOF_ENTRYPOINT=FAIL` — Technical Proof / proof navigation
- `GITHUB_LINK=FAIL` — github links=0
- `PLACEHOLDER_LINKS=PASS` — count=0
- `BROKEN_INTERNAL_ANCHORS=PASS` — count=0
- `LOCAL_ASSETS=PASS` — missing=0
- `VIEWPORT_META=PASS` — responsive viewport

## Browser viewports

- `DESKTOP=FAIL` overflow=False broken_images=0 js_errors=3 tiny_text=0
- `TABLET=FAIL` overflow=False broken_images=0 js_errors=3 tiny_text=0
- `MOBILE=FAIL` overflow=False broken_images=0 js_errors=3 tiny_text=0

## Release rule

Seal only when static checks, public deployment, external links, and desktop/tablet/mobile render probes are proven green. Blockers remain blockers.

# NYX Constraint Intelligence T1-T5 — Batch 65 Receipt-Bound Host Builder

This ZIP does **not** claim Batch 65 is already sealed. It builds Batch 65 only after your local Batch 64 build has produced a real `BATCH64_SEAL_RECEIPT.json`.

## One click

1. Finish Batch 64 with the prior host builder.
2. Leave its output in the default `D:\NYX_BATCH64_BUILD` folder, or keep the sealed Batch 64 ZIP / ten Batch 64 transfer ZIPs plus `BATCH64_SEAL_RECEIPT.json` together.
3. Extract this ZIP.
4. Double-click `RUN_BATCH65_FROM_BATCH64.cmd`.

The runner prefers the already sealed Batch 64 ZIP if present. If absent, it reconstructs Batch 64 from the ten transfer ZIPs. In both cases the bytes and SHA-256 must match the Batch 64 seal receipt exactly before Batch 65 construction begins.

## Batch 65 target

- Packaging: `DELTA_WITH_EXACT_SEALED_PREDECESSOR`
- Boundary: `SYNTHETIC_SHADOW_ONLY`
- Schema profile: `2.47`
- Golden seeds: `65001` through `65012`
- Outer members: `8,915`
- Manifest-governed entries: `8,912`
- Shadow QA checks: `3,463`
- Transfer ZIPs: exactly `10`
- Thread 6: `NOT_STARTED`
- Real production data: not used
- Automatic canonical promotion: disabled
- Baby-ML training: disabled
- Trading-signal generation: disabled

## Batch 65 focus

T1 expands into locale-sensitive Unicode casefold profile drift, sub-minute timezone offset precision, currency-quantum version drift, reference compaction epochs, duplicate-member semantic hashing, and grapheme-normalization provenance offsets.

T2 adds PDF optional-content visibility leakage, denominator-basis table scope bleed, cross-venue symbol epochs, nested unless/except polarity, and cursor-restart overlap duplication.

A successful run writes the sealed Batch 65 ZIP, ten Batch 65 transfer ZIPs, and `BATCH65_SEAL_RECEIPT.json`.

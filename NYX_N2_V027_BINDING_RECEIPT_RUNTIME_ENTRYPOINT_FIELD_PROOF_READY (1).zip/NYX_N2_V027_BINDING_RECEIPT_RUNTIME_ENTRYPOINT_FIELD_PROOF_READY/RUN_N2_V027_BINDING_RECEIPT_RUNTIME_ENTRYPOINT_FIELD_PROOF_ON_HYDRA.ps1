param(
    [string]$HydraRoot="D:\HYDRA",
    [string]$V026Evidence=""
)
$ErrorActionPreference="Stop"
Set-StrictMode -Version Latest

Write-Host "============================================================"
Write-Host "NYX N2 V027 - BINDING RECEIPT RUNTIME ENTRYPOINT FIELD PROOF"
Write-Host "============================================================"
Write-Host "PARENT_DEFECT=N2-DEFECT-022-RESOLVED-TARGETS-NON-EXECUTABLE"
Write-Host "HYDRA_ROOT=$HydraRoot"
Write-Host "MODE=READ_ONLY_BINDING_RECEIPT_RUNTIME_ENTRYPOINT_FIELD_PROOF"
Write-Host "SCOPE=BINDING_RECEIPTS_ONLY"
Write-Host "WHOLE_TREE_SEARCH=NO"
Write-Host "TARGET_CHILD_TRAVERSAL=NO"
Write-Host "SCORE_SELECTION=NO"
Write-Host "MTIME_AUTHORITY=NO"
Write-Host "NEWEST_WINS=NO"
Write-Host "ALIAS_BINDING=NONE"
Write-Host "UPSTREAM_MUTATION_AUTHORIZED=NO"
Write-Host "N2_MUTATION=NONE"

$Downloads=Join-Path $env:USERPROFILE "Downloads"
if(-not $V026Evidence){
    $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "N2_V026_RETURN_PACKET_*.zip" -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending
    $Found=$null
    foreach($C in $Candidates){
        $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        if($H -eq "f99515fbd8c0a022639fa7f3ea21c10f47dc7d87359b1463efa3e45ba93517e3"){$Found=$C;break}
    }
    if(-not $Found){
        $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "*V026*RETURN*.zip" -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending
        foreach($C in $Candidates){
            $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            if($H -eq "f99515fbd8c0a022639fa7f3ea21c10f47dc7d87359b1463efa3e45ba93517e3"){$Found=$C;break}
        }
    }
    if(-not $Found){throw "Exact V026 return packet not found with SHA256=f99515fbd8c0a022639fa7f3ea21c10f47dc7d87359b1463efa3e45ba93517e3"}
    $V026Evidence=$Found.FullName
}

$Actual=(Get-FileHash -LiteralPath $V026Evidence -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host "V026_EVIDENCE=$V026Evidence"
Write-Host "V026_EVIDENCE_SHA256=$Actual"
if($Actual -ne "f99515fbd8c0a022639fa7f3ea21c10f47dc7d87359b1463efa3e45ba93517e3"){throw "V026 evidence hash mismatch."}
Write-Host "V026_EVIDENCE_HASH_VERIFIED=PASS"

$PkgRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
$Py=Join-Path $PkgRoot "n2_v027_binding_receipt_runtime_entrypoint_field_proof.py"

$PythonCmd=Get-Command python.exe -ErrorAction SilentlyContinue
$PyLauncher=Get-Command py.exe -ErrorAction SilentlyContinue
if($PythonCmd){
    $PythonExe=$PythonCmd.Source
    $Prefix=@()
    Write-Host "PYTHON_LAUNCH_MODE=DIRECT_PYTHON"
}elseif($PyLauncher){
    $PythonExe=$PyLauncher.Source
    $Prefix=@("-3")
    Write-Host "PYTHON_LAUNCH_MODE=PY_LAUNCHER_3"
}else{throw "Python not found."}
Write-Host "PYTHON_COMMAND=$PythonExe"

& $PythonExe @Prefix $Py --selftest
if($LASTEXITCODE -ne 0){throw "V027 selftest failed."}

$RunDir="D:\NYX_N2_WORK\V027_BINDING_RECEIPT_ENTRYPOINT_$(Get-Date -Format yyyyMMdd_HHmmss)"
$ReturnDir=Join-Path $RunDir "N2_V027_RETURN"
New-Item -ItemType Directory -Path $ReturnDir -Force|Out-Null
Write-Host "RUN_DIR=$RunDir"

& $PythonExe @Prefix $Py --hydra-root $HydraRoot --v026-evidence $V026Evidence --output-dir $ReturnDir
if($LASTEXITCODE -ne 0){throw "V027 receipt entrypoint proof failed."}

$R=Get-Content -LiteralPath (Join-Path $ReturnDir "N2_V027_BINDING_RECEIPT_RUNTIME_ENTRYPOINT_FIELD_PROOF.json") -Raw|ConvertFrom-Json
$ReturnZip=Join-Path $Downloads ("N2_V027_BINDING_RECEIPT_RUNTIME_ENTRYPOINT_RETURN_{0}.zip" -f (Get-Date -Format yyyyMMdd_HHmmss))
Compress-Archive -Path (Join-Path $ReturnDir "*") -DestinationPath $ReturnZip -CompressionLevel Optimal
$ReturnSha=(Get-FileHash -LiteralPath $ReturnZip -Algorithm SHA256).Hash.ToLowerInvariant()

Write-Host ""
Write-Host "============================================================"
Write-Host "N2 V027 FINAL"
Write-Host "============================================================"
Write-Host "FINAL=$($R.status)"
Write-Host "DEFECT_ID=$($R.defect_id)"
Write-Host "RECEIPT_SEED_COUNT=$($R.receipt_seed_count)"
Write-Host "LIVE_RECEIPT_COUNT=$($R.live_receipt_count)"
Write-Host "EXPLICIT_RUNTIME_FIELD_COUNT=$($R.explicit_runtime_field_count)"
Write-Host "RESOLVED_EXECUTABLE_TARGET_COUNT=$($R.resolved_executable_target_count)"
if($null -ne $R.selected_runtime_entrypoint){
    Write-Host "SELECTED_RUNTIME_ENTRYPOINT=$($R.selected_runtime_entrypoint.path)"
    Write-Host "SELECTED_RUNTIME_ENTRYPOINT_SHA256=$($R.selected_runtime_entrypoint.sha256)"
    Write-Host "SELECTED_RUNTIME_ENTRYPOINT_RECEIPT=$($R.selected_runtime_entrypoint.receipt_path)"
    Write-Host "SELECTED_RUNTIME_ENTRYPOINT_FIELD=$($R.selected_runtime_entrypoint.field)"
}
Write-Host "READ_ONLY=TRUE"
Write-Host "BASELINE_MUTATED=FALSE"
Write-Host "CANONICAL_CORE_MUTATED=FALSE"
Write-Host "N2_MUTATED=FALSE"
Write-Host "NEXT_ACTION=$($R.next_action)"
Write-Host "RETURN_ZIP=$ReturnZip"
Write-Host "RETURN_SHA256=$ReturnSha"
Write-Host "RETURN_RUN_DIR=$RunDir"

# HYDRA Website V1

A dependency-free, responsive portfolio site for presenting HYDRA as a data-engineering-first project with a future generative-AI division.

## Run locally

The quickest option on Windows:

1. Extract the folder.
2. Double-click `index.html`.

For a local web server from PowerShell, if Python is installed:

```powershell
cd path\to\hydra_website_v1
python -m http.server 8080
```

Then open `http://localhost:8080`.

## Add the GitHub repository later

Open `app.js` and set:

```js
repositoryUrl: "https://github.com/YOURNAME/YOURREPO",
```

The disabled repository button will automatically become a live GitHub button.

## Design direction

- **Primary story:** dependable data engineering
- **Secondary story:** AI readiness / long-term generative AI layer
- **Tone:** technical, clean, restrained, credible
- **No fake metrics:** the site intentionally avoids invented scale, benchmarks, customer claims, or production-status language

## Suggested next pass

When the public repo is ready, replace the generic architecture section with one real architecture diagram and add 2–4 concrete project artifacts, such as:

- a pipeline flow or lineage screenshot
- one integrated test / defect-closeout example
- one data contract / schema example
- one cloud architecture diagram once AWS work is underway

That will turn the site from a polished shell into a very strong hiring-manager project page.

# Phase-0 Binding/Runtime — DEFECT-026 Handoff

N2 V031 has sealed successfully as a blocked external-owner state.

Pinned N2 V031 return SHA-256:

`620677b7e81a29e77627879dc9005e5bd696dff12be8d037e6e45a8699f8cf1b`

Do not continue N2 discovery.

The defect now belongs to:

`PHASE0_BINDING_RUNTIME`

Mission:

Prove or install exactly one legitimate deployment activation contract connecting one of the two
current Phase-0 deployment roots to its authoritative runtime entrypoint/runner.

Do not infer activation from folder names, timestamps, newest-wins, basename popularity, or the
fact that the deployed writer copies are byte-identical.

If authority exists, return:

`DEPLOYMENT_ACTIVATION_CONTRACT_PROVEN`

If authority does not exist, return:

`BLOCKED_BY_MISSING_DEPLOYMENT_ACTIVATION_AUTHORITY`

N2 stays archived until the reopen gate is satisfied.

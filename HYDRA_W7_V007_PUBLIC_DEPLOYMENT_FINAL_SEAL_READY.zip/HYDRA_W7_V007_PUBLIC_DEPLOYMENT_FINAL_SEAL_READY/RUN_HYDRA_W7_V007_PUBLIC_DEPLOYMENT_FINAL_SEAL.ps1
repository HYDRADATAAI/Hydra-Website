﻿param(
    [string]$PublicUrl = ""
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$SiteRoot = "D:\HYDRA_SITE\V7"
$ResultBase = "D:\HYDRA\WEBSITE_TEST_RESULTS"
$ExpectedV006ResultSha = "c817419605be0265977efae959d846e077dd3ac2766a3f9c7b2970856edb69b0"
$RepoUrl = "https://github.com/HYDRADATAAI/hydra-website"
$RepoApi = "https://api.github.com/repos/HYDRADATAAI/hydra-website"
$PagesApi = "$RepoApi/pages"

Write-Host "===================================================================="
Write-Host "HYDRA W7 V007 - PUBLIC DEPLOYMENT FINAL SEAL"
Write-Host "===================================================================="
Write-Host "MODE=READ_ONLY_PUBLIC_VERIFICATION"
Write-Host "SITE_ROOT=$SiteRoot"
Write-Host "SITE_MUTATION=NONE"
Write-Host "PUBLIC_DEPLOYMENT_MUTATION=NONE"
Write-Host "EXPECTED_V006_RESULT_SHA256=$ExpectedV006ResultSha"
Write-Host "===================================================================="

if (-not (Test-Path -LiteralPath $SiteRoot -PathType Container)) {
    throw "Authoritative V7 site root missing: $SiteRoot"
}

# -------------------------------------------------------------------
# 1. Bind to the already-sealed W7 V006 local result.
# -------------------------------------------------------------------
$downloads = Join-Path $HOME "Downloads"
$v006Candidates = @(
    Get-ChildItem -LiteralPath $downloads -File -Filter "HYDRA_W7_V006_FINAL_LOCAL_SEAL_RESULT_*.zip" -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending
)

$v006 = $null
foreach ($candidate in $v006Candidates) {
    $h = (Get-FileHash -LiteralPath $candidate.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($h -eq $ExpectedV006ResultSha) {
        $v006 = $candidate
        break
    }
}

if (-not $v006) {
    Write-Host "LOCAL_V006_RECEIPT=NOT_FOUND_OR_HASH_MISMATCH"
    Write-Host "FINAL_PUBLIC_SEAL=BLOCKED"
    Write-Host "BLOCKER=AUTHORITATIVE_V006_LOCAL_SEAL_RECEIPT_REQUIRED"
    exit 20
}

Write-Host "LOCAL_V006_RECEIPT=$($v006.FullName)"
Write-Host "LOCAL_V006_RECEIPT_SHA256=$ExpectedV006ResultSha"
Write-Host "LOCAL_V006_RECEIPT_PIN=PASS"

# -------------------------------------------------------------------
# 2. Resolve the authoritative public URL without inventing one.
# Resolution order:
#   parameter -> Downloads\HYDRA_PUBLIC_URL.txt -> GitHub Pages API
# -------------------------------------------------------------------
if ([string]::IsNullOrWhiteSpace($PublicUrl)) {
    $urlFile = Join-Path $downloads "HYDRA_PUBLIC_URL.txt"
    if (Test-Path -LiteralPath $urlFile -PathType Leaf) {
        $candidateUrl = (Get-Content -LiteralPath $urlFile -Raw).Trim()
        if (-not [string]::IsNullOrWhiteSpace($candidateUrl)) {
            $PublicUrl = $candidateUrl
            Write-Host "PUBLIC_URL_SOURCE=DOWNLOADS_URL_FILE"
        }
    }
} else {
    Write-Host "PUBLIC_URL_SOURCE=RUNNER_PARAMETER"
}

if ([string]::IsNullOrWhiteSpace($PublicUrl)) {
    try {
        $headers = @{
            "User-Agent" = "HYDRA-W7-V007-PUBLIC-SEAL"
            "Accept" = "application/vnd.github+json"
        }
        $pages = Invoke-RestMethod -Uri $PagesApi -Headers $headers -Method Get -TimeoutSec 20
        if ($pages -and $pages.html_url) {
            $PublicUrl = [string]$pages.html_url
            Write-Host "PUBLIC_URL_SOURCE=GITHUB_PAGES_API"
        }
    } catch {
        Write-Host "GITHUB_PAGES_DISCOVERY=NOT_PROVEN"
    }
}

if ([string]::IsNullOrWhiteSpace($PublicUrl)) {
    Write-Host "PUBLIC_HYDRA_URL=NOT_PROVEN"
    Write-Host "FINAL_PUBLIC_SEAL=BLOCKED"
    Write-Host "BLOCKER=PUBLIC_DEPLOYMENT_URL_NOT_PROVEN"
    Write-Host "NEXT_ACTION=ENABLE_OR_BIND_PUBLIC_DEPLOYMENT_THEN_RERUN_V007"
    exit 21
}

try {
    $baseUri = [Uri]$PublicUrl
} catch {
    throw "Invalid public URL: $PublicUrl"
}

if ($baseUri.Scheme -notin @("http","https")) {
    throw "Public URL must be http/https: $PublicUrl"
}

$normalizedBase = $baseUri.AbsoluteUri
if (-not $normalizedBase.EndsWith("/")) {
    $normalizedBase += "/"
}
Write-Host "PUBLIC_HYDRA_URL=$normalizedBase"

# -------------------------------------------------------------------
# 3. Fetch public root.
# -------------------------------------------------------------------
$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$headers = @{ "User-Agent" = "HYDRA-W7-V007-PUBLIC-SEAL" }

try {
    $rootResponse = Invoke-WebRequest -Uri $normalizedBase -Headers $headers -WebSession $session -UseBasicParsing -MaximumRedirection 8 -TimeoutSec 30
} catch {
    Write-Host "PUBLIC_ROOT_HTTP=FAIL"
    Write-Host "FINAL_PUBLIC_SEAL=BLOCKED"
    Write-Host "BLOCKER=PUBLIC_ROOT_UNREACHABLE"
    Write-Host "DETAIL=$($_.Exception.Message)"
    exit 22
}

$rootStatus = [int]$rootResponse.StatusCode
Write-Host "PUBLIC_ROOT_HTTP_STATUS=$rootStatus"
if ($rootStatus -lt 200 -or $rootStatus -ge 400) {
    Write-Host "FINAL_PUBLIC_SEAL=BLOCKED"
    Write-Host "BLOCKER=PUBLIC_ROOT_NON_SUCCESS_STATUS"
    exit 23
}
Write-Host "PUBLIC_ROOT_HTTP=PASS"

# -------------------------------------------------------------------
# 4. Crawl same-origin HTML routes found from public pages.
# Bounded: max 50 pages.
# -------------------------------------------------------------------
function Resolve-Link {
    param([Uri]$Base, [string]$Href)

    if ([string]::IsNullOrWhiteSpace($Href)) { return $null }
    $h = $Href.Trim()
    if ($h.StartsWith("#")) { return $null }
    if ($h -match '^(?i)(mailto:|tel:|javascript:|data:)') { return $null }

    try {
        return [Uri]::new($Base, $h)
    } catch {
        return $null
    }
}

$origin = "{0}://{1}" -f $baseUri.Scheme, $baseUri.Authority
$queue = New-Object System.Collections.Generic.Queue[Uri]
$seen = New-Object 'System.Collections.Generic.HashSet[string]'
$results = New-Object System.Collections.Generic.List[object]
$externalLinks = New-Object System.Collections.Generic.HashSet[string]

$queue.Enqueue([Uri]$normalizedBase)

while ($queue.Count -gt 0 -and $seen.Count -lt 50) {
    $u = $queue.Dequeue()
    $key = $u.AbsoluteUri.Split("#")[0]

    if ($seen.Contains($key)) { continue }
    [void]$seen.Add($key)

    try {
        $r = Invoke-WebRequest -Uri $key -Headers $headers -WebSession $session -UseBasicParsing -MaximumRedirection 8 -TimeoutSec 30
        $status = [int]$r.StatusCode
        $ok = ($status -ge 200 -and $status -lt 400)
        $contentType = [string]$r.Headers["Content-Type"]

        $results.Add([pscustomobject]@{
            url = $key
            status = $status
            ok = $ok
            content_type = $contentType
        })

        if ($ok -and ($contentType -match 'text/html' -or $key -match '\.html?$' -or $key.EndsWith("/"))) {
            $html = [string]$r.Content

            # Deployment-leak checks.
            if ($html -match '(?i)\bUNBOUND\b') {
                $results.Add([pscustomobject]@{
                    url = $key
                    status = 0
                    ok = $false
                    content_type = "ERROR:PUBLIC_UNBOUND_LITERAL"
                })
            }

            $matches = [regex]::Matches($html, '(?i)\bhref\s*=\s*["'']([^"'']+)["'']')
            foreach ($m in $matches) {
                $href = $m.Groups[1].Value
                $resolved = Resolve-Link -Base ([Uri]$key) -Href $href
                if (-not $resolved) { continue }

                $resolvedOrigin = "{0}://{1}" -f $resolved.Scheme, $resolved.Authority
                if ($resolvedOrigin -eq $origin) {
                    $path = $resolved.AbsolutePath.ToLowerInvariant()
                    $looksPage = (
                        $path.EndsWith("/") -or
                        $path.EndsWith(".html") -or
                        $path.EndsWith(".htm") -or
                        -not [IO.Path]::GetExtension($path)
                    )
                    if ($looksPage -and -not $seen.Contains($resolved.AbsoluteUri.Split("#")[0])) {
                        $queue.Enqueue($resolved)
                    }
                } elseif ($resolved.Scheme -in @("http","https")) {
                    [void]$externalLinks.Add($resolved.AbsoluteUri.Split("#")[0])
                }
            }
        }
    } catch {
        $results.Add([pscustomobject]@{
            url = $key
            status = 0
            ok = $false
            content_type = "ERROR:$($_.Exception.Message)"
        })
    }
}

$failures = @($results | Where-Object { -not $_.ok })
Write-Host "PUBLIC_ROUTE_COUNT=$($seen.Count)"
Write-Host "PUBLIC_ROUTE_FAILURE_COUNT=$($failures.Count)"

foreach ($row in $results) {
    Write-Host ("ROUTE status={0} ok={1} url={2}" -f $row.status, $row.ok, $row.url)
}

# -------------------------------------------------------------------
# 5. Verify authoritative GitHub repository is reachable and referenced.
# -------------------------------------------------------------------
$githubReachable = $false
try {
    $gh = Invoke-WebRequest -Uri $RepoUrl -Headers $headers -UseBasicParsing -MaximumRedirection 8 -TimeoutSec 30
    $githubReachable = ([int]$gh.StatusCode -ge 200 -and [int]$gh.StatusCode -lt 400)
} catch {}

$githubReferenced = $false
foreach ($x in $externalLinks) {
    if ($x.TrimEnd("/") -eq $RepoUrl.TrimEnd("/")) {
        $githubReferenced = $true
        break
    }
}

Write-Host "GITHUB_REPO_REACHABLE=$($githubReachable.ToString().ToUpperInvariant())"
Write-Host "GITHUB_REPO_REFERENCED=$($githubReferenced.ToString().ToUpperInvariant())"

# -------------------------------------------------------------------
# 6. Final public seal.
# -------------------------------------------------------------------
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$ResultDir = Join-Path $ResultBase "W7_V007_PUBLIC_DEPLOYMENT_FINAL_SEAL_$Stamp"
New-Item -ItemType Directory -Path $ResultDir -Force | Out-Null

$publicPass = (
    $rootStatus -ge 200 -and
    $rootStatus -lt 400 -and
    $failures.Count -eq 0 -and
    $githubReachable -and
    $githubReferenced
)

$seal = [ordered]@{
    test_id = "HYDRA_W7_V007_PUBLIC_DEPLOYMENT_FINAL_SEAL"
    mode = "READ_ONLY_PUBLIC_VERIFICATION"
    site_root = $SiteRoot
    site_mutation = "NONE"
    authoritative_local_v006_receipt = $v006.FullName
    authoritative_local_v006_sha256 = $ExpectedV006ResultSha
    local_v006_receipt_pin = $true
    public_url = $normalizedBase
    public_root_http_status = $rootStatus
    public_route_count = $seen.Count
    public_route_failure_count = $failures.Count
    github_repo = $RepoUrl
    github_repo_reachable = $githubReachable
    github_repo_referenced = $githubReferenced
    public_deployment = $(if ($publicPass) { "PASS" } else { "BLOCKED" })
    public_site_release_seal = $(if ($publicPass) { "PASS" } else { "BLOCKED" })
    failures = @($failures)
    checked_at = (Get-Date).ToString("o")
}

$jsonPath = Join-Path $ResultDir "PUBLIC_SITE_RELEASE_SEAL.json"
$txtPath = Join-Path $ResultDir "PUBLIC_SITE_RELEASE_SEAL.txt"

$seal | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $jsonPath -Encoding UTF8

@"
HYDRA W7 V007 PUBLIC DEPLOYMENT FINAL SEAL
===========================================
PUBLIC_HYDRA_URL=$normalizedBase
LOCAL_V006_RECEIPT_PIN=PASS
PUBLIC_ROOT_HTTP_STATUS=$rootStatus
PUBLIC_ROUTE_COUNT=$($seen.Count)
PUBLIC_ROUTE_FAILURE_COUNT=$($failures.Count)
GITHUB_REPO_REACHABLE=$($githubReachable.ToString().ToUpperInvariant())
GITHUB_REPO_REFERENCED=$($githubReferenced.ToString().ToUpperInvariant())
PUBLIC_DEPLOYMENT=$($seal.public_deployment)
PUBLIC_SITE_RELEASE_SEAL=$($seal.public_site_release_seal)
SITE_MUTATION=NONE
"@ | Set-Content -LiteralPath $txtPath -Encoding UTF8

$resultZip = Join-Path $downloads ("HYDRA_W7_V007_PUBLIC_SITE_RELEASE_SEAL_RESULT_{0}.zip" -f $Stamp)
Compress-Archive -Path (Join-Path $ResultDir "*") -DestinationPath $resultZip -Force
$resultHash = (Get-FileHash -LiteralPath $resultZip -Algorithm SHA256).Hash.ToLowerInvariant()

Write-Host "RESULT_DIR=$ResultDir"
Write-Host "RESULT_ZIP=$resultZip"
Write-Host "RESULT_ZIP_SHA256=$resultHash"
Write-Host "PUBLIC_DEPLOYMENT=$($seal.public_deployment)"
Write-Host "PUBLIC_SITE_RELEASE_SEAL=$($seal.public_site_release_seal)"
Write-Host "SITE_MUTATION=NONE"

if ($publicPass) {
    Write-Host "OVERALL=PASS_PUBLIC_SITE_RELEASE_SEAL"
    exit 0
}

Write-Host "OVERALL=BLOCKED_PUBLIC_SITE_RELEASE_SEAL"
exit 24

param(
  [string]$HydraRoot = "D:\HYDRA",
  [string]$SiteRoot = "D:\HYDRA_SITE\V7"
)
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$ResultRoot = Join-Path $HydraRoot ("WEBSITE_TEST_RESULTS\W7_V005_PUBLIC_DEPLOYMENT_PREFLIGHT_" + $Stamp)
New-Item -ItemType Directory -Force -Path $ResultRoot | Out-Null

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "HYDRA W7 V005 - PUBLIC DEPLOYMENT PREFLIGHT" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "MODE=READ_ONLY"
Write-Host "SITE_ROOT=$SiteRoot"
Write-Host "RESULT_ROOT=$ResultRoot"

$Py = Get-Command python -ErrorAction SilentlyContinue
if (-not $Py) { $Py = Get-Command py -ErrorAction SilentlyContinue }
if (-not $Py) { throw "Python not found." }

& $Py.Source (Join-Path $Here "w7_v005_public_deployment_preflight.py") `
  --site-root $SiteRoot `
  --result-root $ResultRoot
$ExitCode = $LASTEXITCODE

$Downloads = Join-Path $HOME "Downloads"
$Out = Join-Path $Downloads ("HYDRA_W7_V005_PUBLIC_DEPLOYMENT_PREFLIGHT_RESULT_" + $Stamp + ".zip")
if (Test-Path $Out) { Remove-Item $Out -Force }
Compress-Archive -Path (Join-Path $ResultRoot "*") -DestinationPath $Out -CompressionLevel Optimal
$Hash = (Get-FileHash $Out -Algorithm SHA256).Hash.ToLowerInvariant()
"$Hash  $([IO.Path]::GetFileName($Out))" | Set-Content ($Out + ".sha256.txt") -Encoding ASCII

Write-Host ""
Write-Host "RESULT_ZIP=$Out" -ForegroundColor Green
Write-Host "RESULT_ZIP_SHA256=$Hash" -ForegroundColor Green
Write-Host "PREFLIGHT_EXIT_CODE=$ExitCode"
Write-Host "NEXT=Return console output or RESULT ZIP to Nyx." -ForegroundColor Yellow
exit $ExitCode

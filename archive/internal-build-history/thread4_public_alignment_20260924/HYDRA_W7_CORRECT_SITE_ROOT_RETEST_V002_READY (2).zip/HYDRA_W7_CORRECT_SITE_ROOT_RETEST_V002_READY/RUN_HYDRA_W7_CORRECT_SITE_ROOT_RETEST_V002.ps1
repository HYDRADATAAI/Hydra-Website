﻿param([string]$HydraRoot="D:\HYDRA")
$ErrorActionPreference="Stop"
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$resultRoot=Join-Path $HydraRoot "WEBSITE_TEST_RESULTS\W7_CORRECT_SITE_ROOT_RETEST_$stamp"
New-Item -ItemType Directory -Path $resultRoot -Force | Out-Null
Write-Host "===================================================================="
Write-Host "HYDRA W7 V002 - CORRECT SITE ROOT + ROOT-BOUND RETEST"
Write-Host "===================================================================="
Write-Host "HYDRA_ROOT=$HydraRoot"
Write-Host "RESULT_ROOT=$resultRoot"

$excluded=@("\\node_modules\\","\\site-packages\\","\\portable_env\\","\\.venv\\","\\venv\\","\\text-generation-webui\\","\\gradio\\","\\WEBSITE_TEST_RESULTS\\","\\TEST_RESULTS\\","\\archive\\","\\archives\\","\\backups\\")
function Excluded([string]$p){foreach($x in $excluded){if($p -match $x){return $true}};return $false}
function Depth([string]$p){$r=$p.Substring($HydraRoot.Length).TrimStart('\\');if(-not $r){return 0};return ($r -split '\\').Count}
function Corpus([string]$d){
  $sb=New-Object System.Text.StringBuilder
  $files=Get-ChildItem -LiteralPath $d -Recurse -File -ErrorAction SilentlyContinue | Where-Object { -not (Excluded $_.FullName) -and $_.Length -le 8MB -and $_.Extension -match '^\.(html|js|css|svelte|tsx|jsx|ts|md)$' } | Select-Object -First 300
  foreach($f in $files){try{[void]$sb.AppendLine((Get-Content -LiteralPath $f.FullName -Raw -ErrorAction Stop))}catch{};if($sb.Length -gt 12000000){break}}
  return $sb.ToString()
}

$rows=@()
$idxs=Get-ChildItem -LiteralPath $HydraRoot -Recurse -File -Filter index.html -ErrorAction SilentlyContinue | Where-Object { -not (Excluded $_.FullName) -and (Depth $_.Directory.FullName) -le 5 }
foreach($idx in $idxs){
  $c=Corpus $idx.Directory.FullName
  $title=$c -match 'MARKET INTELLIGENCE DATA PLATFORM'
  $tag=$c -match 'Turn fragmented market data into traceable intelligence'
  $hydra=$c -match '\bHYDRA\b'
  $score=0;if($title){$score+=20};if($tag){$score+=20};if($hydra){$score+=4};if($c -match 'Contract-bound handoffs'){$score+=6};if($c -match 'Multi-source evidence inputs'){$score+=6};if($c -match 'Provenance \+ validation gates'){$score+=6};if($c -match 'Technical Proof|Inspect Technical Proof'){$score+=4}
  $rows+=[pscustomobject]@{SiteRoot=$idx.Directory.FullName;Score=$score;HeroTitle=$title;Tagline=$tag;Hydra=$hydra}
}
$rows=$rows|Sort-Object Score -Descending,SiteRoot
$rows|Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $resultRoot 'SITE_ROOT_CANDIDATES.csv')
$q=@($rows|Where-Object {$_.Score -ge 44 -and $_.HeroTitle -and $_.Tagline -and $_.Hydra})
if($q.Count -eq 0){Write-Host 'SITE_ROOT=NOT_FOUND';Write-Host 'OVERALL=BLOCKED_BY_MISSING_HYDRA_SITE_ROOT';exit 3}
$topScore=$q[0].Score;$top=@($q|Where-Object Score -eq $topScore)
if($top.Count -gt 1){Write-Host 'SITE_ROOT=AMBIGUOUS';$top|Format-Table -AutoSize;Write-Host 'OVERALL=BLOCKED_BY_AMBIGUOUS_HYDRA_SITE_ROOT';exit 4}
$siteRoot=$top[0].SiteRoot
Write-Host "SITE_ROOT=$siteRoot"
Write-Host "SITE_ROOT_SCORE=$topScore"
$c=Corpus $siteRoot
$checks=New-Object System.Collections.Generic.List[object]
function Check([string]$n,[bool]$ok,[string]$d){$s=$(if($ok){'PASS'}else{'FAIL'});$checks.Add([pscustomobject]@{check=$n;status=$s;detail=$d});Write-Host "$n=$s :: $d"}
Check 'HERO_TITLE' ($c -match 'MARKET INTELLIGENCE DATA PLATFORM') 'MARKET INTELLIGENCE DATA PLATFORM'
Check 'TAGLINE' ($c -match 'Turn fragmented market data into traceable intelligence') 'Turn fragmented market data into traceable intelligence.'
Check 'BADGE_MULTI_SOURCE_EVIDENCE_INPUTS' ($c -match 'Multi-source evidence inputs') 'W5-safe wording'
Check 'BADGE_CONTRACT_BOUND_HANDOFFS' ($c -match 'Contract-bound handoffs') 'Contract-bound handoffs'
Check 'BADGE_PROVENANCE_VALIDATION_GATES' ($c -match 'Provenance \+ validation gates') 'W5-safe wording'
Check 'PROOF_ENTRYPOINT' ($c -match 'Technical Proof|Inspect Technical Proof') 'Technical Proof navigation'

$html=Get-ChildItem -LiteralPath $siteRoot -Recurse -File -Filter '*.html' -ErrorAction SilentlyContinue|Where-Object{-not (Excluded $_.FullName)}
$placeholder=0;$missing=@();$viewport=$false
foreach($h in $html){$t=Get-Content -LiteralPath $h.FullName -Raw -ErrorAction SilentlyContinue;if($t -match '<meta[^>]+name=["'']viewport["'']'){$viewport=$true};$placeholder+=([regex]::Matches($t,'href\s*=\s*["''](?:\s*|#|javascript:void\(0\);?|javascript:;?)["'']','IgnoreCase')).Count;foreach($m in [regex]::Matches($t,'(?:src|href)\s*=\s*["'']([^"'']+)["'']','IgnoreCase')){$r=$m.Groups[1].Value;if(-not $r -or $r.StartsWith('#') -or $r -match '^(https?:|mailto:|tel:|data:|javascript:)'){continue};$clean=($r -split '[?#]')[0];if(-not $clean){continue};$target=Join-Path $h.Directory.FullName $clean;if(-not (Test-Path -LiteralPath $target)){$missing+=[pscustomobject]@{page=$h.FullName;ref=$r}}}}
Check 'PLACEHOLDER_LINKS' ($placeholder -eq 0) "count=$placeholder"
Check 'LOCAL_ASSETS' ($missing.Count -eq 0) "missing=$($missing.Count)"
Check 'VIEWPORT_META' $viewport 'responsive viewport'
if($missing.Count -gt 0){$missing|Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $resultRoot 'BROKEN_LOCAL_ASSETS.csv')}

$gh=[regex]::Matches($c,'https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+','IgnoreCase')|ForEach-Object{$_.Value.TrimEnd('/')}|Sort-Object -Unique
if($gh.Count -gt 0){$checks.Add([pscustomobject]@{check='GITHUB_LINK';status='PASS';detail=('count='+$gh.Count+' first='+$gh[0])});Write-Host "GITHUB_LINK=PASS :: count=$($gh.Count) first=$($gh[0])"}else{$checks.Add([pscustomobject]@{check='GITHUB_LINK';status='BLOCKED';detail='no public GitHub link in selected HYDRA site'});Write-Host 'GITHUB_LINK=BLOCKED :: no public GitHub link in selected HYDRA site'}

$fail=@($checks|Where-Object status -eq 'FAIL').Count;$blocked=@($checks|Where-Object status -eq 'BLOCKED').Count
$overall=$(if($fail -gt 0){'FAIL_WITH_DEFECT'}elseif($blocked -gt 0){'BLOCKED_WITH_CORRECT_SITE_ROOT'}else{'PASS_LOCAL_STATIC'})
$receipt=[pscustomobject]@{version='W7_V002';generated_at=(Get-Date).ToString('o');site_root=$siteRoot;site_root_score=$topScore;excluded_wrong_root_classes=$excluded;fail_count=$fail;blocked_count=$blocked;overall=$overall;checks=$checks}
$receipt|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $resultRoot 'W7_V002_ROOT_BOUND_RECEIPT.json') -Encoding UTF8
$checks|Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $resultRoot 'W7_V002_CHECKS.csv')
"SITE_ROOT=$siteRoot`nFAIL_COUNT=$fail`nBLOCKED_COUNT=$blocked`nOVERALL=$overall"|Set-Content -LiteralPath (Join-Path $resultRoot 'W7_V002_SUMMARY.txt') -Encoding UTF8
$resultZip=Join-Path $HOME ("Downloads\HYDRA_W7_CORRECT_SITE_ROOT_RETEST_RESULT_"+$stamp+".zip")
Compress-Archive -Path (Join-Path $resultRoot '*') -DestinationPath $resultZip -Force
$rh=(Get-FileHash -LiteralPath $resultZip -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host '====================================================================';Write-Host 'HYDRA W7 V002 ROOT-BOUND VERDICT';Write-Host '====================================================================';Write-Host "SITE_ROOT=$siteRoot";Write-Host "FAIL_COUNT=$fail";Write-Host "BLOCKED_COUNT=$blocked";Write-Host "OVERALL=$overall";Write-Host "RESULT_ZIP=$resultZip";Write-Host "RESULT_ZIP_SHA256=$rh"
if($fail -gt 0){exit 2}elseif($blocked -gt 0){exit 3}else{exit 0}

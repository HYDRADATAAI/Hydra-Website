
document.addEventListener('click', (event) => {
  const btn = event.target.closest('[data-tab]');
  if (!btn) return;
  const group = btn.closest('[data-tab-group]');
  if (!group) return;
  const id = btn.getAttribute('data-tab');
  group.querySelectorAll('[data-tab]').forEach(el => el.classList.toggle('active', el === btn));
  group.querySelectorAll('[data-panel]').forEach(el => el.classList.toggle('active', el.getAttribute('data-panel') === id));
});

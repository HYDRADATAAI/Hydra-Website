# HYDRA W7 V007 — PUBLIC DEPLOYMENT FINAL SEAL

## Mission

This is the only remaining W7 action after the local V006 seal.

It does **not** modify `D:\HYDRA_SITE\V7`.

It requires the authoritative W7 V006 local result receipt:
`HYDRA_W7_V006_FINAL_LOCAL_SEAL_RESULT_20260919_205314.zip`
SHA-256:
`c817419605be0265977efae959d846e077dd3ac2766a3f9c7b2970856edb69b0`

Then it resolves the real public URL without inventing one:

1. `-PublicUrl` parameter, or
2. `%USERPROFILE%\Downloads\HYDRA_PUBLIC_URL.txt`, or
3. the public GitHub Pages API for `HYDRADATAAI/hydra-website`.

If no authoritative public URL exists, the correct result is:

`PUBLIC_SITE_RELEASE_SEAL=BLOCKED`

If a public URL exists, V007 checks the public root, crawls bounded same-origin routes, rejects public `UNBOUND` literals, verifies the GitHub repository is reachable and referenced, and writes:

`PUBLIC_SITE_RELEASE_SEAL.json`
`PUBLIC_SITE_RELEASE_SEAL.txt`

A green run ends with:

`OVERALL=PASS_PUBLIC_SITE_RELEASE_SEAL`
`PUBLIC_DEPLOYMENT=PASS`
`PUBLIC_SITE_RELEASE_SEAL=PASS`

No website redesign or local site mutation is authorized here.

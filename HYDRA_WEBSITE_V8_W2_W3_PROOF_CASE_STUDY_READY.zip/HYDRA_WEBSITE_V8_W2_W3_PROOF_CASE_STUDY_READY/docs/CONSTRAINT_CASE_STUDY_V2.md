# CONSTRAINT CASE STUDY V2

## Story
`FRAGMENTED MARKET EVIDENCE`
↓
`SOURCE NORMALIZATION`
↓
`IDENTITY RESOLUTION`
↓
`CONTRACT / AUTHORITY CHECK`
↓
`PROVENANCE + HISTORY`
↓
`CONSTRAINT INTERPRETATION`
↓
`AUDITABLE RESULT`

## Representative outcome
The walkthrough resolves to a **local bottleneck** while deliberately refusing to promote a broader systemic-shortage claim. This is a representative/non-live scenario, not a production signal.

## Why it works as a data-engineering story
The case demonstrates that HYDRA separates four concerns that are often blurred together: source normalization, entity identity, semantic authority, and downstream interpretation. The final conclusion remains attached to the evidence and to the claims the system declined to make.

## Real proof embedded around the representative case
- CI-TEST-004 repaired rerun: PASS, zero failures, frozen baseline preserved.
- CI-TEST-006 quarantine/release-block path: PASS, lineage preserved.
- CI-TEST-008 authority gate: BLOCKED when required authoritative fields were absent; semantic values not invented.

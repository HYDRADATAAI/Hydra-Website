# Installation notes

This package is designed as a bounded replacement for a recruiter-facing GitHub front door.

## Safe install sequence

1. Preserve the current repository root README before replacement.
2. Copy this package's `README.md`, `docs/`, and `evidence/` into the public-safe repository.
3. Verify every relative link from the root README.
4. If the real public repository already has source directories worth surfacing, add them to `docs/REPOSITORY_MAP.md` **only after verifying they exist and are safe to expose**.
5. Do not link internal ZIP factories, raw paid/vendor data, secrets, private source dumps, stale handoffs, or superseded archives.
6. Do not advertise a runnable production demo until a public-safe entrypoint has been independently verified.

## W4 acceptance checklist

- README answers what HYDRA is in the first screen: **PASS**
- Architecture visible: **PASS**
- Data flow visible: **PASS**
- Engineering principles visible: **PASS**
- Technical proof linked: **PASS**
- Representative constraint example linked: **PASS**
- Testing behavior explained: **PASS**
- Real vs. synthetic labeling explicit: **PASS**
- Repository navigation provided: **PASS**
- Fake public runner avoided: **PASS**
- Internal factory floor not used as the front door: **PASS**

# HYDRA Recruiter Proof Strip V001

Standalone preview: `index.html`

Drop-in files:
- `proof-strip-component.html`
- `proof-strip.css`

Evidence payload:
- `proof-data.json`

Review:
- `W2_BUILD_REPORT.md`

The component intentionally preserves W1 evidence labels and does not claim live production execution.

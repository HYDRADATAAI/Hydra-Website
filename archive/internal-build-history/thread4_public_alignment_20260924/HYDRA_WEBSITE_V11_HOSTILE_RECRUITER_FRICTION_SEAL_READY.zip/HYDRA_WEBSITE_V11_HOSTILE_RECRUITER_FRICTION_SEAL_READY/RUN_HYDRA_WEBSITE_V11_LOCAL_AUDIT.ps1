﻿$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "HYDRA WEBSITE V11 - LOCAL RECRUITER EXPORT AUDIT" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

$Required = @(
  'index.html',
  'repository.html',
  'constraint-case-study-v2.html',
  'assets\\site.css',
  'repo\\README.md',
  'docs\\ARCHITECTURE.md',
  'docs\\EVIDENCE_INDEX.md',
  'docs\\REAL_VS_SYNTHETIC.md',
  'evidence\\CI_TEST_004_PUBLIC_EXCERPT.json',
  'evidence\\CI_TEST_006_PUBLIC_EXCERPT.txt',
  'evidence\\CI_TEST_008_PUBLIC_EXCERPT.json'
)
$Missing = @($Required | Where-Object { -not (Test-Path (Join-Path $Root $_)) })
if ($Missing.Count -gt 0) {
  $Missing | ForEach-Object { Write-Host "MISSING=$_" -ForegroundColor Red }
  throw 'Required export files are missing.'
}

$Index = Get-Content (Join-Path $Root 'index.html') -Raw
$Case  = Get-Content (Join-Path $Root 'constraint-case-study-v2.html') -Raw
$Readme = Get-Content (Join-Path $Root 'repo\\README.md') -Raw
$Css = Get-Content (Join-Path $Root 'assets\\site.css') -Raw

$Checks = [ordered]@{
  PUBLIC_REPO_BOUND = $Index.Contains('https://github.com/HYDRADATAAI/Hydra-Website')
  AUTHORITY_PRINCIPLE = $Index.Contains('Discoverable data is not automatically authorized data.')
  BLOCK_STATE_VISIBLE = $Case.Contains('VALID ENGINEERING OUTCOME: BLOCK')
  REPRESENTATIVE_LABEL = $Case.Contains('REPRESENTATIVE')
  SHADOW_LABEL = $Case.Contains('SHADOW')
  README_ROOT_DOC_LINKS = ($Readme.Contains('(docs/ARCHITECTURE.md)') -and -not $Readme.Contains('(../docs/ARCHITECTURE.md)'))
  MOBILE_NAV_NOT_HIDDEN = (-not $Css.Contains('.nav{display:none}'))
}

$Failed = @()
foreach ($Name in $Checks.Keys) {
  $Ok = [bool]$Checks[$Name]
  Write-Host ("CHECK::{0}={1}" -f $Name, $(if ($Ok) {'PASS'} else {'FAIL'})) -ForegroundColor $(if ($Ok) {'Green'} else {'Red'})
  if (-not $Ok) { $Failed += $Name }
}

if ($Failed.Count -gt 0) { throw ('Audit failed: ' + ($Failed -join ', ')) }
Write-Host 'OVERALL=PASS' -ForegroundColor Green
Start-Process (Join-Path $Root 'index.html')

#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re, subprocess, urllib.request, urllib.error, time
from pathlib import Path

TITLE="MARKET INTELLIGENCE DATA PLATFORM"
TAGLINE="Turn fragmented market data into traceable intelligence."

def read(path:Path):
    try:return path.read_text(encoding="utf-8",errors="ignore")
    except:return ""

def urlcheck(url,timeout=10):
    try:
        req=urllib.request.Request(url,method="GET",headers={"User-Agent":"HYDRA-W7-V005/1.0"})
        with urllib.request.urlopen(req,timeout=timeout) as r:
            body=r.read(2_000_000).decode("utf-8","ignore")
            flat=re.sub(r"<[^>]+>"," ",body)
            flat=re.sub(r"\s+"," ",flat)
            return {
                "reachable":200<=r.status<400,
                "status":r.status,
                "final_url":r.geturl(),
                "hydra_title":TITLE.lower() in flat.lower(),
                "hydra_tagline":TAGLINE.lower() in flat.lower(),
            }
    except urllib.error.HTTPError as e:
        return {"reachable":False,"status":e.code,"error":str(e)}
    except Exception as e:
        return {"reachable":False,"error":str(e)}

def gh_cli(site:Path):
    out={"installed":False,"authenticated":False,"remote":None,"pages_api":None}
    try:
        cp=subprocess.run(["gh","--version"],capture_output=True,text=True,timeout=5)
        out["installed"]=cp.returncode==0
    except:return out
    try:
        cp=subprocess.run(["gh","auth","status"],capture_output=True,text=True,timeout=8)
        out["authenticated"]=cp.returncode==0
        out["auth_text"]=(cp.stdout+"\n"+cp.stderr)[-4000:]
    except:pass
    return out

def git_remote(site:Path):
    for d in [site,site.parent]:
        try:
            cp=subprocess.run(["git","-C",str(d),"remote","get-url","origin"],capture_output=True,text=True,timeout=5)
            if cp.returncode==0 and cp.stdout.strip():
                return cp.stdout.strip()
        except:pass
    return None

def normalize_github(url):
    if not url:return None
    url=url.strip()
    m=re.match(r"git@github\.com:(.+?)(?:\.git)?$",url,re.I)
    if m:return "https://github.com/"+m.group(1).removesuffix(".git")
    m=re.match(r"https?://github\.com/([^/]+)/([^/#?]+)",url,re.I)
    if m:return f"https://github.com/{m.group(1)}/{m.group(2).removesuffix('.git')}"
    return None

def github_urls(site:Path):
    blob="\n".join(read(site/f) for f in ["index.html","app.js","site.config.js","README.md"] if (site/f).exists())
    urls=sorted(set(re.findall(r"https?://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+",blob,re.I)))
    return [u.rstrip(')"\\\'.,;') for u in urls]

def candidate_pages(repo_url):
    m=re.match(r"https?://github\.com/([^/]+)/([^/#?]+)",repo_url,re.I)
    if not m:return []
    owner=m.group(1);repo=m.group(2).removesuffix(".git")
    c=[]
    if repo.lower()==f"{owner.lower()}.github.io":
        c.append(f"https://{owner.lower()}.github.io/")
    c += [
        f"https://{owner.lower()}.github.io/{repo}/",
        f"https://{owner.lower()}.github.io/{repo.lower()}/",
    ]
    return list(dict.fromkeys(c))

def gh_pages_api(repo_url, gh):
    if not (gh.get("installed") and gh.get("authenticated")):return None
    m=re.match(r"https?://github\.com/([^/]+)/([^/#?]+)",repo_url,re.I)
    if not m:return None
    owner,repo=m.group(1),m.group(2).removesuffix(".git")
    try:
        cp=subprocess.run(["gh","api",f"repos/{owner}/{repo}/pages"],capture_output=True,text=True,timeout=10)
        if cp.returncode==0:
            return {"status":"CONFIGURED","response":json.loads(cp.stdout)}
        return {"status":"NOT_CONFIGURED_OR_INACCESSIBLE","stderr":cp.stderr.strip(),"exit_code":cp.returncode}
    except Exception as e:
        return {"status":"ERROR","error":repr(e)}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--site-root",default=r"D:\HYDRA_SITE\V7")
    ap.add_argument("--result-root",required=True)
    args=ap.parse_args()
    site=Path(args.site_root);result=Path(args.result_root);result.mkdir(parents=True,exist_ok=True)

    if not (site/"index.html").is_file():
        print("OVERALL=BLOCKED_SITE_ROOT_MISSING")
        return 3

    urls=github_urls(site)
    remote_raw=git_remote(site)
    remote=normalize_github(remote_raw)
    repo_candidates=[]
    if remote:repo_candidates.append(remote)
    repo_candidates += [normalize_github(u) for u in urls]
    repo_candidates=[u for u in dict.fromkeys(repo_candidates) if u]

    gh=gh_cli(site)
    repos=[]
    live_hydra=[]
    for repo in repo_candidates:
        page_checks=[]
        for u in candidate_pages(repo):
            chk=urlcheck(u)
            page_checks.append({"url":u,**chk})
            if chk.get("reachable") and chk.get("hydra_title") and chk.get("hydra_tagline"):
                live_hydra.append(u)
        pages=gh_pages_api(repo,gh)
        repos.append({"repo_url":repo,"candidate_pages":page_checks,"github_pages_api":pages})

    if live_hydra:
        overall="PASS_PUBLIC_DEPLOYMENT_PROVEN"
        deployment=live_hydra[0]
    elif repo_candidates:
        overall="BLOCKED_PUBLIC_DEPLOYMENT_NOT_CONFIGURED_OR_NOT_DISCOVERABLE"
        deployment=None
    else:
        overall="BLOCKED_GITHUB_REPOSITORY_NOT_PROVEN"
        deployment=None

    receipt={
        "test_id":"W7_V005_PUBLIC_DEPLOYMENT_PREFLIGHT",
        "timestamp":time.strftime("%Y-%m-%dT%H:%M:%S"),
        "site_root":str(site),
        "github_urls_found":urls,
        "git_origin_raw":remote_raw,
        "repo_candidates":repos,
        "gh_cli":gh,
        "public_hydra_urls":live_hydra,
        "deployment_url":deployment,
        "mutation":"NONE",
        "overall":overall,
    }
    (result/"W7_V005_PUBLIC_DEPLOYMENT_PREFLIGHT.json").write_text(json.dumps(receipt,indent=2),encoding="utf-8")
    lines=["# W7 V005 PUBLIC DEPLOYMENT PREFLIGHT","",f"`OVERALL={overall}`","",
           f"- SITE_ROOT: `{site}`",f"- GITHUB_URLS_FOUND: `{len(urls)}`",f"- GIT_ORIGIN: `{remote_raw or 'NONE'}`",
           f"- GH_CLI_INSTALLED: `{gh.get('installed')}`",f"- GH_AUTHENTICATED: `{gh.get('authenticated')}`",
           f"- PUBLIC_HYDRA_URL: `{deployment or 'NOT_PROVEN'}`","","## Repository candidates",""]
    for r in repos:
        lines.append(f"- `{r['repo_url']}`")
        for c in r["candidate_pages"]:
            lines.append(f"  - `{c['url']}` reachable={c.get('reachable')} hydra_title={c.get('hydra_title')} hydra_tagline={c.get('hydra_tagline')}")
        if r["github_pages_api"]:
            lines.append(f"  - Pages API: `{r['github_pages_api'].get('status')}`")
    (result/"W7_V005_PUBLIC_DEPLOYMENT_PREFLIGHT.md").write_text("\n".join(lines)+"\n",encoding="utf-8")

    print("="*68)
    print("HYDRA W7 V005 PUBLIC DEPLOYMENT PREFLIGHT")
    print("="*68)
    print(f"SITE_ROOT={site}")
    print(f"GITHUB_URL_COUNT={len(urls)}")
    for u in urls:print(f"GITHUB_URL={u}")
    print(f"GIT_ORIGIN={remote_raw or 'NONE'}")
    print(f"GH_CLI_INSTALLED={gh.get('installed')}")
    print(f"GH_AUTHENTICATED={gh.get('authenticated')}")
    for r in repos:
        print(f"REPO={r['repo_url']}")
        if r["github_pages_api"]:print(f"PAGES_API={r['github_pages_api'].get('status')}")
        for c in r["candidate_pages"]:
            print(f"PAGE_CANDIDATE={c['url']} reachable={c.get('reachable')} hydra_title={c.get('hydra_title')} hydra_tagline={c.get('hydra_tagline')}")
    print(f"PUBLIC_HYDRA_URL={deployment or 'NOT_PROVEN'}")
    print("MUTATION=NONE")
    print(f"OVERALL={overall}")
    return 0 if overall=="PASS_PUBLIC_DEPLOYMENT_PROVEN" else 2

if __name__=="__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
from __future__ import annotations
import argparse, base64, hashlib, http.server, json, os, re, shutil, socket, struct, subprocess, tempfile, threading, time, urllib.parse, urllib.request, urllib.error
from html.parser import HTMLParser
from pathlib import Path

APPROVED = {
    "title": "MARKET INTELLIGENCE DATA PLATFORM",
    "tagline": "Turn fragmented market data into traceable intelligence.",
    "badges": ["Multi-source ingestion","Contract-bound handoffs","Lineage + release gates"],
}
SKIP = {".git","node_modules","venv",".venv","__pycache__","TEST_RESULTS","WEBSITE_TEST_RESULTS",
        "artifacts","archive","archives","backups","backup","execution_runtime",
        "site-packages","portable_env","text-generation-webui","gradio"}
PLACEHOLDERS = {"", "#", "javascript:void(0)", "javascript:void(0);", "about:blank"}

class Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.text=[]; self.anchors=[]; self.ids=set(); self.imgs=[]; self.scripts=[]; self.links=[]; self.meta=[]
        self._a=None
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if a.get("id"): self.ids.add(a["id"])
        if tag=="a":
            self._a={"href":a.get("href",""),"text":"","target":a.get("target",""),"rel":a.get("rel","")}
            self.anchors.append(self._a)
        elif tag=="img": self.imgs.append(a)
        elif tag=="script": self.scripts.append(a)
        elif tag=="link": self.links.append(a)
        elif tag=="meta": self.meta.append(a)
    def handle_endtag(self,tag):
        if tag=="a": self._a=None
    def handle_data(self,data):
        s=" ".join(data.split())
        if s:
            self.text.append(s)
            if self._a is not None:
                self._a["text"] += (" " if self._a["text"] else "") + s

def parse(path):
    p=Parser(); txt=path.read_text(encoding="utf-8",errors="replace"); p.feed(txt); return p,txt

def is_forbidden(path):
    return any(part.lower() in {x.lower() for x in SKIP} for part in Path(path).parts)

def read_limited(path, limit=12_000_000):
    try:
        if path.stat().st_size > limit: return ""
        return path.read_text(encoding="utf-8",errors="ignore")
    except: return ""

def site_blob(index):
    if is_forbidden(index): return ""
    chunks=[read_limited(index)]
    raw=chunks[0]
    # Include directly referenced JS/CSS from built SPAs.
    for ref in re.findall(r"(?:src|href)=[\"']([^\"']+\.(?:js|css)(?:\?[^\"']*)?)[\"']", raw, flags=re.I)[:60]:
        if ref.startswith(("http://","https://","data:")): continue
        f=(index.parent/urllib.parse.unquote(ref.split("?",1)[0])).resolve()
        if f.is_file() and not is_forbidden(f): chunks.append(read_limited(f))
    # Vite/Svelte/React builds often keep recruiter copy in adjacent assets.
    for d in [index.parent/"assets", index.parent.parent/"assets"]:
        if d.is_dir() and not is_forbidden(d):
            for f in sorted(d.iterdir())[:100]:
                if f.is_file() and f.suffix.lower() in {".js",".css"}: chunks.append(read_limited(f))
    return "\n".join(chunks).lower()

def score(index):
    if is_forbidden(index): return -9999
    lo=site_blob(index)
    title=APPROVED["title"].lower() in lo
    tagline=APPROVED["tagline"].lower() in lo
    badges=sum(1 for b in APPROVED["badges"] if b.lower() in lo)
    proof=("technical proof" in lo or "inspect technical proof" in lo)
    # Hard identity requirement. Generic HYDRA/vendor pages are not eligible.
    eligible = tagline or (title and (badges >= 2 or proof))
    if not eligible: return -100
    s=(120 if tagline else 0)+(100 if title else 0)+(22*badges)+(25 if proof else 0)+(8 if "constraint" in lo else 0)
    p=str(index.parent).lower()
    if any(x in p for x in ("website","public_site","public-site","recruiter","portfolio")): s+=20
    if any(x in p for x in ("dist","build")): s+=5
    return s

def find_site(root):
    c=[]; seen=set(); count=0
    # Preferred website-ish roots first.
    for name in ["WEBSITE","website","HYDRA_WEBSITE","HYDRA WEBSITE","PUBLIC_SITE","public_site","RECRUITER_SITE","site","public","docs","frontend","web"]:
        d=root/name
        if d.is_dir() and not is_forbidden(d):
            for idx in list(d.rglob("index.html"))[:120]:
                if is_forbidden(idx): continue
                key=str(idx.resolve()).lower()
                if key in seen: continue
                seen.add(key); c.append((score(idx),idx.parent))
    # Controlled full fallback, excluding all vendor/runtime trees.
    for dp,dns,fns in os.walk(root):
        dns[:] = [d for d in dns if d.lower() not in {x.lower() for x in SKIP}]
        if "index.html" in fns:
            idx=Path(dp)/"index.html"
            if not is_forbidden(idx):
                key=str(idx.resolve()).lower()
                if key not in seen:
                    seen.add(key); c.append((score(idx),idx.parent))
        count += len(fns)
        if count>250000: break
    c.sort(key=lambda x:(x[0],-len(str(x[1]))),reverse=True)
    eligible=[x for x in c if x[0] >= 100]
    return (eligible[0][1] if eligible else None), [{"score":s,"path":str(p),"eligible":s>=100} for s,p in c[:25]]

def recover_v001_wrong_root(root,result):
    actions=[]
    wr=root/"WEBSITE_TEST_RESULTS"
    if not wr.is_dir(): return actions
    dirs=sorted([d for d in wr.glob("W7_V003_PUBLIC_SITE_RELEASE_SEAL_*") if d.is_dir()], key=lambda p:p.stat().st_mtime, reverse=True)
    for d in dirs[:8]:
        receipt=d/"PUBLIC_SITE_RELEASE_SEAL.json"
        if not receipt.exists(): continue
        try: r=json.loads(receipt.read_text(encoding="utf-8",errors="ignore"))
        except: continue
        old=Path(str(r.get("site_root", "")))
        if old and is_forbidden(old):
            backup=d/"BACKUP_BEFORE_SAFE_REPAIR"
            restored=[]
            if backup.is_dir():
                for f in backup.rglob("*"):
                    if not f.is_file(): continue
                    rel=f.relative_to(backup); dest=old/rel
                    try:
                        dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,dest); restored.append(str(dest))
                    except Exception as e: restored.append("RESTORE_FAILED::"+str(dest)+"::"+str(e))
            actions.append({"classification":"W7-AUDITOR-001_WRONG_SITE_ROOT_SELECTION","old_site_root":str(old),"receipt":str(receipt),"restored_files":restored})
            break
    return actions

def git_remote(site,hydra):
    for d in [site, site.parent, hydra]:
        try:
            cp=subprocess.run(["git","-C",str(d),"remote","get-url","origin"],capture_output=True,text=True,timeout=4)
            if cp.returncode==0 and cp.stdout.strip():
                u=cp.stdout.strip()
                m=re.match(r"git@github\.com:(.+?)(?:\.git)?$",u)
                if m: return "https://github.com/"+m.group(1).removesuffix(".git")
                if "github.com" in u: return u.removesuffix(".git")
        except: pass
    return None

def safe_repairs(site,result,remote):
    edits=[]
    for html in site.rglob("*.html"):
        try: original=html.read_text(encoding="utf-8")
        except: continue
        txt=original
        txt=re.sub(r'<a\b([^>]*\btarget=["\']_blank["\'][^>]*)>',
                   lambda m:'<a'+(m.group(1) if re.search(r'\brel=',m.group(1),re.I) else m.group(1)+' rel="noopener noreferrer"')+'>',
                   txt,flags=re.I)
        if remote:
            pat=r'(<a\b[^>]*\bhref=["\'])(#|)(["\'][^>]*>)([^<]*(?:GitHub|Repository)[^<]*)(</a>)'
            txt=re.sub(pat,lambda m:m.group(1)+remote+m.group(3)+m.group(4)+m.group(5),txt,flags=re.I)
        if txt!=original:
            rel=html.relative_to(site); b=result/"BACKUP_BEFORE_SAFE_REPAIR"/rel
            b.parent.mkdir(parents=True,exist_ok=True); b.write_text(original,encoding="utf-8")
            html.write_text(txt,encoding="utf-8"); edits.append(str(rel))
    return edits

def external(h): return h.startswith("http://") or h.startswith("https://")

def check_url(url,timeout=10):
    for method in ["HEAD","GET"]:
        try:
            req=urllib.request.Request(url,method=method,headers={"User-Agent":"HYDRA-W7/1.0"})
            with urllib.request.urlopen(req,timeout=timeout) as r:
                return {"status":"PASS" if 200<=r.status<400 else "FAIL","code":r.status,"final_url":r.geturl()}
        except urllib.error.HTTPError as e:
            if method=="GET": return {"status":"FAIL","code":e.code,"error":str(e)}
        except Exception as e:
            if method=="GET": return {"status":"BLOCKED_NETWORK","error":str(e)}
    return {"status":"BLOCKED_NETWORK"}

def _page_matches_hydra(url,timeout=10):
    try:
        req=urllib.request.Request(url,method="GET",headers={"User-Agent":"HYDRA-W7-V003/1.0"})
        with urllib.request.urlopen(req,timeout=timeout) as r:
            if not (200 <= r.status < 400): return False
            body=r.read(2_000_000).decode("utf-8","ignore")
            flat=re.sub(r"<[^>]+>"," ",body)
            flat=re.sub(r"\\s+"," ",flat).lower()
            return (APPROVED["title"].lower() in flat and APPROVED["tagline"].lower() in flat)
    except Exception:
        return False

def discover_public(site,p,github_urls=None):
    for l in p.links:
        if l.get("rel","").lower()=="canonical" and external(l.get("href","")): return l["href"],"DECLARED_CANONICAL"
    for m in p.meta:
        if m.get("property","").lower()=="og:url" and external(m.get("content","")): return m["content"],"DECLARED_OG_URL"
    c=site/"CNAME"
    if c.exists():
        host=c.read_text(errors="ignore").strip().splitlines()[0].strip()
        if host: return "https://"+host,"DECLARED_CNAME"
    j=site/"package.json"
    if j.exists():
        try:
            d=json.loads(j.read_text(encoding="utf-8")); h=str(d.get("homepage",""))
            if external(h): return h,"DECLARED_PACKAGE_HOMEPAGE"
        except: pass

    # Derive only from an already-public GitHub repository URL, then require the
    # candidate Pages URL to return HYDRA's exact public identity before accepting it.
    for gh in github_urls or []:
        m=re.match(r"https?://github\.com/([^/]+)/([^/#?]+)",gh,re.I)
        if not m: continue
        owner,repo=m.group(1),m.group(2).removesuffix(".git")
        candidates=[
            f"https://{owner.lower()}.github.io/{repo}/",
            f"https://{owner.lower()}.github.io/{repo.lower()}/",
        ]
        if repo.lower()==f"{owner.lower()}.github.io":
            candidates.insert(0,f"https://{owner.lower()}.github.io/")
        seen=set()
        for u in candidates:
            if u in seen: continue
            seen.add(u)
            if _page_matches_hydra(u):
                return u,"DERIVED_GITHUB_PAGES_VERIFIED"
    return None,"NOT_PROVEN"

def static_audit(site):
    out={"pages":[],"external_urls":[],"github_urls":[],"placeholder_links":[],"broken_internal_anchors":[],"missing_assets":[]}
    ex=set()
    for page in site.rglob("*.html"):
        p,txt=parse(page); rel=str(page.relative_to(site)); out["pages"].append(rel)
        for a in p.anchors:
            href=(a["href"] or "").strip()
            if href.lower() in PLACEHOLDERS: out["placeholder_links"].append({"page":rel,"href":href,"text":a["text"]})
            if href.startswith("#") and len(href)>1 and href[1:] not in p.ids:
                out["broken_internal_anchors"].append({"page":rel,"href":href,"text":a["text"]})
            if external(href):
                ex.add(href)
                if "github.com" in urllib.parse.urlparse(href).netloc.lower(): out["github_urls"].append(href)
            elif href and not href.startswith(("#","mailto:","tel:","javascript:")):
                d=href.split("#",1)[0].split("?",1)[0]
                path=(page.parent/urllib.parse.unquote(d)).resolve()
                if d.endswith("/"): path=path/"index.html"
                if not path.exists() and not Path(str(path)+".html").exists() and not (path/"index.html").exists():
                    out["missing_assets"].append({"page":rel,"href":href})
        for item,key in [(p.imgs,"src"),(p.scripts,"src")]:
            for a in item:
                src=(a.get(key) or "").strip()
                if src and not external(src) and not src.startswith("data:"):
                    path=(page.parent/urllib.parse.unquote(src.split("?",1)[0])).resolve()
                    if not path.exists(): out["missing_assets"].append({"page":rel,key:src})
        for l in p.links:
            h=(l.get("href") or "").strip()
            if h and not external(h) and not h.startswith("data:") and l.get("rel","").lower() in {"stylesheet","icon","shortcut icon","apple-touch-icon"}:
                path=(page.parent/urllib.parse.unquote(h.split("?",1)[0])).resolve()
                if not path.exists(): out["missing_assets"].append({"page":rel,"href":h})
    out["external_urls"]=sorted(ex)
    ip,itxt=parse(site/"index.html")
    low=site_blob(site/"index.html")
    rendered_text=" ".join(ip.text).lower()
    rendered_text=re.sub(r"\\s+"," ",rendered_text).strip()
    for u in sorted(set(re.findall(r"https?://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", low, flags=re.I))):
        if u not in out["github_urls"]: out["github_urls"].append(u)
    checks=[]
    def add(n,ok,d): checks.append({"check":n,"status":"PASS" if ok else "FAIL","detail":d})
    add("HERO_TITLE",APPROVED["title"].lower() in rendered_text,APPROVED["title"])
    add("TAGLINE",APPROVED["tagline"].lower() in rendered_text,APPROVED["tagline"])
    add("BADGE_MULTI_SOURCE_INGESTION",APPROVED["badges"][0].lower() in rendered_text,APPROVED["badges"][0])
    add("BADGE_CONTRACT_BOUND_HANDOFFS",APPROVED["badges"][1].lower() in rendered_text,APPROVED["badges"][1])
    add("BADGE_LINEAGE_RELEASE_GATES",APPROVED["badges"][2].lower() in rendered_text,APPROVED["badges"][2])
    proof=("technical proof" in rendered_text or any("proof" in a["text"].lower() for a in ip.anchors))
    add("PROOF_ENTRYPOINT",proof,"Technical Proof / proof navigation")
    add("GITHUB_LINK",len(out["github_urls"])>0,f"github links={len(out['github_urls'])}")
    add("PLACEHOLDER_LINKS",len(out["placeholder_links"])==0,f"count={len(out['placeholder_links'])}")
    add("BROKEN_INTERNAL_ANCHORS",len(out["broken_internal_anchors"])==0,f"count={len(out['broken_internal_anchors'])}")
    add("LOCAL_ASSETS",len(out["missing_assets"])==0,f"missing={len(out['missing_assets'])}")
    add("VIEWPORT_META",any(m.get("name","").lower()=="viewport" for m in ip.meta),"responsive viewport")
    return out,checks,ip

def find_browser():
    for n in ["msedge.exe","chrome.exe","chromium.exe","msedge","google-chrome","chromium","chromium-browser"]:
        p=shutil.which(n)
        if p:return p
    for p in [
        Path(os.environ.get("PROGRAMFILES(X86)",""))/"Microsoft/Edge/Application/msedge.exe",
        Path(os.environ.get("PROGRAMFILES",""))/"Microsoft/Edge/Application/msedge.exe",
        Path(os.environ.get("LOCALAPPDATA",""))/"Microsoft/Edge/Application/msedge.exe",
        Path(os.environ.get("PROGRAMFILES",""))/"Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("PROGRAMFILES(X86)",""))/"Google/Chrome/Application/chrome.exe"]:
        if str(p) and p.exists(): return str(p)
    return None

class WS:
    def __init__(self,url):
        u=urllib.parse.urlparse(url); self.sock=socket.create_connection((u.hostname,u.port),timeout=8); self.cid=0
        key=base64.b64encode(os.urandom(16)).decode(); path=u.path+("?" + u.query if u.query else "")
        req=(f"GET {path} HTTP/1.1\r\nHost: {u.hostname}:{u.port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
             f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n")
        self.sock.sendall(req.encode()); data=b""
        while b"\r\n\r\n" not in data: data+=self.sock.recv(4096)
        if b" 101 " not in data.split(b"\r\n",1)[0]: raise RuntimeError("websocket handshake failed")
    def _readn(self,n):
        d=b""
        while len(d)<n:
            x=self.sock.recv(n-len(d))
            if not x: raise EOFError
            d+=x
        return d
    def send(self,obj):
        raw=json.dumps(obj).encode(); mask=os.urandom(4); n=len(raw); h=bytearray([0x81])
        if n<126:h.append(0x80|n)
        elif n<65536:h.append(0x80|126);h.extend(struct.pack("!H",n))
        else:h.append(0x80|127);h.extend(struct.pack("!Q",n))
        h.extend(mask); payload=bytes(b^mask[i%4] for i,b in enumerate(raw)); self.sock.sendall(h+payload)
    def recv(self):
        b1,b2=self._readn(2); n=b2&0x7f
        if n==126:n=struct.unpack("!H",self._readn(2))[0]
        elif n==127:n=struct.unpack("!Q",self._readn(8))[0]
        if b2&0x80: mask=self._readn(4)
        else: mask=None
        p=self._readn(n)
        if mask:p=bytes(b^mask[i%4] for i,b in enumerate(p))
        if (b1&0xf)==8:raise EOFError
        return json.loads(p.decode("utf-8","replace"))
    def call(self,m,params=None,timeout=10):
        self.cid+=1; cid=self.cid; self.send({"id":cid,"method":m,"params":params or {}}); end=time.time()+timeout
        while time.time()<end:
            x=self.recv()
            if x.get("id")==cid:return x
        raise TimeoutError(m)
    def close(self):
        try:self.sock.close()
        except:pass

def browser_audit(site,result):
    browser=find_browser()
    if not browser:return {"status":"BLOCKED_BROWSER_NOT_FOUND","viewports":[]}
    handler=lambda *a,**k:http.server.SimpleHTTPRequestHandler(*a,directory=str(site),**k)
    srv=http.server.ThreadingHTTPServer(("127.0.0.1",0),handler); port=srv.server_address[1]
    threading.Thread(target=srv.serve_forever,daemon=True).start()
    profile=tempfile.mkdtemp(prefix="hydra_w7_"); proc=None; ws=None
    try:
        dbg=9333
        proc=subprocess.Popen([browser,"--headless=new",f"--remote-debugging-port={dbg}",f"--user-data-dir={profile}",
                               "--disable-gpu","--no-first-run","about:blank"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        meta=None
        for _ in range(40):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{dbg}/json",timeout=1) as r:
                    arr=json.load(r); pages=[x for x in arr if x.get("type")=="page" and x.get("webSocketDebuggerUrl")]
                    if pages:meta=pages[0];break
            except:time.sleep(.25)
        if not meta:return {"status":"BLOCKED_CDP_UNAVAILABLE","browser":browser,"viewports":[]}
        ws=WS(meta["webSocketDebuggerUrl"]); ws.call("Runtime.enable"); ws.call("Page.enable")
        hook="window.__HYDRA_W7_ERRORS__=[];window.addEventListener('error',e=>window.__HYDRA_W7_ERRORS__.push(String(e.message||e.error||'error')));window.addEventListener('unhandledrejection',e=>window.__HYDRA_W7_ERRORS__.push(String(e.reason||'unhandledrejection')));"
        ws.call("Page.addScriptToEvaluateOnNewDocument",{"source":hook})
        rows=[]
        for name,w,h,mobile in [("DESKTOP",1440,1000,False),("TABLET",1024,900,False),("MOBILE",390,844,True)]:
            ws.call("Emulation.setDeviceMetricsOverride",{"width":w,"height":h,"deviceScaleFactor":1,"mobile":mobile})
            ws.call("Page.navigate",{"url":f"http://127.0.0.1:{port}/index.html"});time.sleep(1.5)
            js="(()=>{const de=document.documentElement,b=document.body,txt=(b?.innerText||'').toLowerCase();const els=[...document.querySelectorAll('p,li,a,button,code')].filter(e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'&&(e.textContent||'').trim().length>8});const tiny=els.filter(e=>parseFloat(getComputedStyle(e).fontSize)<11).slice(0,20).map(e=>(e.textContent||'').trim().slice(0,80));const broken=[...document.images].filter(i=>!i.complete||i.naturalWidth===0).map(i=>i.currentSrc||i.src);const aa=[...document.querySelectorAll('a')].map(a=>({href:(a.getAttribute('href')||'').trim(),text:(a.innerText||'').trim()}));const placeholders=aa.filter(a=>['','#','javascript:void(0)','javascript:void(0);','about:blank'].includes(a.href.toLowerCase()));const gh=aa.filter(a=>a.href.toLowerCase().includes('github.com'));return {innerWidth:innerWidth,scrollWidth:Math.max(de.scrollWidth,b?b.scrollWidth:0),overflow:Math.max(de.scrollWidth,b?b.scrollWidth:0)>innerWidth+2,brokenImages:broken,tinyText:tiny,jsErrors:window.__HYDRA_W7_ERRORS__||[],bodyTextLength:(b?.innerText||'').trim().length,heroTitle:txt.includes('market intelligence data platform'),tagline:txt.includes('turn fragmented market data into traceable intelligence.'),badge1:txt.includes('multi-source ingestion'),badge2:txt.includes('contract-bound handoffs'),badge3:txt.includes('lineage + release gates'),proof:txt.includes('technical proof')||txt.includes('inspect technical proof'),placeholderLinks:placeholders,githubLinks:gh};})()"
            m=ws.call("Runtime.evaluate",{"expression":js,"returnByValue":True}); val=m.get("result",{}).get("result",{}).get("value",{})
            cap=ws.call("Page.captureScreenshot",{"format":"png","captureBeyondViewport":False}); data=cap.get("result",{}).get("data")
            if data:(result/f"{name.lower()}_render.png").write_bytes(base64.b64decode(data))
            status="PASS"
            if (val.get("overflow") or val.get("brokenImages") or val.get("tinyText") or val.get("jsErrors") or val.get("bodyTextLength",0)<100
                or not val.get("heroTitle") or not val.get("tagline") or not val.get("badge1") or not val.get("badge2") or not val.get("badge3")
                or not val.get("proof") or val.get("placeholderLinks") or not val.get("githubLinks")): status="FAIL"
            rows.append({"viewport":name,"width":w,"height":h,"status":status,**val})
        return {"status":"PASS" if all(x["status"]=="PASS" for x in rows) else "FAIL","browser":browser,"viewports":rows}
    except Exception as e:return {"status":"BLOCKED_BROWSER_EXCEPTION","browser":browser,"error":repr(e),"viewports":[]}
    finally:
        if ws:ws.close()
        if proc:
            try:proc.terminate()
            except:pass
        srv.shutdown();shutil.rmtree(profile,ignore_errors=True)

def main():
    a=argparse.ArgumentParser();a.add_argument("--hydra-root",default=r"D:\HYDRA");a.add_argument("--site-root");a.add_argument("--result-root",required=True);a.add_argument("--repair-safe",action="store_true")
    args=a.parse_args();hydra=Path(args.hydra_root);result=Path(args.result_root);result.mkdir(parents=True,exist_ok=True)
    recovery=recover_v001_wrong_root(hydra,result)
    site=Path(args.site_root) if args.site_root else None;candidates=[]
    if site and is_forbidden(site):
        site=None
    if not site:site,candidates=find_site(hydra)
    report={"test_id":"W7_V003_PUBLIC_SITE_RELEASE_SEAL_V002","timestamp":time.strftime("%Y-%m-%dT%H:%M:%S"),"hydra_root":str(hydra),"site_root":str(site) if site else None,"site_candidates":candidates,
            "defect_repaired":"W7-AUDITOR-001_WRONG_SITE_ROOT_SELECTION","v001_containment_recovery":recovery}
    if not site or not (site/"index.html").exists():
        report["overall"]="BLOCKED_CORRECT_SITE_ROOT_NOT_PROVEN";(result/"PUBLIC_SITE_RELEASE_SEAL.json").write_text(json.dumps(report,indent=2));print("DEFECT=W7-AUDITOR-001_WRONG_SITE_ROOT_SELECTION");print("OVERALL=BLOCKED_CORRECT_SITE_ROOT_NOT_PROVEN");return 3
    remote=git_remote(site,hydra);report["github_remote_discovered"]=remote
    report["safe_repairs"]=safe_repairs(site,result,remote) if args.repair_safe else []
    static,checks,ip=static_audit(site);report["static"]=static;report["checks"]=checks
    public,public_method=discover_public(site,ip,static.get("github_urls",[]));report["public_deployment_url"]=public;report["public_deployment_method"]=public_method;report["public_deployment_check"]=check_url(public) if public else {"status":"BLOCKED_NOT_DECLARED"}
    ext={u:check_url(u) for u in static["external_urls"]};report["external_link_checks"]=ext
    report["browser"]=browser_audit(site,result)
    hard=[c for c in checks if c["status"]=="FAIL"];ef=[u for u,v in ext.items() if v.get("status")=="FAIL"];eb=[u for u,v in ext.items() if v.get("status","").startswith("BLOCKED")]
    dep=report["public_deployment_check"]["status"];bs=report["browser"]["status"]
    if hard or ef or dep=="FAIL" or bs=="FAIL":overall="FAIL_WITH_DEFECT"
    elif dep!="PASS":overall="BLOCKED_PUBLIC_DEPLOYMENT_NOT_PROVEN"
    elif bs!="PASS":overall="BLOCKED_BROWSER_RENDER_NOT_PROVEN"
    elif eb:overall="BLOCKED_EXTERNAL_LINK_REACHABILITY_NOT_PROVEN"
    else:overall="PASS_PUBLIC_SITE_RELEASE_SEAL"
    report["overall"]=overall;report["summary"]={"hard_failure_count":len(hard),"external_failure_count":len(ef),"external_blocked_count":len(eb),"safe_repair_count":len(report["safe_repairs"]),"unsupported_claims_added":0}
    (result/"PUBLIC_SITE_RELEASE_SEAL.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    lines=["# PUBLIC_SITE_RELEASE_SEAL","",f"`OVERALL={overall}`","",f"- SITE_ROOT: `{site}`",f"- PUBLIC_DEPLOYMENT: `{dep}` "+(f"`{public}`" if public else ""),f"- BROWSER_RENDER: `{bs}`",f"- STATIC_HARD_FAILURES: `{len(hard)}`",f"- EXTERNAL_LINK_FAILURES: `{len(ef)}`",f"- EXTERNAL_LINK_BLOCKED: `{len(eb)}`",f"- SAFE_REPAIRS_APPLIED: `{len(report['safe_repairs'])}`","","## Static checks",""]
    lines += [f"- `{c['check']}={c['status']}` — {c['detail']}" for c in checks]
    lines += ["","## Browser viewports",""]
    lines += [f"- `{v['viewport']}={v['status']}` overflow={v.get('overflow')} broken_images={len(v.get('brokenImages',[]))} js_errors={len(v.get('jsErrors',[]))} tiny_text={len(v.get('tinyText',[]))}" for v in report["browser"].get("viewports",[])]
    lines += ["","## Release rule","","Seal only when static checks, public deployment, external links, and desktop/tablet/mobile render probes are proven green. Blockers remain blockers."]
    (result/"PUBLIC_SITE_RELEASE_SEAL.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    (result/"W7_CONSOLE_SUMMARY.txt").write_text(f"OVERALL={overall}\nSITE_ROOT={site}\nPUBLIC_DEPLOYMENT={dep}\nBROWSER_RENDER={bs}\nHARD_FAILURES={len(hard)}\nEXTERNAL_FAILURES={len(ef)}\nEXTERNAL_BLOCKED={len(eb)}\n",encoding="utf-8")
    print("="*68);print("HYDRA W7 V003 DOM-TRUTH + DEPLOYMENT RELEASE SEAL");print("="*68);print("V001_DEFECT=W7-AUDITOR-001_WRONG_SITE_ROOT_SELECTION");print(f"V001_CONTAINMENT_RECOVERY_ACTIONS={len(recovery)}");print(f"SITE_ROOT={site}");print(f"GITHUB_REMOTE={remote or 'NOT_DISCOVERED'}");print(f"PUBLIC_DEPLOYMENT_URL={public or 'NOT_DECLARED'}")
    for c in checks:print(f"{c['check']}={c['status']} :: {c['detail']}")
    print(f"BROWSER_RENDER={bs}")
    for v in report["browser"].get("viewports",[]):
        print(f"{v['viewport']}={v['status']} overflow={v.get('overflow')} broken_images={len(v.get('brokenImages',[]))} js_errors={len(v.get('jsErrors',[]))} tiny_text={len(v.get('tinyText',[]))} body_text={v.get('bodyTextLength')} hero={v.get('heroTitle')} tagline={v.get('tagline')} badge1={v.get('badge1')} badge2={v.get('badge2')} badge3={v.get('badge3')} proof={v.get('proof')} placeholders={len(v.get('placeholderLinks',[]))} github_links={len(v.get('githubLinks',[]))}")
        if v.get("tinyText"):
            print("TINY_TEXT_DETAIL::"+v["viewport"]+"::"+" | ".join(v.get("tinyText",[])))
    print(f"OVERALL={overall}")
    return 0 if overall=="PASS_PUBLIC_SITE_RELEASE_SEAL" else 2
if __name__=="__main__":raise SystemExit(main())

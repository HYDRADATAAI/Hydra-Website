
(() => {
  const buttons = [...document.querySelectorAll('.filter')];
  const cards = [...document.querySelectorAll('.card[data-category]')];
  const search = document.getElementById('proofSearch');
  let active = 'all';
  function apply(){
    const q = (search?.value || '').trim().toLowerCase();
    for(const card of cards){
      const categoryOk = active === 'all' || card.dataset.category === active;
      const searchOk = !q || (card.dataset.search || '').includes(q);
      card.classList.toggle('hidden', !(categoryOk && searchOk));
    }
  }
  buttons.forEach(btn => btn.addEventListener('click', () => {
    buttons.forEach(x => x.classList.remove('active'));
    btn.classList.add('active');
    active = btn.dataset.filter;
    apply();
  }));
  search?.addEventListener('input', apply);
})();

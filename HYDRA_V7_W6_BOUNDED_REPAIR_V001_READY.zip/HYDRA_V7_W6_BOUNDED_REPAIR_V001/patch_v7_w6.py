#!/usr/bin/env python3
from pathlib import Path
import argparse, re, shutil, json, hashlib, datetime, sys
from html import unescape

BADGES = {
    "MULTI-SOURCE INGESTION": "Multi-source ingestion",
    "CONTRACT-BOUND HANDOFFS": "Contract-bound handoffs",
    "LINEAGE + RELEASE GATES": "Lineage + release gates",
}
ANCHOR = re.compile(r'(?is)<a\b(?P<attrs>[^>]*)>(?P<body>.*?)</a>')
PENDING = re.compile(r'(?is)<span\b(?P<attrs>[^>]*data-github-pending=["\']true["\'][^>]*)>(?P<body>.*?)</span>')
HREF = re.compile(r'(?is)\s+href\s*=\s*(["\']).*?\1')
TARGET = re.compile(r'(?is)\s+target\s*=\s*(["\']).*?\1')
REL = re.compile(r'(?is)\s+rel\s*=\s*(["\']).*?\1')
TAG = re.compile(r'(?is)<[^>]+>')

def visible(s): return " ".join(unescape(TAG.sub(" ", s)).split())
def set_href(attrs, url): return HREF.sub("", attrs).rstrip() + f' href="{url}"'
def strip_action(attrs): return REL.sub("", TARGET.sub("", HREF.sub("", attrs))).rstrip()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def patch_anchor(m, github, page):
    attrs, body = m.group("attrs"), m.group("body")
    txt = visible(body).lower()
    hrefm = re.search(r'(?is)\bhref\s*=\s*(["\'])(.*?)\1', attrs)
    href = hrefm.group(2).strip() if hrefm else None

    if page == "index.html" and href == "#" and "open repository" in txt:
        return f'<a{set_href(attrs, "proof.html")}>Inspect technical proof ↗</a>'

    if href == "#" and "repository" in txt:
        if github:
            a = set_href(attrs, github)
            if "target=" not in a.lower(): a += ' target="_blank"'
            if "rel=" not in a.lower(): a += ' rel="noopener noreferrer"'
            return f'<a{a}>{body}</a>'
        return f'<span{strip_action(attrs)} data-github-pending="true" aria-disabled="true">{body}</span>'

    if href == "#" and (txt.startswith("linkedin") or txt.startswith("contact")):
        return f'<span{strip_action(attrs)} data-action-pending="true" aria-disabled="true">{body}</span>'

    return m.group(0)

def bind_pending(m, github):
    if not github: return m.group(0)
    attrs, body = m.group("attrs"), m.group("body")
    attrs = re.sub(r'(?is)\s+data-github-pending\s*=\s*(["\'])true\1', "", attrs)
    attrs = re.sub(r'(?is)\s+aria-disabled\s*=\s*(["\'])true\1', "", attrs)
    attrs = set_href(attrs, github)
    if "target=" not in attrs.lower(): attrs += ' target="_blank"'
    if "rel=" not in attrs.lower(): attrs += ' rel="noopener noreferrer"'
    return f'<a{attrs}>{body}</a>'

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--site-root", required=True)
    ap.add_argument("--github-url", default="")
    args = ap.parse_args()
    root = Path(args.site_root).resolve()
    github = args.github_url.strip()

    if not (root / "index.html").exists():
        print("ERROR: index.html not found", file=sys.stderr); return 2
    if github and not re.match(r'^https://github\.com/[^/\s]+/[^/\s#?]+/?$', github, re.I):
        print("ERROR: invalid GitHub repository URL", file=sys.stderr); return 3

    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = root.parent / "_BACKUPS" / f"V7_W6_REPAIR_{stamp}"
    reportdir = root.parent / "_TEST_RESULTS" / f"V7_W6_REPAIR_{stamp}"
    reportdir.mkdir(parents=True, exist_ok=True)

    modified = []
    counts = {"badge_replacements":0, "proof_cta":0, "repo_pending":0,
              "repo_bound":0, "actions_deactivated":0, "pending_bound":0}

    for p in sorted(root.rglob("*.html")):
        old = p.read_text(encoding="utf-8", errors="replace")
        txt = old
        if p.name.lower() == "index.html":
            for a,b in BADGES.items():
                n = txt.count(a); txt = txt.replace(a,b); counts["badge_replacements"] += n

        anchors = list(ANCHOR.finditer(txt))
        for m in anchors:
            body = visible(m.group("body")).lower()
            hm = re.search(r'(?is)\bhref\s*=\s*(["\'])(.*?)\1', m.group("attrs"))
            href = hm.group(2).strip() if hm else None
            if p.name.lower()=="index.html" and href=="#" and "open repository" in body: counts["proof_cta"] += 1
            elif href=="#" and "repository" in body:
                counts["repo_bound" if github else "repo_pending"] += 1
            elif href=="#" and (body.startswith("linkedin") or body.startswith("contact")):
                counts["actions_deactivated"] += 1

        txt = ANCHOR.sub(lambda m: patch_anchor(m, github, p.name.lower()), txt)
        if github:
            before = len(PENDING.findall(txt))
            txt = PENDING.sub(lambda m: bind_pending(m, github), txt)
            counts["pending_bound"] += before

        if txt != old:
            rel = p.relative_to(root)
            bp = backup / rel
            bp.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, bp)
            p.write_text(txt, encoding="utf-8")
            modified.append({"file":str(rel).replace("\\","/"), "before_sha256":hashlib.sha256(old.encode()).hexdigest(), "after_sha256":sha(p)})

    idx = (root/"index.html").read_text(encoding="utf-8", errors="replace")
    verify = {
        "badges_exact": all(v in idx for v in BADGES.values()),
        "proof_cta_present": "Inspect technical proof" in idx and 'href="proof.html"' in idx,
        "github_authority_supplied": bool(github),
        "github_bound": bool(github) and any(github in p.read_text(encoding="utf-8", errors="replace") for p in root.rglob("*.html")),
    }
    status = "REPAIR_COMPLETE_GITHUB_BOUND" if github else "REPAIR_COMPLETE_GITHUB_AUTHORITY_PENDING"
    report = {"artifact":"HYDRA_V7_W6_BOUNDED_REPAIR_V001","status":status,"site_root":str(root),
              "github_url":github or None,"backup_root":str(backup),"modified_files":modified,
              "counts":counts,"verification":verify,"next":"RERUN_W6_W7_STATIC_PREFLIGHT"}
    (reportdir/"V7_W6_BOUNDED_REPAIR_REPORT.json").write_text(json.dumps(report,indent=2),encoding="utf-8")

    print(f"STATUS={status}")
    print(f"MODIFIED_FILES={len(modified)}")
    for k,v in counts.items(): print(f"{k.upper()}={v}")
    print(f"BACKUP_ROOT={backup}")
    print(f"REPORT_ROOT={reportdir}")
    print("NEXT=RERUN_W6_W7_STATIC_PREFLIGHT")
    if not github:
        print("GITHUB_URL_REQUIRED=YES")
        return 12
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

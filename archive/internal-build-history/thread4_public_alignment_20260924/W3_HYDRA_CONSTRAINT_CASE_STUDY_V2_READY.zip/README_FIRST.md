# HYDRA CONSTRAINT CASE STUDY V2

## Story

`FRAGMENTED MARKET EVIDENCE`
→ `SOURCE NORMALIZATION`
→ `IDENTITY + AUTHORITY`
→ `CONSTRAINT INTERPRETATION`
→ `AUDITABLE RESULT`

## What is real

- Public-safe ES options-chain and VX one-minute source-format samples.
- CI-TEST-004 integrated T1→T5 receipt excerpts.
- CI-TEST-005 behavioral trace receipt excerpts.
- CI-008 V011/V012 blocked authority outcomes.

## What is representative

- The normalized internal-record example.
- The admissible constraint-output example.
- The explanatory constraint interpretation shape.

These are explicitly labeled `REPRESENTATIVE`.

## Critical engineering point

**Discoverable data is not automatically authorized data.**

CI-008 identified native fields required for a downstream T6 handoff, but the exact authoritative case source could not be established. The test therefore remained blocked and preserved:

`semantic_values_invented=false`

That is a valid governed outcome.

## Integration files

- `HYDRA_CONSTRAINT_CASE_STUDY_V2.html`
- `constraint-case-study.fragment.html`
- `constraint-case-study.css`
- `CASE_STUDY_CLAIM_EVIDENCE_MAP.json`
- `evidence/`
- `W3_ACCEPTANCE_RECEIPT.json`
- `W3_STATIC_VALIDATION.json`
- `SHA256SUMS.json`

## Truth boundary

This packet does not claim live production ingestion, live production constraint classification, that displayed source rows were the exact CI-008 case, N1 38/38 execution proof, Baby ML or Serious ML training, or canonical promotion.

# HYDRA Technical Proof Index V001

Standalone preview:
- `index.html`

Drop-in website files:
- `proof-index-component.html`
- `proof-index.css`
- `proof-index.js`

Structured data:
- `proof-index-data.json`

Review:
- `W5_BUILD_REPORT.md`
- `W5_VALIDATION.md`

The index exposes only W1-approved public-safe evidence.

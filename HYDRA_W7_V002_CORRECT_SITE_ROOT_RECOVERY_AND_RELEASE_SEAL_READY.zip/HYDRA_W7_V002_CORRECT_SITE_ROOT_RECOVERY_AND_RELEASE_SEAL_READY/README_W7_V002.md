# HYDRA W7 V002 — Correct Site Root Recovery + Release Seal

## Proven V001 defect

`W7-AUDITOR-001_WRONG_SITE_ROOT_SELECTION`

V001 selected Gradio's vendor frontend under `text-generation-webui\portable_env\Lib\site-packages`. Its hero/link/JS failures are not HYDRA website evidence.

V002 refuses vendor/runtime roots, proves the HYDRA recruiter identity from the built site's HTML/JS/CSS assets, restores any V001 backup created against the wrong vendor root, and then reruns the full W7 seal.

It remains fail-closed. If the correct site or public deployment cannot be proven, it returns BLOCKED rather than a fake PASS.

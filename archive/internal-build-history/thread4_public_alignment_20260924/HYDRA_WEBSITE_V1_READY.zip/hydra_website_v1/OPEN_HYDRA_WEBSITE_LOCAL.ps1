$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Index = Join-Path $Here 'index.html'
if (-not (Test-Path -LiteralPath $Index)) {
    throw "index.html not found beside this launcher: $Index"
}
Write-Host 'Opening HYDRA Website V1...' -ForegroundColor Cyan
Start-Process $Index

param()
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$RepoSlug = 'HYDRADATAAI/Hydra-Website'
$Branch = 'main'
$PagesBase = 'https://hydradataai.github.io/Hydra-Website/'
$ManifestPath = Join-Path $PSScriptRoot 'DEPLOYMENT_MANIFEST_V12.json'
$Downloads = Join-Path $HOME 'Downloads'
$Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$RunRoot = "D:\HYDRA_WEBSITE_DEPLOY\V14_$Stamp"
$EvidenceRoot = Join-Path $RunRoot 'evidence'
$ReturnRoot = Join-Path $RunRoot 'return'
$ReturnZip = Join-Path $Downloads "HYDRA_V14_FINAL_PUBLIC_RELEASE_SEAL_RETURN_$Stamp.zip"
New-Item -ItemType Directory -Path $EvidenceRoot,$ReturnRoot -Force | Out-Null

$result = [ordered]@{
  schema = 'HYDRA_V14_FINAL_PUBLIC_RELEASE_SEAL_V001'
  run_timestamp = (Get-Date).ToString('o')
  mode = 'READ_ONLY_PUBLIC_VERIFICATION'
  target_repository = $RepoSlug
  target_branch = $Branch
  pages_base = $PagesBase
  v13_return_zip = $null
  v13_return_zip_sha256 = $null
  v13_overall = $null
  v13_repo_sync = $null
  v13_postdeploy_remote_sha = $null
  public_main_sha = $null
  public_commit_matches_v13 = $false
  manifest_file_count = 0
  public_repo_files_verified = 0
  public_repo_hash_mismatches = @()
  public_repo_missing_files = @()
  pages_checks = @()
  required_markers = [ordered]@{
    recruiter_hero = $false
    representative_label = $false
    synthetic_shadow_label = $false
    authority_principle = $false
    blocked_state = $false
    public_claim_boundary = $false
  }
  unsupported_live_production_claim_found = $false
  repo_exact_v12 = $false
  pages_all_required_routes = $false
  overall = 'RUNNING'
  next_action = $null
  failure_phase = $null
  failure_message = $null
}

function Write-Utf8([string]$Path,[string]$Text){ $Text | Set-Content -LiteralPath $Path -Encoding UTF8 }
function Sha256-Bytes([byte[]]$Bytes){
  $sha = [System.Security.Cryptography.SHA256]::Create()
  try { return (($sha.ComputeHash($Bytes) | ForEach-Object { $_.ToString('x2') }) -join '') }
  finally { $sha.Dispose() }
}
function Get-ApiJson([string]$Uri,[string]$Label){
  $headers = @{ 'User-Agent'='HYDRA-V14-Public-Release-Verifier'; 'Accept'='application/vnd.github+json' }
  try {
    $r = Invoke-RestMethod -Uri $Uri -Headers $headers -Method Get -TimeoutSec 30
    Write-Utf8 (Join-Path $EvidenceRoot ("api_{0}.json" -f $Label)) ($r | ConvertTo-Json -Depth 20)
    return $r
  } catch {
    Write-Utf8 (Join-Path $EvidenceRoot ("api_{0}_error.txt" -f $Label)) $_.Exception.Message
    throw
  }
}
function Get-Web([string]$Uri,[string]$Label){
  try {
    $r = Invoke-WebRequest -Uri $Uri -UseBasicParsing -MaximumRedirection 5 -TimeoutSec 30
    Write-Utf8 (Join-Path $EvidenceRoot ("web_{0}_status.txt" -f $Label)) ("URL=$Uri`r`nSTATUS=$([int]$r.StatusCode)`r`nLENGTH=$(([string]$r.Content).Length)")
    return $r
  } catch {
    $status = $null
    try { $status = [int]$_.Exception.Response.StatusCode.value__ } catch {}
    Write-Utf8 (Join-Path $EvidenceRoot ("web_{0}_error.txt" -f $Label)) ("URL=$Uri`r`nSTATUS=$status`r`nERROR=$($_.Exception.Message)")
    return $null
  }
}
function Write-ReturnPacket {
  $result.run_completed_at = (Get-Date).ToString('o')
  Write-Utf8 (Join-Path $ReturnRoot 'V14_FINAL_PUBLIC_RELEASE_SEAL.json') ($result | ConvertTo-Json -Depth 20)
  $summary = @"
HYDRA V14 FINAL PUBLIC RELEASE SEAL
OVERALL=$($result.overall)
MODE=$($result.mode)
TARGET_REPOSITORY=$($result.target_repository)
TARGET_BRANCH=$($result.target_branch)
V13_OVERALL=$($result.v13_overall)
V13_REPO_SYNC=$($result.v13_repo_sync)
V13_REMOTE_SHA=$($result.v13_postdeploy_remote_sha)
PUBLIC_MAIN_SHA=$($result.public_main_sha)
PUBLIC_COMMIT_MATCHES_V13=$($result.public_commit_matches_v13)
MANIFEST_FILE_COUNT=$($result.manifest_file_count)
PUBLIC_REPO_FILES_VERIFIED=$($result.public_repo_files_verified)
PUBLIC_REPO_HASH_MISMATCH_COUNT=$(@($result.public_repo_hash_mismatches).Count)
PUBLIC_REPO_MISSING_FILE_COUNT=$(@($result.public_repo_missing_files).Count)
REPO_EXACT_V12=$($result.repo_exact_v12)
PAGES_ALL_REQUIRED_ROUTES=$($result.pages_all_required_routes)
RECRUITER_HERO_MARKER=$($result.required_markers.recruiter_hero)
REPRESENTATIVE_LABEL=$($result.required_markers.representative_label)
SYNTHETIC_SHADOW_LABEL=$($result.required_markers.synthetic_shadow_label)
AUTHORITY_PRINCIPLE=$($result.required_markers.authority_principle)
BLOCKED_STATE=$($result.required_markers.blocked_state)
PUBLIC_CLAIM_BOUNDARY=$($result.required_markers.public_claim_boundary)
UNSUPPORTED_LIVE_PRODUCTION_CLAIM_FOUND=$($result.unsupported_live_production_claim_found)
FAILURE_PHASE=$($result.failure_phase)
FAILURE_MESSAGE=$($result.failure_message)
NEXT_ACTION=$($result.next_action)
"@
  Write-Utf8 (Join-Path $ReturnRoot 'V14_FINAL_PUBLIC_RELEASE_SEAL.txt') $summary
  if(Test-Path $EvidenceRoot){ Copy-Item -LiteralPath $EvidenceRoot -Destination (Join-Path $ReturnRoot 'evidence') -Recurse -Force }
  if(Test-Path $ReturnZip){ Remove-Item -LiteralPath $ReturnZip -Force }
  Compress-Archive -Path (Join-Path $ReturnRoot '*') -DestinationPath $ReturnZip -CompressionLevel Optimal -Force
  $h=(Get-FileHash -LiteralPath $ReturnZip -Algorithm SHA256).Hash.ToLowerInvariant()
  Write-Host "RETURN_ZIP=$ReturnZip"
  Write-Host "RETURN_ZIP_SHA256=$h"
}

Write-Host '============================================================'
Write-Host 'HYDRA V14 - FINAL PUBLIC RELEASE VERIFICATION + SEAL'
Write-Host '============================================================'
Write-Host 'MODE=READ_ONLY'
Write-Host "REPOSITORY=$RepoSlug"
Write-Host "BRANCH=$Branch"
Write-Host "PAGES=$PagesBase"
Write-Host 'REPOSITORY_MUTATION=NONE'
Write-Host 'GITHUB_PAGES_SETTINGS_MUTATION=NONE'
Write-Host 'FINAL_SEAL_REQUIRES=V13_PASS + EXACT_PUBLIC_HASHES + LIVE_PAGES_ROUTES + CLAIM_BOUNDARY_MARKERS'
Write-Host '============================================================'

try {
  $result.failure_phase = 'V13_RECEIPT_DISCOVERY'
  $v13Zip = Get-ChildItem -LiteralPath $Downloads -Filter 'HYDRA_V13_PUBLIC_GITHUB_DEPLOYMENT_RETURN_*.zip' -File -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if(-not $v13Zip){ throw 'No HYDRA_V13_PUBLIC_GITHUB_DEPLOYMENT_RETURN_*.zip found in Downloads. Run V13 first.' }
  $result.v13_return_zip = $v13Zip.FullName
  $result.v13_return_zip_sha256 = (Get-FileHash -LiteralPath $v13Zip.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
  $v13Extract = Join-Path $RunRoot 'v13_return'
  Expand-Archive -LiteralPath $v13Zip.FullName -DestinationPath $v13Extract -Force
  $receiptPath = Get-ChildItem -LiteralPath $v13Extract -Filter 'V13_PUBLIC_GITHUB_DEPLOYMENT_RECEIPT.json' -File -Recurse | Select-Object -First 1
  if(-not $receiptPath){ throw 'V13 receipt JSON missing from return ZIP.' }
  $v13 = Get-Content -LiteralPath $receiptPath.FullName -Raw | ConvertFrom-Json
  Copy-Item -LiteralPath $receiptPath.FullName -Destination (Join-Path $EvidenceRoot 'V13_PUBLIC_GITHUB_DEPLOYMENT_RECEIPT.json') -Force
  $result.v13_overall = [string]$v13.overall
  $result.v13_repo_sync = [string]$v13.repo_sync
  $result.v13_postdeploy_remote_sha = [string]$v13.postdeploy_remote_sha
  if($result.v13_overall -eq 'BLOCKED'){ throw "V13 is BLOCKED: $($v13.failure_message)" }
  if($result.v13_repo_sync -notin @('PUSH_SUCCEEDED','ALREADY_MATCHED_NO_COMMIT_REQUIRED')){ throw "V13 repo sync is not proven: $($result.v13_repo_sync)" }
  if([string]::IsNullOrWhiteSpace($result.v13_postdeploy_remote_sha)){ throw 'V13 did not record a postdeploy remote SHA.' }

  $result.failure_phase = 'MANIFEST_VERIFY'
  if(-not (Test-Path -LiteralPath $ManifestPath)){ throw 'Embedded V12 deployment manifest missing.' }
  $manifest = Get-Content -LiteralPath $ManifestPath -Raw | ConvertFrom-Json
  if($manifest.target_repository -ne $RepoSlug -or $manifest.target_branch -ne $Branch){ throw 'Embedded V12 manifest target mismatch.' }
  $result.manifest_file_count = @($manifest.files).Count

  $result.failure_phase = 'PUBLIC_COMMIT_VERIFY'
  $commit = Get-ApiJson "https://api.github.com/repos/$RepoSlug/commits/$Branch" 'main_commit'
  $result.public_main_sha = [string]$commit.sha
  $result.public_commit_matches_v13 = ($result.public_main_sha -eq $result.v13_postdeploy_remote_sha)
  if(-not $result.public_commit_matches_v13){ throw "Public main SHA does not match V13 postdeploy SHA. public=$($result.public_main_sha) v13=$($result.v13_postdeploy_remote_sha)" }

  $result.failure_phase = 'PUBLIC_FILE_HASH_VERIFY'
  foreach($entry in $manifest.files){
    $path = [string]$entry.path
    $escaped = (($path -split '/') | ForEach-Object { [Uri]::EscapeDataString($_) }) -join '/'
    try {
      $obj = Get-ApiJson "https://api.github.com/repos/$RepoSlug/contents/$escaped?ref=$Branch" ("file_" + ($path -replace '[^A-Za-z0-9]+','_'))
      if([string]$obj.type -ne 'file'){ throw "Not a file: $path" }
      $b64 = ([string]$obj.content) -replace '\s',''
      $bytes = [Convert]::FromBase64String($b64)
      $sha = Sha256-Bytes $bytes
      if($sha -ne ([string]$entry.sha256).ToLowerInvariant()){
        $result.public_repo_hash_mismatches += [ordered]@{ path=$path; expected=[string]$entry.sha256; actual=$sha }
      } else {
        $result.public_repo_files_verified++
      }
    } catch {
      $result.public_repo_missing_files += [ordered]@{ path=$path; error=$_.Exception.Message }
    }
  }
  $result.repo_exact_v12 = ($result.public_repo_files_verified -eq $result.manifest_file_count -and @($result.public_repo_hash_mismatches).Count -eq 0 -and @($result.public_repo_missing_files).Count -eq 0)
  if(-not $result.repo_exact_v12){ throw 'Public repository does not exactly match the sealed V12 deployment manifest.' }

  $result.failure_phase = 'PUBLIC_PAGES_ROUTES'
  $routes = @(
    [ordered]@{ name='index'; url=$PagesBase; marker='HYDRA / MARKET INTELLIGENCE DATA PLATFORM' },
    [ordered]@{ name='constraint_case'; url=($PagesBase + 'constraint-case-study-v2.html'); marker='HYDRA_CONSTRAINT_CASE_STUDY_V2' },
    [ordered]@{ name='repository'; url=($PagesBase + 'repository.html'); marker='HYDRA / REPOSITORY FRONT DOOR' }
  )
  $routePass = $true
  $bodies = @{}
  foreach($route in $routes){
    $resp = Get-Web $route.url $route.name
    $status = if($resp){ [int]$resp.StatusCode } else { $null }
    $body = if($resp){ [string]$resp.Content } else { '' }
    $markerFound = ($body.Contains([string]$route.marker))
    $pass = ($status -eq 200 -and $markerFound)
    if(-not $pass){ $routePass = $false }
    $result.pages_checks += [ordered]@{ name=$route.name; url=$route.url; status=$status; marker=[string]$route.marker; marker_found=$markerFound; pass=$pass }
    $bodies[$route.name] = $body
  }
  $result.pages_all_required_routes = $routePass
  if(-not $routePass){ throw 'One or more required GitHub Pages routes are not publicly proven.' }

  $result.failure_phase = 'PUBLIC_MARKER_AUDIT'
  $combined = ($bodies['index'] + "`n" + $bodies['constraint_case'] + "`n" + $bodies['repository'])
  $result.required_markers.recruiter_hero = $combined.Contains('HYDRA / MARKET INTELLIGENCE DATA PLATFORM')
  $result.required_markers.representative_label = $combined.Contains('REPRESENTATIVE')
  $result.required_markers.synthetic_shadow_label = ($combined.Contains('SYNTHETIC / SHADOW') -or $combined.Contains('SHADOW'))
  $result.required_markers.authority_principle = $combined.Contains('Discoverable data is not automatically authorized data.')
  $result.required_markers.blocked_state = ($combined.Contains('BLOCKED') -or $combined.Contains('VALID ENGINEERING OUTCOME: BLOCK'))
  $result.required_markers.public_claim_boundary = ($combined.Contains('Public claim boundary:') -or $combined.Contains('Claim boundary:'))
  foreach($kv in $result.required_markers.GetEnumerator()){
    if(-not [bool]$kv.Value){ throw "Required public marker missing: $($kv.Key)" }
  }

  # Fail only on explicit unsupported affirmative production language, not on boundary text that denies it.
  $badPatterns = @(
    'live production validated',
    'production constraint detection proven',
    'running in production',
    'production ML execution verified'
  )
  foreach($p in $badPatterns){ if($combined.ToLowerInvariant().Contains($p)){ $result.unsupported_live_production_claim_found = $true } }
  if($result.unsupported_live_production_claim_found){ throw 'Unsupported affirmative live-production claim detected in public pages.' }

  $result.failure_phase = $null
  $result.overall = 'PASS_FINAL_PUBLIC_SITE_RELEASE_SEAL'
  $result.next_action = 'PUBLIC_RELEASE_SEALED_NO_FURTHER_WEBSITE_WORK_REQUIRED_UNLESS_NEW_SCOPE_IS_AUTHORIZED'
}
catch {
  $result.failure_message = $_.Exception.Message
  if($result.failure_phase -eq 'V13_RECEIPT_DISCOVERY'){
    $result.overall = 'BLOCKED_V13_DEPLOYMENT_NOT_PROVEN'
    $result.next_action = 'RUN_V13_DEPLOYMENT_AND_RETURN_ITS_RECEIPT_THEN_RERUN_V14'
  } elseif($result.failure_phase -eq 'PUBLIC_PAGES_ROUTES'){
    $result.overall = 'BLOCKED_PUBLIC_PAGES_NOT_PROVEN'
    $result.next_action = 'ENABLE_OR_CONFIRM_GITHUB_PAGES_FOR_MAIN_ROOT_THEN_RERUN_V14'
  } elseif($result.failure_phase -in @('PUBLIC_FILE_HASH_VERIFY','PUBLIC_COMMIT_VERIFY')){
    $result.overall = 'BLOCKED_PUBLIC_REPOSITORY_DOES_NOT_MATCH_SEALED_V12'
    $result.next_action = 'REPAIR_ONLY_THE_REPORTED_PUBLIC_REPOSITORY_MISMATCH_THEN_RERUN_V14'
  } else {
    $result.overall = 'BLOCKED_FINAL_PUBLIC_RELEASE_SEAL'
    $result.next_action = 'REPAIR_ONLY_THE_REPORTED_VERIFICATION_DEFECT_THEN_RERUN_V14'
  }
  Write-Host "ERROR=$($result.failure_message)" -ForegroundColor Red
}
finally {
  Write-ReturnPacket
  Write-Host '============================================================'
  Write-Host "OVERALL=$($result.overall)"
  Write-Host "REPO_EXACT_V12=$($result.repo_exact_v12)"
  Write-Host "PAGES_ALL_REQUIRED_ROUTES=$($result.pages_all_required_routes)"
  Write-Host "NEXT_ACTION=$($result.next_action)"
  Write-Host '============================================================'
}

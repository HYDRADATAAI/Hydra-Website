param(
    [string]$HydraRoot="D:\HYDRA",
    [string]$V028Evidence=""
)
$ErrorActionPreference="Stop"
Set-StrictMode -Version Latest

Write-Host "============================================================"
Write-Host "NYX N2 V029 - RECEIPT WRITER CALLER ADJUDICATION"
Write-Host "============================================================"
Write-Host "PARENT_DEFECT=N2-DEFECT-024-RUNTIME-BINDING-CONTRACT-OWNER-NOT-PROVEN"
Write-Host "HYDRA_ROOT=$HydraRoot"
Write-Host "MODE=READ_ONLY_EXACT_RECEIPT_WRITER_CALLER_ADJUDICATION"
Write-Host "MENTION_ONLY_AUTHORITY=REJECTED"
Write-Host "IDENTICAL_HASH_OWNER_AUTHORITY=REJECTED"
Write-Host "MTIME_AUTHORITY=NO"
Write-Host "SCORE_SELECTION=NO"
Write-Host "UPSTREAM_MUTATION_AUTHORIZED=NO"
Write-Host "N2_MUTATION=NONE"

$Downloads=Join-Path $env:USERPROFILE "Downloads"
if(-not $V028Evidence){
    $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "N2_V028_RETURN_PACKET_*.zip" -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending
    $Found=$null
    foreach($C in $Candidates){
        $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        if($H -eq "274c9040e80d1479e8feda0ac4005e1b047166d693ffdb0f0ca6613f87b052c5"){$Found=$C;break}
    }
    if(-not $Found){
        $Candidates=Get-ChildItem -LiteralPath $Downloads -Filter "*V028*RETURN*.zip" -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending
        foreach($C in $Candidates){
            $H=(Get-FileHash -LiteralPath $C.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            if($H -eq "274c9040e80d1479e8feda0ac4005e1b047166d693ffdb0f0ca6613f87b052c5"){$Found=$C;break}
        }
    }
    if(-not $Found){throw "Exact V028 return packet not found with SHA256=274c9040e80d1479e8feda0ac4005e1b047166d693ffdb0f0ca6613f87b052c5"}
    $V028Evidence=$Found.FullName
}
$Actual=(Get-FileHash -LiteralPath $V028Evidence -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host "V028_EVIDENCE=$V028Evidence"
Write-Host "V028_EVIDENCE_SHA256=$Actual"
if($Actual -ne "274c9040e80d1479e8feda0ac4005e1b047166d693ffdb0f0ca6613f87b052c5"){throw "V028 evidence hash mismatch."}
Write-Host "V028_EVIDENCE_HASH_VERIFIED=PASS"

$PkgRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
$Py=Join-Path $PkgRoot "n2_v029_receipt_writer_caller_adjudication.py"
$PythonCmd=Get-Command python.exe -ErrorAction SilentlyContinue
$PyLauncher=Get-Command py.exe -ErrorAction SilentlyContinue
if($PythonCmd){$PythonExe=$PythonCmd.Source;$Prefix=@();Write-Host "PYTHON_LAUNCH_MODE=DIRECT_PYTHON"}
elseif($PyLauncher){$PythonExe=$PyLauncher.Source;$Prefix=@("-3");Write-Host "PYTHON_LAUNCH_MODE=PY_LAUNCHER_3"}
else{throw "Python not found."}
Write-Host "PYTHON_COMMAND=$PythonExe"

& $PythonExe @Prefix $Py --selftest
if($LASTEXITCODE -ne 0){throw "V029 selftest failed."}

$RunDir="D:\NYX_N2_WORK\V029_RECEIPT_WRITER_CALLER_$(Get-Date -Format yyyyMMdd_HHmmss)"
$ReturnDir=Join-Path $RunDir "N2_V029_RETURN"
New-Item -ItemType Directory -Path $ReturnDir -Force|Out-Null
Write-Host "RUN_DIR=$RunDir"

& $PythonExe @Prefix $Py --hydra-root $HydraRoot --v028-evidence $V028Evidence --output-dir $ReturnDir
if($LASTEXITCODE -ne 0){throw "V029 caller adjudication failed."}

$R=Get-Content -LiteralPath (Join-Path $ReturnDir "N2_V029_RECEIPT_WRITER_CALLER_ADJUDICATION.json") -Raw|ConvertFrom-Json
$ReturnZip=Join-Path $Downloads ("N2_V029_RECEIPT_WRITER_CALLER_RETURN_{0}.zip" -f (Get-Date -Format yyyyMMdd_HHmmss))
Compress-Archive -Path (Join-Path $ReturnDir "*") -DestinationPath $ReturnZip -CompressionLevel Optimal
$ReturnSha=(Get-FileHash -LiteralPath $ReturnZip -Algorithm SHA256).Hash.ToLowerInvariant()

Write-Host ""
Write-Host "============================================================"
Write-Host "N2 V029 FINAL"
Write-Host "============================================================"
Write-Host "FINAL=$($R.status)"
Write-Host "DEFECT_ID=$($R.defect_id)"
Write-Host "WRITER_COUNT=$($R.writer_count)"
Write-Host "STRONG_CALLER_COUNT=$($R.strong_caller_count)"
Write-Host "MENTION_ONLY_COUNT=$($R.mention_only_count)"
if($null -ne $R.selected_writer_branch){
    Write-Host "SELECTED_WRITER_PATH=$($R.selected_writer_branch.writer_path)"
    Write-Host "SELECTED_WRITER_SHA256=$($R.selected_writer_branch.writer_sha256)"
}
Write-Host "READ_ONLY=TRUE"
Write-Host "BASELINE_MUTATED=FALSE"
Write-Host "CANONICAL_CORE_MUTATED=FALSE"
Write-Host "CONSTRAINT_SEMANTICS_MUTATED=FALSE"
Write-Host "N2_MUTATED=FALSE"
Write-Host "NEXT_ACTION=$($R.next_action)"
Write-Host "RETURN_ZIP=$ReturnZip"
Write-Host "RETURN_SHA256=$ReturnSha"
Write-Host "RETURN_RUN_DIR=$RunDir"

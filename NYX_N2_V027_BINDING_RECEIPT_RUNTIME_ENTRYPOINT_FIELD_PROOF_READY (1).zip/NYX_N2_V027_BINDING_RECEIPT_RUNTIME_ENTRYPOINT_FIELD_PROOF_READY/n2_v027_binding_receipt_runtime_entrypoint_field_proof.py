
from __future__ import annotations

import argparse
import hashlib
import json
import ntpath
import os
import re
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Mapping

EXPECTED_V026_SHA256 = "f99515fbd8c0a022639fa7f3ea21c10f47dc7d87359b1463efa3e45ba93517e3"
ANCHOR_PATH = r"D:\\HYDRA\\phase0_surface_implementations\\constraint_semantics_surface_v001.py"
ANCHOR_SHA256 = "bc95f5f86142084234c2dc954c7f6f192bfcbbdcdf3f77ce53bedbda7262388c"
FALLBACK_RECEIPTS = ['D:\\HYDRA\\execution_runtime\\NYX_PHASE0_HOST_PREFLIGHT_20260906_165307\\nyx_runtime\\phase0_binding_review\\BINDING\\BOUND_IMPLEMENTATION_TREE_HASH.json', 'D:\\HYDRA\\execution_runtime\\NYX_PHASE0_HOST_PREFLIGHT_20260906_165307\\nyx_runtime\\phase0_binding_review\\BINDING\\IMPLEMENTATION_SURFACE_BINDING_RECEIPT.json', 'D:\\HYDRA\\execution_runtime\\NYX_PHASE0_HOST_PREFLIGHT_20260906_165307\\nyx_runtime\\phase0_binding_review\\EVIDENCE\\EXPLICIT_10_SURFACE_SELECTION_EVIDENCE.json', 'D:\\HYDRA\\execution_runtime\\NYX_PHASE0_HOST_PREFLIGHT_20260906_165307\\nyx_runtime\\phase0_binding_review\\REVIEW\\implementation_surface_review.json', 'D:\\HYDRA\\execution_runtime\\NYX_PHASE0_HOST_PREFLIGHT_20260906_165307\\nyx_runtime\\phase0_discovery_workspace\\implementation_discovery\\implementation_candidates.json', 'D:\\HYDRA\\execution_runtime\\NYX_PHASE0_HOST_PREFLIGHT_20260906_165307\\nyx_runtime\\phase0_discovery_workspace\\trust_t5_stabilization_20260906_165307\\CONSTRAINT_SEMANTICS_V001_BUILD_RECEIPT.json', 'D:\\HYDRA\\execution_runtime\\NYX_PHASE0_HOST_PREFLIGHT_20260906_165307\\nyx_runtime\\phase0_discovery_workspace\\trust_t5_stabilization_20260906_165307\\CONSTRAINT_SEMANTICS_V001_NARROW_PROBE.json', 'D:\\HYDRA\\execution_runtime\\NYX_PHASE0_HOST_PREFLIGHT_20260906_165307\\nyx_runtime\\phase0_discovery_workspace\\trust_t5_stabilization_20260906_165307\\post_discovery_resume\\CONSTRAINT_SEMANTICS_V001_NARROW_BINDING_PROOF.json']

EXEC_EXTS = {".py",".ps1",".cmd",".bat"}
EXPLICIT_FIELD_TOKENS = {
    "runtime_entrypoint","runtime_runner","runtime_loader",
    "entrypoint","entry_point","runner","launcher","loader",
    "executable","invocation","command","bootstrap","script",
}
REJECT_FIELD_TOKENS = {
    "selected_path","implementation_path","target_path","resolved_target",
    "selection_path","proof","receipt","hash","sha256","candidate",
}

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()

def is_win_path(v: Any) -> bool:
    return isinstance(v,str) and bool(re.match(r"^[A-Za-z]:[\\/]",v.strip()))

def canon(v: str) -> str:
    s=v.strip().strip("'\"").replace("/","\\")
    while "\\\\" in s:
        s=s.replace("\\\\","\\")
    s=ntpath.normpath(s)
    if re.match(r"^[A-Za-z]:",s):
        s=s[0].upper()+s[1:]
    return s.casefold()

def display(v: str) -> str:
    s=v.strip().strip("'\"").replace("/","\\")
    while "\\\\" in s:
        s=s.replace("\\\\","\\")
    s=ntpath.normpath(s)
    if re.match(r"^[A-Za-z]:",s):
        s=s[0].upper()+s[1:]
    return s

def recursive(obj: Any, ptr="#"):
    if isinstance(obj,Mapping):
        yield ptr,obj
        for k,v in obj.items():
            yield from recursive(v,ptr+"/"+str(k))
    elif isinstance(obj,list):
        for i,v in enumerate(obj):
            yield from recursive(v,ptr+"/"+str(i))

def read_v026(zip_path: Path):
    actual=sha256_file(zip_path)
    if actual!=EXPECTED_V026_SHA256:
        raise RuntimeError(f"V026 evidence hash mismatch expected={EXPECTED_V026_SHA256} actual={actual}")

    docs=[]
    with zipfile.ZipFile(zip_path,"r") as z:
        for name in z.namelist():
            if name.casefold().endswith(".json"):
                try:
                    docs.append((name,json.loads(z.read(name).decode("utf-8"))))
                except Exception:
                    pass

    receipt_paths=[]
    report_member=None
    for member,doc in docs:
        if "N2_V026" in member.upper():
            report_member=member
        for ptr,obj in recursive(doc):
            if not isinstance(obj,Mapping):
                continue
            blob=json.dumps(obj,sort_keys=True,default=str).casefold()
            for k,v in obj.items():
                if not is_win_path(v):
                    continue
                kc=str(k).casefold()
                vc=str(v).casefold()
                if (
                    "receipt" in kc or "binding" in kc or "proof" in kc or
                    "receipt" in vc or "binding" in vc or "proof" in vc
                ):
                    if canon(v)!=canon(ANCHOR_PATH):
                        receipt_paths.append(display(v))

    # V026 may not preserve all eight upstream receipt paths explicitly.
    # Fall back only to the exact receipt allowlist already proven by V024.
    if len(set(map(canon,receipt_paths))) < 2:
        receipt_paths=list(FALLBACK_RECEIPTS)

    uniq={}
    for p in receipt_paths:
        uniq[canon(p)]=display(p)

    return {
        "docs":docs,
        "report_member":report_member,
        "receipt_paths":list(uniq.values()),
    }

def normalized_key(k: str) -> str:
    return re.sub(r"[^a-z0-9]+","_",k.casefold()).strip("_")

def key_is_explicit_runtime_field(k: str) -> bool:
    nk=normalized_key(k)
    if nk in REJECT_FIELD_TOKENS:
        return False
    parts=set(nk.split("_"))
    if nk in EXPLICIT_FIELD_TOKENS:
        return True
    if "runtime" in parts and bool(parts & {"entrypoint","runner","loader","launcher","executable","command","script","bootstrap"}):
        return True
    if nk.endswith("_path") and bool(parts & {"entrypoint","runner","loader","launcher","executable","script","bootstrap"}):
        return True
    if nk.endswith("_command") or nk.endswith("_invocation"):
        return True
    return False

def extract_script_candidates(value: str):
    vals=[]
    s=value.strip()

    if is_win_path(s):
        vals.append(display(s))

    # Quoted or bare executable script paths inside command strings.
    rx=re.compile(r'(?i)([A-Za-z]:[\\/][^"\']+?\.(?:py|ps1|cmd|bat)|[A-Za-z0-9_.$%{}()/:\\+-]+\.(?:py|ps1|cmd|bat))')
    for m in rx.finditer(s):
        vals.append(m.group(1).strip())

    uniq={}
    for v in vals:
        uniq[canon(v) if is_win_path(v) else v.casefold()]=v
    return list(uniq.values())

def resolve_candidate(raw: str, receipt_path: Path, hydra_root: Path):
    candidates=[]
    if is_win_path(raw):
        candidates.append(Path(display(raw)))
    else:
        candidates.extend([receipt_path.parent/raw,hydra_root/raw])

    rows=[]
    for p in candidates:
        try:
            exists=p.is_file()
        except Exception:
            exists=False
        rows.append({
            "path":str(p),
            "exists":exists,
            "suffix":p.suffix.casefold(),
            "executable_ext":p.suffix.casefold() in EXEC_EXTS,
            "sha256":sha256_file(p) if exists else None,
        })
    return rows

def inspect_receipt(path: Path, hydra_root: Path):
    row={
        "path":str(path),
        "exists":path.is_file(),
        "sha256":sha256_file(path) if path.is_file() else None,
        "explicit_runtime_field_count":0,
        "explicit_runtime_fields":[],
        "resolved_executable_target_count":0,
        "resolved_executable_targets":[],
    }
    if not path.is_file():
        return row

    try:
        doc=json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        row["parse_error"]=str(e)
        return row

    fields=[]
    resolved=[]
    for ptr,obj in recursive(doc):
        if not isinstance(obj,Mapping):
            continue
        for k,v in obj.items():
            if not isinstance(v,str):
                continue
            if not key_is_explicit_runtime_field(str(k)):
                continue

            candidates=extract_script_candidates(v)
            field={
                "pointer":ptr,
                "key":str(k),
                "value":v,
                "candidate_count":len(candidates),
                "candidates":[],
            }

            for cand in candidates:
                resolutions=resolve_candidate(cand,path,hydra_root)
                field["candidates"].extend(resolutions)
                for rr in resolutions:
                    if rr["exists"] and rr["executable_ext"]:
                        resolved.append({
                            "receipt_path":str(path),
                            "pointer":ptr,
                            "field":str(k),
                            "raw_value":v,
                            **rr,
                        })
            fields.append(field)

    # exact path dedup
    uniq={}
    for r in resolved:
        uniq[canon(r["path"])]=r
    resolved=list(uniq.values())

    row["explicit_runtime_field_count"]=len(fields)
    row["explicit_runtime_fields"]=fields
    row["resolved_executable_target_count"]=len(resolved)
    row["resolved_executable_targets"]=resolved
    return row

def selftest():
    td=Path(tempfile.mkdtemp(prefix="n2v027_"))
    try:
        root=td/"HYDRA";root.mkdir()
        runner=root/"RUN_REAL.py";runner.write_text("print('x')\n",encoding="utf-8")
        receipt=root/"receipt.json"
        receipt.write_text(json.dumps({
            "selected_path":r"D:\HYDRA\fake.py",
            "runtime_entrypoint_path":str(runner),
            "runner_command":"python "+str(runner),
        }),encoding="utf-8")
        row=inspect_receipt(receipt,root)
        assert row["explicit_runtime_field_count"]==2
        assert row["resolved_executable_target_count"]==1

        static=root/"static.json"
        static.write_text(json.dumps({
            "selected_path":str(runner),
            "implementation_path":str(runner),
            "narrow_binding_proof":"accepted",
        }),encoding="utf-8")
        row2=inspect_receipt(static,root)
        assert row2["explicit_runtime_field_count"]==0
        assert row2["resolved_executable_target_count"]==0

        print("N2_V027_SELFTEST=PASS")
        print("N2_V027_EXPLICIT_RUNTIME_FIELD_GATE=PASS")
        print("N2_V027_SELECTED_PATH_REJECTED_AS_RUNTIME_FIELD=PASS")
        print("N2_V027_LIVE_EXECUTABLE_RESOLUTION=PASS")
        print("N2_V027_RECEIPT_SCOPE_ONLY=PASS")
    finally:
        shutil.rmtree(td,ignore_errors=True)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--hydra-root",default=r"D:\HYDRA")
    ap.add_argument("--v026-evidence")
    ap.add_argument("--output-dir")
    ap.add_argument("--selftest",action="store_true")
    args=ap.parse_args()

    if args.selftest:
        selftest()
        return 0

    root=Path(args.hydra_root)
    ev=Path(args.v026_evidence)
    outdir=Path(args.output_dir)

    if not root.is_dir():
        raise RuntimeError(f"HYDRA root missing: {root}")

    evidence=read_v026(ev)

    anchor=Path(ANCHOR_PATH)
    if not anchor.is_file():
        raise RuntimeError(f"anchor missing: {anchor}")
    anchor_sha=sha256_file(anchor)
    if anchor_sha!=ANCHOR_SHA256:
        raise RuntimeError(f"anchor hash drift: {anchor_sha}")

    receipts=[]
    for raw in evidence["receipt_paths"]:
        receipts.append(inspect_receipt(Path(raw),root))

    live=[r for r in receipts if r["exists"]]
    explicit_field_total=sum(r["explicit_runtime_field_count"] for r in receipts)
    resolved=[]
    for r in receipts:
        resolved.extend(r["resolved_executable_targets"])

    # exact executable path dedup
    uniq={}
    for r in resolved:
        uniq[canon(r["path"])]=r
    resolved=list(uniq.values())

    if len(resolved)==1:
        status="UNIQUE_EXPLICIT_RUNTIME_ENTRYPOINT_FIELD_PROVEN"
        defect=None
        selected=resolved[0]
        next_action="PIN_EXPLICIT_RUNTIME_ENTRYPOINT_AND_PROVE_IT_LOADS_SELECTED_SURFACE"
    elif len(resolved)>1:
        status="MULTIPLE_EXPLICIT_RUNTIME_ENTRYPOINT_FIELDS_PROVEN"
        defect="N2-DEFECT-023-BINDING-RECEIPT-RUNTIME-ENTRYPOINT-AMBIGUOUS"
        selected=None
        next_action="STOP_NO_MUTATION_ADJUDICATE_MULTIPLE_RECEIPT_DECLARED_RUNTIME_ENTRYPOINTS"
    elif explicit_field_total>0:
        status="RUNTIME_ENTRYPOINT_FIELDS_PRESENT_BUT_TARGETS_UNRESOLVED"
        defect="N2-DEFECT-023-BINDING-RECEIPT-RUNTIME-ENTRYPOINT-UNRESOLVED"
        selected=None
        next_action="STOP_NO_MUTATION_FIX_ONLY_EXPLICIT_RUNTIME_ENTRYPOINT_TARGET_RESOLUTION"
    else:
        status="NO_EXPLICIT_RUNTIME_ENTRYPOINT_FIELD_IN_BINDING_RECEIPTS"
        defect="N2-DEFECT-023-BINDING-RECEIPTS-LACK-RUNTIME-ENTRYPOINT"
        selected=None
        next_action="FREEZE_SELECTED_SURFACE_AS_STATIC_BINDING_ONLY_RUNTIME_BINDING_CONTRACT_MISSING"

    result={
        "version":"N2_V027_BINDING_RECEIPT_RUNTIME_ENTRYPOINT_FIELD_PROOF",
        "parent_defect":"N2-DEFECT-022-RESOLVED-TARGETS-NON-EXECUTABLE",
        "v026_sha256":sha256_file(ev),
        "v026_report_member":evidence.get("report_member"),
        "hydra_root":str(root),
        "anchor_path":str(anchor),
        "anchor_sha256":anchor_sha,
        "receipt_seed_count":len(receipts),
        "live_receipt_count":len(live),
        "receipts":receipts,
        "explicit_runtime_field_count":explicit_field_total,
        "resolved_executable_target_count":len(resolved),
        "resolved_executable_targets":resolved,
        "selected_runtime_entrypoint":selected,
        "status":status,
        "defect_id":defect,
        "next_action":next_action,
        "read_only":True,
        "baseline_mutated":False,
        "canonical_core_mutated":False,
        "n2_mutated":False,
        "whole_tree_search":False,
        "target_child_traversal":False,
        "score_selection":False,
        "mtime_authority":False,
        "newest_wins":False,
        "alias_binding":"NONE",
    }

    outdir.mkdir(parents=True,exist_ok=True)
    (outdir/"N2_V027_BINDING_RECEIPT_RUNTIME_ENTRYPOINT_FIELD_PROOF.json").write_text(
        json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")

    print("="*60)
    print("NYX N2 V027 - BINDING RECEIPT RUNTIME ENTRYPOINT FIELD PROOF")
    print("="*60)
    print("FINAL="+status)
    print("PARENT_DEFECT="+result["parent_defect"])
    print("DEFECT_ID="+(defect or "NONE"))
    print("V026_REPORT_MEMBER="+str(result["v026_report_member"] or ""))
    print("RECEIPT_SEED_COUNT="+str(len(receipts)))
    print("LIVE_RECEIPT_COUNT="+str(len(live)))
    print("EXPLICIT_RUNTIME_FIELD_COUNT="+str(explicit_field_total))
    print("RESOLVED_EXECUTABLE_TARGET_COUNT="+str(len(resolved)))
    if selected:
        print("SELECTED_RUNTIME_ENTRYPOINT="+selected["path"])
        print("SELECTED_RUNTIME_ENTRYPOINT_SHA256="+str(selected["sha256"] or ""))
        print("SELECTED_RUNTIME_ENTRYPOINT_RECEIPT="+selected["receipt_path"])
        print("SELECTED_RUNTIME_ENTRYPOINT_FIELD="+selected["field"])
    print("ANCHOR_PATH="+str(anchor))
    print("ANCHOR_SHA256="+anchor_sha)
    print("READ_ONLY=TRUE")
    print("BASELINE_MUTATED=FALSE")
    print("CANONICAL_CORE_MUTATED=FALSE")
    print("N2_MUTATED=FALSE")
    print("WHOLE_TREE_SEARCH=NO")
    print("TARGET_CHILD_TRAVERSAL=NO")
    print("SCORE_SELECTION=NO")
    print("MTIME_AUTHORITY=NO")
    print("NEWEST_WINS=NO")
    print("ALIAS_BINDING=NONE")
    print("NEXT_ACTION="+next_action)
    return 0

if __name__=="__main__":
    raise SystemExit(main())

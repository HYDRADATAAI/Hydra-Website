# Contract + Authority Excerpt

**Evidence class: EXECUTED TEST SUMMARY / BOUNDED EXCERPT**

This page is a recruiter-safe inspection aid derived from the CI-TEST-008 authority/admissibility result. It is **not the complete native T6 schema**.

## Tested authority question

CI-TEST-008 asked whether the authoritative native T5→T6 handoff could legitimately satisfy downstream T6 requirements without inventing semantics.

The executed result was:

```text
RESULT = BLOCKED_BY_MISSING_AUTHORITY
T6_NATIVE_CONTRACT = PROVEN
T5_TO_T6_AUTHORITATIVE_BINDING = ABSENT
SEMANTIC_VALUES_INVENTED = NO
BASELINE_MUTATED = NO
```

## Downstream fields explicitly protected from fabrication

The public receipt records that these values were **not** synthesized merely to satisfy downstream validation:

```text
as_of
confidence
evidence_ids
object_type
subject_entity_id
```

This list is a tested field-requirements excerpt, not a claim that these five fields constitute the entire native T6 contract.

## Engineering behavior demonstrated

```text
required downstream field
        ↓
find authoritative producer / valid derivation
        ↓
      found? ── yes ──> validate handoff
        │
        no
        ↓
BLOCKED_BY_MISSING_AUTHORITY
        ↓
DO NOT FABRICATE SEMANTICS
```

Inspect the compact executed receipt: [`../proof/CI_TEST_008_AUTHORITY_BLOCKER_RECEIPT.json`](../proof/CI_TEST_008_AUTHORITY_BLOCKER_RECEIPT.json).

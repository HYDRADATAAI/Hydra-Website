# NYX Constraint Intelligence T1-T5 — Batch 63 Receipt-Bound Host Builder

This ZIP does **not** pretend Batch 63 is already sealed. It builds Batch 63 only after your local Batch 62 build has produced a real `BATCH62_SEAL_RECEIPT.json`.

## One click

1. Finish Batch 62 with the prior host builder.
2. Leave its output in the default `D:\NYX_BATCH62_BUILD` folder, or keep the sealed Batch 62 ZIP / ten Batch 62 transfer ZIPs plus `BATCH62_SEAL_RECEIPT.json` together.
3. Extract this ZIP.
4. Double-click `RUN_BATCH63_FROM_BATCH62.cmd`.

The runner prefers the already sealed Batch 62 ZIP if present. If it is absent, it reconstructs Batch 62 from the ten transfer ZIPs. In both cases it requires the bytes and SHA-256 to match the Batch 62 seal receipt exactly before Batch 63 construction begins.

## Batch 63 target

- Packaging: `DELTA_WITH_EXACT_SEALED_PREDECESSOR`
- Boundary: `SYNTHETIC_SHADOW_ONLY`
- Schema profile: `2.45`
- Golden seeds: `63001` through `63012`
- Outer members: `8,915`
- Manifest-governed entries: `8,912`
- Shadow QA checks: `3,355`
- Transfer ZIPs: exactly `10`
- Thread 6: `NOT_STARTED`
- Real production data: not used
- Automatic canonical promotion: disabled
- Baby-ML training: disabled
- Trading-signal generation: disabled

A successful run writes the sealed Batch 63 ZIP, ten Batch 63 transfer ZIPs, and `BATCH63_SEAL_RECEIPT.json`.

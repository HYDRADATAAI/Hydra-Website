# Architecture

HYDRA is presented publicly as a **market intelligence data platform**. The architecture is organized around data custody and governed transformations rather than a single monolithic model.

> **Scope note:** the diagram below is the governed architecture model. Public recruiter evidence proves specific real-data and synthetic/shadow paths; it does not claim that every source family in the diagram is live or publicly integrated today.

```mermaid
flowchart TD
    S[Market / reference / history sources]
    I[Ingestion]
    N[Normalization]
    ID[Identity resolution]
    C[Contract gates]
    E[Evidence / trust]
    H[History / replay]
    K[Constraint interpretation]
    L[Lineage]
    R[Release / downstream gate]

    S --> I --> N --> ID --> C --> E --> H --> K --> R
    I --> L
    N --> L
    ID --> L
    C --> L
    E --> L
    H --> L
    K --> L
    L --> R
```

## Boundary model

**Ingestion** discovers and accounts for source material.

**Normalization** produces controlled internal structure without erasing source identity.

**Identity** determines which records refer to the same governed subject. Downstream classifiers are not allowed to create canonical identity merely because evidence looks similar.

**Contracts** define the exact fields a downstream stage is allowed to require and consume.

**Evidence / trust / history** preserve source relationships, temporal state, and replayable lineage.

**Constraint interpretation** enriches already-governed objects. It preserves ambiguity and refuses semantic promotion when authority is missing.

**Release gates** allow a result to travel downstream only when its required structure and authority are satisfied.

## Architectural theme

The architecture deliberately separates four questions:

1. **What data exists?**
2. **What does it refer to?**
3. **What is the system authorized to infer from it?**
4. **Can the result be traced and reproduced?**

Keeping those questions separate is the central engineering decision behind HYDRA's public story.

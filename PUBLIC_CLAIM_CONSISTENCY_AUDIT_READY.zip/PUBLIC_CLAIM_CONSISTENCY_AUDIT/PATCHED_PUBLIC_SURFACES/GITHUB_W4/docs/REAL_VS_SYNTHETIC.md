# Real vs. synthetic evidence

HYDRA's public materials should keep evidence scope visible. The labels below are part of the engineering story, not fine print.

| Public item | Label | Meaning |
|---|---|---|
| Historical options canonicalization | **REAL** | Real historical source files were processed into a canonical dataset. |
| CI-TEST-004 repaired seam | **SYNTHETIC / SHADOW** | Integrated contract and repair behavior was exercised against the frozen synthetic/shadow baseline. |
| CI-TEST-005 behavioral seam | **SYNTHETIC / SHADOW** | Replay, lineage, reverse trace, why trace, and blocker behavior were integration-tested without claiming live production data. |
| CI-TEST-008 authority rejection | **SYNTHETIC / SHADOW** | Native handoff authority rules were tested; missing semantic authority remained blocked. |
| Recruiter constraint case | **REPRESENTATIVE / NON-LIVE** | The example illustrates governed constraint interpretation without presenting a fabricated live market conclusion. |

## Claims deliberately not made

This front door does not claim:

- live production deployment;
- live market constraint output;
- production ML inference;
- production automated trading;
- production reliability/SLA;
- a verified public production runner.

When those states become provable, they should be added only with a corresponding artifact, receipt, or independently verifiable execution path.

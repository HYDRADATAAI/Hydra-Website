# Real vs Synthetic

HYDRA uses explicit evidence labels so a recruiter can tell what has actually been executed from what is explanatory or synthetic.

| Label | Meaning in this front door | Example |
|---|---|---|
| Executed test evidence | A real local test/result receipt with recorded outcome and integrity metadata | CI-TEST-005, CI-TEST-008, N1 sealed result |
| Integrated | A test that exercised an actual cross-stage or cross-thread seam | CI-TEST-005 |
| Representative / non-live | Public-safe example used to explain data structures and flow | Representative constraint case |
| Synthetic / shadow | Controlled hardening or validation that does not claim live production behavior | Broader HYDRA hardening lanes |
| Live production | Operational live market inference | **Not claimed by this front door** |

## Public claim boundary

This recruiter package may truthfully claim:

- executed validation and seam tests;
- deterministic identity invariants;
- provenance/lineage design and evidence;
- contract and authority enforcement;
- explicit PASS / BLOCK behavior;
- baseline mutation checks;
- representative constraint structures.

It does not claim:

- live production trading signals;
- live production market inference;
- a public runnable demo that has not been safely packaged;
- authority for downstream fields that CI-TEST-008 showed were missing from the native T5→T6 handoff.
